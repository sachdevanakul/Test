"""
Waitress Entry Point for eDMS Production Deployment.

Acts as the WSGI application server backend. It runs bound strictly to 
localhost (127.0.0.1:8081) and processes Python/Django logic forwarded by Apache.

Usage:
    python run_waitress.py
"""

import os
import sys
import logging

# 1. Setup minimal logging to trace startup errors on Windows
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("eDMS.Waitress")

def main():
    logger.info("Initializing eDMS System Path and Environment...")
    
    # 2. Fix working directory resolution safely
    current_dir = os.path.dirname(os.path.abspath(__file__))
    if current_dir not in sys.path:
        sys.path.insert(0, current_dir)
        
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'edms.settings')

    try:
        # 3. Import WSGI application safely *inside* the execution block
        from waitress import serve
        from edms.wsgi import application
    except ImportError as e:
        logger.critical(f"Failed to import dependencies. Is your Virtual Environment active? Error: {e}")
        sys.exit(1)

    # 4. Production Network Rules & Metadata Configuration
    HOST = '0.0.0.0'
    PORT = 8081
    THREADS = 8
    TIMEOUT = 180

    logger.info("--------------------------------------------------")
    logger.info(f"Starting eDMS backend via Waitress WSGI Server")
    logger.info(f"Address: http://{HOST}:{PORT}")
    logger.info(f"Worker Threads: {THREADS} | Timeout Channel: {TIMEOUT}s")
    logger.info("Status: Listening for incoming Apache reverse-proxy traffic...")
    logger.info("--------------------------------------------------")

    try:
        serve(
            application,
            host=HOST,
            port=PORT,
            threads=THREADS,
            channel_timeout=TIMEOUT,
            connection_limit=200,   # Prevents resource exhaustion on Windows
            url_prefix=''           # Ensures clean routing matches Apache's Alias rules
        )
    except Exception as e:
        logger.critical(f"Waitress server encountered an unexpected failure: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()