import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'edms.settings')
django.setup()

from django.db import connection
from django.core.management import call_command

def fix_dak_nature_master():
    print("="*60)
    print("COMPLETE FIX FOR DAK_NATURE_MASTER")
    print("="*60)
    
    with connection.cursor() as cursor:
        # Get current columns
        cursor.execute("SELECT column_name FROM information_schema.columns WHERE table_name='dak_nature_master';")
        current = [col[0] for col in cursor.fetchall()]
        print(f"\nCurrent columns: {current}")
        
        # All required columns for the model
        required_columns = {
            'id': 'SERIAL PRIMARY KEY',
            'nature_name': 'varchar(100) UNIQUE NOT NULL',
            'applicable_category': 'varchar(50)',
            'is_active': 'boolean DEFAULT true',
            'is_system_defined': 'boolean DEFAULT false',
            'source': "varchar(20) DEFAULT 'MANUAL'",
            'created_by_id': 'integer',
            'created_at': 'timestamp with time zone DEFAULT NOW()',
            'updated_at': 'timestamp with time zone',
        }
        
        # Add missing columns
        for col_name, col_type in required_columns.items():
            if col_name not in current:
                try:
                    # Special handling for primary key and constraints
                    if col_name == 'id':
                        continue  # id should already exist
                    cursor.execute(f"ALTER TABLE dak_nature_master ADD COLUMN {col_name} {col_type};")
                    print(f"✓ Added column: {col_name}")
                except Exception as e:
                    print(f"✗ Error adding {col_name}: {e}")
            else:
                print(f"✓ Column exists: {col_name}")
        
        # Add foreign key constraint if needed
        try:
            cursor.execute("""
                SELECT CONSTRAINT_NAME 
                FROM information_schema.TABLE_CONSTRAINTS 
                WHERE TABLE_NAME='dak_nature_master' AND CONSTRAINT_TYPE='FOREIGN KEY';
            """)
            fk_exists = cursor.fetchone()
            if not fk_exists and 'created_by_id' in required_columns:
                cursor.execute("""
                    ALTER TABLE dak_nature_master 
                    ADD CONSTRAINT dak_nature_master_created_by_fkey 
                    FOREIGN KEY (created_by_id) REFERENCES auth_user(id);
                """)
                print("✓ Added foreign key constraint")
        except Exception as e:
            print(f"Foreign key error: {e}")
        
        # Verify final structure
        cursor.execute("SELECT column_name FROM information_schema.columns WHERE table_name='dak_nature_master' ORDER BY ordinal_position;")
        final = [col[0] for col in cursor.fetchall()]
        print("\n✅ Final columns in dak_nature_master:")
        for col in final:
            print(f"  - {col}")
    
    print("\n" + "="*60)
    print("Faking migrations...")
    call_command('migrate', 'daks', '--fake')
    print("✅ Done! Nature field should now work.")
    print("="*60)

if __name__ == "__main__":
    fix_dak_nature_master()