@echo off
SETLOCAL Enabledelayedenvironmentvariable
TITLE eDMS Backend Server Manager

:: =====================================================================
:: Configuration
:: =====================================================================
SET "PROJECT_DIR=C:\eDMS_Project"
SET "CODE_DIR=%PROJECT_DIR%\Code"
SET "VENV_ACTIVATE=%PROJECT_DIR%\venv\Scripts\activate.bat"

echo =====================================================================
echo  Initializing eDMS Production Bootstrapper...
echo =====================================================================

:: 1. Verify Project Directory Exists
if not exist "%PROJECT_DIR%" (
    echo [ERROR] Project root directory not found at: %PROJECT_DIR%
    goto ERROR_EXIT
)

:: 2. Verify Virtual Environment Exists
if not exist "%VENV_ACTIVATE%" (
    echo [ERROR] Virtual environment activation script missing: %VENV_ACTIVATE%
    goto ERROR_EXIT
)

:: 3. Navigate to Project Directory
echo [*] Changing directory to: %PROJECT_DIR%
cd /d "%PROJECT_DIR%" || goto ERROR_EXIT

:: 4. Activate Virtual Environment cleanly
echo [*] Activating Python Virtual Environment...
call "%VENV_ACTIVATE%" || (
    echo [ERROR] Failed to activate virtual environment.
    goto ERROR_EXIT
)

:: 5. Navigate to Code Directory
echo [*] Changing directory to: %CODE_DIR%
cd /d "%CODE_DIR%" || goto ERROR_EXIT

:: 6. Launch Server Process
echo [*] Spawning Waitress Engine...
echo ---------------------------------------------------------------------
python run_waitress.py

:: Catch unexpected script drops or deliberate exits
if %ERRORLEVEL% NEQ 0 (
    echo ---------------------------------------------------------------------
    echo [CRITICAL] Waitress exited with unexpected error code: %ERRORLEVEL%
    goto ERROR_EXIT
)

goto SUCCESS_EXIT

:: =====================================================================
:: Exit Triggers
:: =====================================================================
:ERROR_EXIT
echo.
echo [FAILURE] Process terminated prematurely. Check your configurations.
color 0C
pause
exit /b 1

:SUCCESS_EXIT
echo.
echo [INFO] Server stopped gracefully.
pause
exit /b 0