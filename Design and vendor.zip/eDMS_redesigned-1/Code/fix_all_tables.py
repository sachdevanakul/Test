import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'edms.settings')
django.setup()

from django.db import connection

def fix_all_tables():
    print("="*60)
    print("COMPLETE DATABASE FIX FOR ALL TABLES")
    print("="*60)
    
    fixes = {
        'organization_master': [
            ('org_type_id', 'integer'),
            ('website', 'varchar(200)'),
            ('verified', 'boolean DEFAULT false'),
            ('notes', 'text'),
            ('source', "varchar(20) DEFAULT 'MANUAL'"),
            ('created_by_id', 'integer'),
            ('updated_at', 'timestamp with time zone'),
        ],
        'dak_nature_master': [
            ('is_system_defined', 'boolean DEFAULT false'),
            ('source', "varchar(20) DEFAULT 'MANUAL'"),
            ('created_by_id', 'integer'),
            ('updated_at', 'timestamp with time zone'),
        ],
        'person_master': [
            ('created_by_id', 'integer'),
            ('group_id', 'integer'),
            ('is_iig_member', 'boolean DEFAULT false'),
            ('department', 'varchar(100)'),
            ('alternate_contact', 'varchar(15)'),
            ('source', "varchar(20) DEFAULT 'MANUAL'"),
            ('is_primary_contact', 'boolean DEFAULT false'),
            ('notes', 'text'),
            ('updated_at', 'timestamp with time zone'),
        ],
        'group_master': [
            ('source', "varchar(20) DEFAULT 'MANUAL'"),
            ('created_by_id', 'integer'),
            ('updated_at', 'timestamp with time zone'),
        ],
    }
    
    with connection.cursor() as cursor:
        for table, columns in fixes.items():
            print(f"\n📋 Fixing {table}...")
            
            # Get current columns
            cursor.execute(f"SELECT column_name FROM information_schema.columns WHERE table_name='{table}';")
            current = [col[0] for col in cursor.fetchall()]
            
            for col_name, col_type in columns:
                if col_name not in current:
                    try:
                        cursor.execute(f"ALTER TABLE {table} ADD COLUMN {col_name} {col_type};")
                        print(f"  ✓ Added {col_name}")
                    except Exception as e:
                        print(f"  ✗ Error adding {col_name}: {e}")
                else:
                    print(f"  ✓ {col_name} already exists")
    
    print("\n" + "="*60)
    print("✅ All tables fixed!")
    print("="*60)

if __name__ == "__main__":
    fix_all_tables()