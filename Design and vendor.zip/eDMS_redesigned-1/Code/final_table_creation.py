from django.db import connection

print("="*60)
print("CREATING MISSING TABLES DIRECTLY")
print("="*60)

tables_to_create = [
    """
    CREATE TABLE IF NOT EXISTS organization_type_master (
        id SERIAL PRIMARY KEY,
        type_name VARCHAR(100) UNIQUE NOT NULL,
        description TEXT,
        is_active BOOLEAN DEFAULT TRUE,
        is_system_defined BOOLEAN DEFAULT FALSE,
        created_by_id INTEGER,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW(),
        source VARCHAR(20) DEFAULT 'SYSTEM'
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS dak_category_master (
        id SERIAL PRIMARY KEY,
        category_code VARCHAR(20) UNIQUE NOT NULL,
        category_name VARCHAR(100) NOT NULL,
        description TEXT,
        can_have_nature BOOLEAN DEFAULT TRUE,
        can_have_report_details BOOLEAN DEFAULT FALSE,
        can_have_dispatch_details BOOLEAN DEFAULT FALSE,
        is_active BOOLEAN DEFAULT TRUE
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS party_role_master (
        id SERIAL PRIMARY KEY,
        role_code VARCHAR(20) UNIQUE NOT NULL,
        role_name VARCHAR(100) NOT NULL,
        description TEXT,
        is_active BOOLEAN DEFAULT TRUE
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS dispatch_mode_master (
        id SERIAL PRIMARY KEY,
        mode_code VARCHAR(20) UNIQUE NOT NULL,
        mode_name VARCHAR(100) NOT NULL,
        description TEXT,
        is_active BOOLEAN DEFAULT TRUE
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS audit_log (
        id SERIAL PRIMARY KEY,
        user_id INTEGER,
        action VARCHAR(20) NOT NULL,
        entity_type VARCHAR(20) NOT NULL,
        entity_id INTEGER NOT NULL,
        entity_name VARCHAR(200) NOT NULL,
        details JSONB,
        ip_address INET,
        user_agent TEXT,
        created_at TIMESTAMP DEFAULT NOW()
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS system_config (
        id SERIAL PRIMARY KEY,
        config_key VARCHAR(100) UNIQUE NOT NULL,
        config_value TEXT NOT NULL,
        data_type VARCHAR(20) DEFAULT 'STRING',
        description TEXT,
        category VARCHAR(50) DEFAULT 'GENERAL',
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
    );
    """
]

with connection.cursor() as cursor:
    for i, sql in enumerate(tables_to_create):
        try:
            cursor.execute(sql)
            print(f"✓ Created table {i+1}/6")
        except Exception as e:
            print(f"✗ Error on table {i+1}: {str(e)[:50]}")

# Mark migrations as applied
try:
    cursor.execute("""
        INSERT INTO django_migrations (app, name, applied)
        VALUES ('daks', '0001_initial', NOW())
        ON CONFLICT (app, name) DO NOTHING;
    """)
    print("✓ Marked migrations as applied")
except Exception as e:
    print(f"✗ Error marking migrations: {str(e)[:50]}")

print("="*60)
print("✅ COMPLETE - Now verify tables")
print("="*60)
exit()