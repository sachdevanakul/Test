@echo off
echo ================================
echo   eDMS - Force Create All Tables
echo ================================
echo.

cd /d C:\eDMS_Project\Code
call venv\Scripts\activate

echo Step 1: Resetting migrations...
python manage.py migrate daks zero

echo Step 2: Deleting migration files...
del /q daks\migrations\*.py 2>nul
echo # > daks\migrations\__init__.py

echo Step 3: Creating fresh migrations...
python manage.py makemigrations daks

echo Step 4: Applying migrations with fake...
python manage.py migrate daks --fake-initial

echo Step 5: Running syncdb to force create...
python manage.py migrate daks --run-syncdb

echo.
echo Step 6: Verifying tables in PostgreSQL...
python manage.py dbshell -c "\dt" 2>nul

echo.
echo Step 7: Check if organization_type_master exists now...
python manage.py shell -c "
from daks.models import OrganizationTypeMaster
try:
    OrganizationTypeMaster.objects.exists()
    print('✓ organization_type_master exists!')
except:
    print('✗ organization_type_master still missing')
"

echo.
echo Done! Now try loading system data again.
pause