@echo off
echo ================================
echo   eDMS - Fix Missing Tables
echo ================================
echo.

cd /d C:\eDMS_Project\Code
call venv\Scripts\activate

echo Step 1: Resetting migrations...
python manage.py migrate daks zero

echo Step 2: Deleting old migration files...
del /q daks\migrations\*.py
echo # > daks\migrations\__init__.py

echo Step 3: Creating fresh migrations...
python manage.py makemigrations daks

echo Step 4: Applying migrations...
python manage.py migrate daks

echo.
echo Step 5: Verifying tables...
python manage.py shell -c "
from daks.models import *
print('Tables created:')
for model in [OrganizationTypeMaster, DakCategoryMaster, PartyRoleMaster, 
              DispatchModeMaster, AuditLog, SystemConfig]:
    try:
        model.objects.exists()
        print(f'✓ {model.__name__} - OK')
    except:
        print(f'✗ {model.__name__} - MISSING')
"

echo.
echo Done! Now run the data loading script again.
pause