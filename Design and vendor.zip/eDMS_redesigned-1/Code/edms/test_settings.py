"""
Test-only settings — runs everything against a throwaway SQLite database
instead of your real Postgres database, so these tests can NEVER touch
or risk your production data, and don't need any special database
privileges (creating Postgres's own test database normally requires the
CREATEDB privilege, which edms_app/edms_admin intentionally don't have
for security reasons — SQLite has no such restriction).

Usage:
    DJANGO_SETTINGS_MODULE=edms.test_settings python manage.py test daks.test_system_checks
"""
import os
os.environ.setdefault('DB_PASSWORD', 'unused-sqlite-tests-dont-need-this')
from .settings import *

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': ':memory:',
    }
}
CACHES = {
    'default': {'BACKEND': 'django.core.cache.backends.locmem.LocMemCache'}
}
DEBUG = True
ALLOWED_HOSTS = ['*']
