import os

for root, dirs, files in os.walk('.'):
    for file in files:
        if file.endswith('.py'):
            path = os.path.join(root, file)
            try:
                with open(path, 'rb') as f:
                    if b'\x00' in f.read():
                        print("NULL BYTES FOUND:", path)
            except:
                pass