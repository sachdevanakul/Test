"""
eTOT Module — Transfer of Technology Views
"""
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.http import HttpResponse, JsonResponse
from django.db.models import Q, Count, Sum
from django.db import transaction
from .models import (
    eTOT, eTOTDakLink, GroupMaster, OrganizationMaster,
    PersonMaster, DakMaster, DakPartyMapping, DakGroupMapping
)
from .forms import eTOTForm, eTOTDakLinkForm
import pandas as pd
from io import BytesIO
from decimal import Decimal


# ─────────────────────────────────────────────────────────────────────────────
# HELPER: Build graph context data for eTOT form
# ─────────────────────────────────────────────────────────────────────────────

def _etot_graph_context():
    """
    Returns aggregated stats for all tab graphs in etot_form.html.
    All values default to 0 so the template never breaks.
    """
    qs = eTOT.objects.all()

    # Basic tab — stage counts
    stage_counts = {}
    for stage, _ in eTOT.STAGE_CHOICES:
        stage_counts[stage] = qs.filter(stage=stage).count()

    # Technology category counts
    tot_cat = {
        'A': qs.filter(technology_category='A').count(),
        'B': qs.filter(technology_category='B').count(),
    }

    # TNF tab
    tot_tnf = {
        'initiated':  qs.exclude(tnf_initiated_by_group_on__isnull=True).count(),
        'certified':  qs.exclude(tnf_certificate_issued_by_director_on__isnull=True).count(),
        'allotted':   qs.exclude(tnf_no_allotted_by_diitm_on__isnull=True).count(),
    }

    # EOI tab
    tot_eoi = {
        'published': qs.exclude(eoi_hosting_on_portal__isnull=True).count(),
        'pending':   qs.filter(eoi_hosting_on_portal__isnull=True).count(),
    }

    # CEC tab
    tot_cec = {
        'constituted': qs.exclude(cec_constitution_on__isnull=True).count(),
        'meeting':     qs.exclude(cec_meeting_held_on__isnull=True).count(),
        'signed':      qs.exclude(cec_report_signed_by_chairman_on__isnull=True).count(),
        'approved':    qs.exclude(cec_approved_by_dg_pc_s7_on__isnull=True).count(),
    }

    # TAC tab
    tot_tac = {
        'constituted': qs.exclude(tac_constitution_by_dir_dg_mss_on__isnull=True).count(),
        'meeting':     qs.exclude(tac1_meeting_held_on__isnull=True).count(),
        'approved':    qs.exclude(tac1_report_approved_by_dg_mss_on__isnull=True).count(),
        'forwarded':   qs.exclude(tac1_report_forwarded_to_diitm_on__isnull=True).count(),
    }

    # LAToT tab
    fee_agg = qs.aggregate(
        total_fee=Sum('tot_fee_paid_by_licensee'),
        total_royalty=Sum('royalty_fee_received'),
    )
    tot_latot = {
        'shared':          qs.exclude(vetted_latot_shared_with_industry_on__isnull=True).count(),
        'received':        qs.exclude(signed_stamped_latot_received_on__isnull=True).count(),
        'fee_paid':        qs.exclude(tot_fee_paid_on__isnull=True).count(),
        'signed':          qs.exclude(latot_signed_on__isnull=True).count(),
        'royalty_received': float(fee_agg['total_royalty'] or 0),
        'royalty_pending':  qs.filter(royalty_fee_received__isnull=True).count(),
    }

    # TTD tab
    tot_ttd = {
        'issued':     qs.exclude(ttd_issued_on__isnull=True).count(),
        'absorption': qs.exclude(tot_absorption_request_received_on__isnull=True).count(),
        'ta_rec':     qs.exclude(director_tbrl_recommendation_for_ta_on__isnull=True).count(),
    }

    # TA Certificate tab
    tot_ta = {
        'issued':  qs.exclude(ta_certificate_issued_on__isnull=True).count(),
        'pending': qs.filter(ta_certificate_issued_on__isnull=True).count(),
    }

    return {
        'tot_stage_counts': stage_counts,
        'tot_cat':          tot_cat,
        'tot_tnf':          tot_tnf,
        'tot_eoi':          tot_eoi,
        'tot_cec':          tot_cec,
        'tot_tac':          tot_tac,
        'tot_latot':        tot_latot,
        'tot_ttd':          tot_ttd,
        'tot_ta':           tot_ta,
    }


# ─────────────────────────────────────────────────────────────────────────────
# HELPER: Auto-populate eTOT fields from a linked DakMaster
# ─────────────────────────────────────────────────────────────────────────────

def _sync_etot_from_dak(etot_obj, dak_obj):
    changed = False

    if not etot_obj.technical_group_id:
        grp = dak_obj.testing_group_id or DakGroupMapping.objects.filter(dak=dak_obj).values_list('group_id', flat=True).first()
        if grp:
            etot_obj.technical_group_id = grp
            changed = True

    if not etot_obj.licensee_company_id:
        sender = (
            DakPartyMapping.objects
            .filter(dak=dak_obj, party_role__role_code='SENDER')
            .select_related('organization', 'person__organization')
            .first()
        )
        if sender:
            org_id = (
                sender.organization_id
                or (sender.person.organization_id if sender.person else None)
            )
            if org_id:
                etot_obj.licensee_company_id = org_id
                changed = True

    if not etot_obj.meeting_held_on and dak_obj.issue_date:
        etot_obj.meeting_held_on = dak_obj.issue_date
        changed = True

    return changed


# ─────────────────────────────────────────────────────────────────────────────
# DASHBOARD
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def etot_dashboard(request):

    # ── Module access guard ──────────────────────────────────────
    if not request.user.is_staff:
        from .models import UserProfile
        try:
            profile = request.user.profile
        except UserProfile.DoesNotExist:
            profile = UserProfile.objects.create(user=request.user)
        if not getattr(profile, 'can_access_etot', False):
            from django.contrib import messages as _msg
            _msg.error(request, 'You do not have permission to access this module.')
            return redirect('daks:home')
    # ─────────────────────────────────────────────────────────────
    qs = (
        eTOT.objects.all()
        .select_related('technical_group', 'point_of_contact', 'licensee_company', 'created_by')
        .prefetch_related('dak_links')
        .order_by('-created_at')
    )

    search_query = request.GET.get('search', '').strip()
    if search_query:
        qs = qs.filter(
            Q(tot_file_no__icontains=search_query) |
            Q(product_technology__icontains=search_query) |
            Q(licensee_name__icontains=search_query) |
            Q(licensee_company__org_name__icontains=search_query) |
            Q(latot_no__icontains=search_query) |
            Q(ttd_no__icontains=search_query) |
            Q(ta_certificate_no__icontains=search_query)
        )

    stage_filter = request.GET.get('stage', '').strip()
    if stage_filter:
        qs = qs.filter(stage=stage_filter)

    group_filter = request.GET.get('group', '').strip()
    if group_filter:
        qs = qs.filter(technical_group_id=group_filter)

    category_filter = request.GET.get('category', '').strip()
    if category_filter:
        qs = qs.filter(technology_category=category_filter)

    stats = qs.aggregate(
        total=Count('id'),
        total_fee=Sum('tot_fee_paid_by_licensee'),
        total_royalty=Sum('royalty_fee_received'),
        total_licenses=Sum('total_no_of_awarded_licenses'),
    )
    stage_counts = {}
    for stage, _ in eTOT.STAGE_CHOICES:
        stage_counts[stage] = qs.filter(stage=stage).count()

    # List of (val, label, count) tuples — Django templates cannot do dict[var]
    # lookups so we flatten the data here for clean template access.
    stage_counts_list = [
        (val, label, stage_counts.get(val, 0))
        for val, label in eTOT.STAGE_CHOICES
    ]

    paginator = Paginator(qs, 50)
    try:
        page_obj = paginator.page(request.GET.get('page', 1))
    except (PageNotAnInteger, EmptyPage):
        page_obj = paginator.page(1)

    groups = list(GroupMaster.objects.filter(is_active=True).values('id', 'group_name').order_by('group_name'))

    from .dynamic_columns import prefetch_extra_col_values
    extra_cols = prefetch_extra_col_values('etot', page_obj.object_list)

    context = {
        'page_obj': page_obj,
        'total_count': stats['total'] or 0,
        'search_query': search_query,
        'stage_filter': stage_filter,
        'group_filter': group_filter,
        'category_filter': category_filter,
        'groups': groups,
        'stage_choices': eTOT.STAGE_CHOICES,
        'stage_counts_list': stage_counts_list,
        'total_fee': stats['total_fee'] or Decimal('0'),
        'total_royalty': stats['total_royalty'] or Decimal('0'),
        'total_licenses': stats['total_licenses'] or 0,
        'stage_counts': stage_counts,
        'extra_cols': extra_cols,
    }
    return render(request, 'daks/etot_dashboard.html', context)


# ─────────────────────────────────────────────────────────────────────────────
# DETAIL
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def etot_detail(request, public_id):
    record = get_object_or_404(
        eTOT.objects.select_related(
            'technical_group', 'point_of_contact',
            'licensee_company', 'created_by'
        ).prefetch_related('dak_links__dak'),
        public_id=public_id
    )
    from .edw_views import _extra_col_context
    link_form = eTOTDakLinkForm()
    context = {
        'record': record,
        'dak_links': record.dak_links.all().select_related('dak'),
        'link_form': link_form,
        'extra_cols': _extra_col_context('etot', record.pk),
    }
    return render(request, 'daks/etot_detail.html', context)


# ─────────────────────────────────────────────────────────────────────────────
# CREATE
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def etot_create(request):
    if request.method == 'POST':
        form = eTOTForm(request.POST)
        if form.is_valid():
            with transaction.atomic():
                etot = form.save(commit=False)
                etot.created_by = request.user
                etot.save()
                form.save_extra_fields(etot)
            messages.success(request, f'eTOT record {etot.tot_file_no} created successfully!')
            return redirect('daks:etot_detail', public_id=etot.public_id)
    else:
        form = eTOTForm()

    ctx = {
        'form': form,
        'title': 'Create eTOT Record',
        'groups': GroupMaster.objects.filter(is_active=True).order_by('group_name'),
    }
    ctx.update(_etot_graph_context())
    return render(request, 'daks/etot_form.html', ctx)


# ─────────────────────────────────────────────────────────────────────────────
# EDIT
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def etot_edit(request, public_id):
    record = get_object_or_404(eTOT, public_id=public_id)
    from .edw_views import _extra_col_context, _save_extra_cols
    if request.method == 'POST':
        form = eTOTForm(request.POST, instance=record)
        if form.is_valid():
            with transaction.atomic():
                etot = form.save()
                form.save_extra_fields(etot)
            messages.success(request, f'eTOT record {record.tot_file_no} updated successfully!')
            return redirect('daks:etot_detail', public_id=record.public_id)
    else:
        form = eTOTForm(instance=record)

    ctx = {
        'form': form,
        'title': f'Edit eTOT — {record.tot_file_no}',
        'record': record,
        'extra_cols': _extra_col_context('etot', record.pk),
        'groups': GroupMaster.objects.filter(is_active=True).order_by('group_name'),
    }
    ctx.update(_etot_graph_context())
    return render(request, 'daks/etot_form.html', ctx)


# ─────────────────────────────────────────────────────────────────────────────
# LINK / UNLINK DAK
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def etot_link_dak(request, public_id):
    record = get_object_or_404(eTOT, public_id=public_id)
    if request.method == 'POST':
        form = eTOTDakLinkForm(request.POST)
        if form.is_valid():
            link = form.save(commit=False)
            link.etot = record
            try:
                link.save()
                messages.success(request, f'Dak {link.dak.dak_index_no} linked successfully!')
            except Exception:
                messages.error(request, 'This Dak is already linked to this eTOT record.')
        else:
            messages.error(request, 'Invalid form. Please check the fields.')
    return redirect('daks:etot_detail', public_id=public_id)


@login_required
def etot_unlink_dak(request, public_id, link_pk):
    record = get_object_or_404(eTOT, public_id=public_id)
    link = get_object_or_404(eTOTDakLink, pk=link_pk, etot=record)
    dak_no = link.dak.dak_index_no
    link.delete()
    messages.success(request, f'Dak {dak_no} unlinked successfully.')
    return redirect('daks:etot_detail', public_id=public_id)


# ─────────────────────────────────────────────────────────────────────────────
# EXPORT
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def etot_export_excel(request):
    qs = eTOT.objects.all().select_related(
        'technical_group', 'point_of_contact', 'licensee_company', 'created_by'
    ).order_by('-created_at')

    if request.GET.get('search'):
        q = request.GET['search'].strip()
        qs = qs.filter(
            Q(tot_file_no__icontains=q) |
            Q(product_technology__icontains=q) |
            Q(licensee_name__icontains=q)
        )
    if request.GET.get('stage'):
        qs = qs.filter(stage=request.GET['stage'])
    if request.GET.get('group'):
        qs = qs.filter(technical_group_id=request.GET['group'])

    from .report_columns import get_default_columns
    from .reports import generate_module_excel_report
    columns = get_default_columns('etot')
    return generate_module_excel_report(qs, columns, 'eTOT_Records')


# ─────────────────────────────────────────────────────────────────────────────
# ADMIN-ONLY HARD DELETE
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def etot_delete(request, public_id):
    """Superuser-only: permanently delete an eTOT record and all related data."""
    if not request.user.is_superuser:
        messages.error(request, 'Only superusers can delete eTOT records.')
        return redirect('daks:etot_detail', public_id=public_id)

    record = get_object_or_404(eTOT, public_id=public_id)

    if request.method == 'POST':
        identifier = record.tot_file_no
        record.delete()
        messages.success(request, f'eTOT record "{identifier}" permanently deleted.')
        return redirect('daks:etot_dashboard')

    return render(request, 'daks/etot_confirm_delete.html', {'record': record})



