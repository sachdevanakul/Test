"""
Report Views for eDMS
Handles report generation requests
"""

from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from datetime import datetime, timedelta
from .models import *
from .reports import *

@login_required
def report_dashboard(request):
    # ── Module access guard ──────────────────────────────────────
    if not request.user.is_staff:
        from .models import UserProfile
        try:
            profile = request.user.profile
        except UserProfile.DoesNotExist:
            profile = UserProfile.objects.create(user=request.user)
        if not getattr(profile, 'can_access_reports', False):
            from django.contrib import messages as _msg
            _msg.error(request, 'You do not have permission to access this module.')
            return redirect('daks:home')
    # ─────────────────────────────────────────────────────────────
    """Report selection dashboard with statistics and category list."""
    total_daks    = DakMaster.objects.filter(is_active=True).count()
    # Resolved = any reply was sent (MAIL, LETTER, or ION)
    resolved_daks = DakMaster.objects.filter(
        is_active=True
    ).exclude(reply_mode='NOT_YET').count()
    pending_daks  = DakMaster.objects.filter(is_active=True, reply_mode='NOT_YET').count()
    total_threads = DakThread.objects.count()
    categories    = DakCategoryMaster.objects.filter(is_active=True).order_by('category_name')

    from .report_columns import DATE_FIELDS

    return render(request, 'daks/report_dashboard.html', {
        'total_daks':    total_daks,
        'resolved_daks': resolved_daks,
        'pending_daks':  pending_daks,
        'total_threads': total_threads,
        'categories':    categories,
        'module_report_list': [
            ('edw', 'eDW', 'fa-coins'),
            ('etot', 'eToT', 'fa-sync-alt'),
            ('eiig', 'eIIG', 'fa-microscope'),
        ],
        'date_fields': DATE_FIELDS,
    })

@login_required
def generate_daily_report(request):
    """Generate daily report"""
    today = datetime.now().date()
    format_type = request.GET.get('format', 'excel')
    report_title = request.GET.get('report_title', '').strip() or 'Daily Dak Report'
    date_field = request.GET.get('date_field', '').strip() or 'basis_date'
    
    data = get_report_data(today, today, date_field=date_field)
    
    if format_type == 'excel':
        return generate_excel_report(data, report_title, date_field=date_field)
    elif format_type == 'csv':
        return generate_csv_report(data, report_title, date_field=date_field)
    elif format_type == 'pdf':
        classification, signatories, placement = parse_report_extras(request.GET)
        return generate_pdf_report(data, report_title, today, today,
                                    classification=classification, signatories=signatories, signature_placement=placement, date_field=date_field)
    
    return HttpResponse("Invalid format", status=400)

@login_required
def generate_monthly_report(request):
    """Generate monthly report"""
    today = datetime.now().date()
    start_date = today.replace(day=1)
    format_type = request.GET.get('format', 'excel')
    report_title = request.GET.get('report_title', '').strip() or 'Monthly Dak Report'
    date_field = request.GET.get('date_field', '').strip() or 'basis_date'
    
    data = get_report_data(start_date, today, date_field=date_field)
    
    if format_type == 'excel':
        return generate_excel_report(data, report_title, date_field=date_field)
    elif format_type == 'csv':
        return generate_csv_report(data, report_title, date_field=date_field)
    elif format_type == 'pdf':
        classification, signatories, placement = parse_report_extras(request.GET)
        return generate_pdf_report(data, report_title, start_date, today,
                                    classification=classification, signatories=signatories, signature_placement=placement, date_field=date_field)
    
    return HttpResponse("Invalid format", status=400)

@login_required
def generate_range_report(request):
    """Generate a report for a user-chosen start/end date"""
    format_type = request.GET.get('format', 'excel')
    start_str = request.GET.get('start_date', '')
    end_str = request.GET.get('end_date', '')
    report_title = request.GET.get('report_title', '').strip() or 'Custom Range Dak Report'
    date_field = request.GET.get('date_field', '').strip() or 'basis_date'

    try:
        start_date = datetime.strptime(start_str, '%Y-%m-%d').date()
        end_date = datetime.strptime(end_str, '%Y-%m-%d').date()
    except ValueError:
        return HttpResponse("Please provide valid start_date and end_date (YYYY-MM-DD).", status=400)

    if start_date > end_date:
        return HttpResponse("start_date must be before end_date.", status=400)

    data = get_report_data(start_date, end_date, date_field=date_field)

    if format_type == 'excel':
        return generate_excel_report(data, report_title, date_field=date_field)
    elif format_type == 'csv':
        return generate_csv_report(data, report_title, date_field=date_field)
    elif format_type == 'pdf':
        classification, signatories, placement = parse_report_extras(request.GET)
        return generate_pdf_report(data, report_title, start_date, end_date,
                                    classification=classification, signatories=signatories, signature_placement=placement, date_field=date_field)

    return HttpResponse("Invalid format", status=400)

@login_required
def generate_module_quick_report(request, module_key):
    """One-click report for a module (eDW/eToT/eIIG)"""
    from .models import UserProfile
    from .report_columns import MODULE_REGISTRY, get_default_columns, _label_from_field_name

    info = MODULE_REGISTRY.get(module_key)
    if not info:
        return HttpResponse('Unknown module.', status=404)

    if not request.user.is_staff:
        try:
            profile = request.user.profile
        except UserProfile.DoesNotExist:
            profile = UserProfile.objects.create(user=request.user)
        if not getattr(profile, f'can_access_{module_key}', False):
            from django.contrib import messages as _msg
            _msg.error(request, 'You do not have permission to access this module.')
            return redirect('daks:home')

    start_str = request.GET.get('start_date', '').strip()
    end_str = request.GET.get('end_date', '').strip()
    start_date = end_date = None
    if start_str:
        try:
            start_date = datetime.strptime(start_str, '%Y-%m-%d').date()
        except ValueError:
            pass
    if end_str:
        try:
            end_date = datetime.strptime(end_str, '%Y-%m-%d').date()
        except ValueError:
            pass
    fmt = request.GET.get('format', 'pdf').lower()
    report_title = request.GET.get('report_title', '').strip() or f"{info['label']} Report"
    date_field = request.GET.get('date_field', '').strip()
    if not date_field:
        date_field = 'created_at' if module_key in ('edw', 'etot') else 'date_of_visit'

    queryset = get_module_report_data(module_key, start_date, end_date, date_field=date_field)
    columns = get_default_columns(module_key)

    # Prepend referencing date to columns list
    all_columns = {c['key']: c for c in info['columns']}
    date_col = all_columns.get(date_field)
    if not date_col:
        date_col = {
            'key': date_field,
            'label': _label_from_field_name(date_field),
            'accessor': date_field
        }
    columns = [c for c in columns if c['key'] != date_field]
    columns.insert(0, date_col)

    if fmt == 'xlsx':
        return generate_module_excel_report(queryset, columns, report_title)
    elif fmt == 'csv':
        return generate_module_csv_report(queryset, columns, report_title)
    elif fmt == 'docx':
        return generate_module_docx_report(queryset, columns, report_title)
    else:
        classification, signatories, placement = parse_report_extras(request.GET)
        return generate_module_pdf_report(queryset, columns, report_title, start_date=start_date, end_date=end_date,
                                           classification=classification, signatories=signatories, signature_placement=placement)

@login_required
def report_builder(request):
    """Column-picker report builder (#21)"""
    if not request.user.is_staff:
        from django.contrib import messages as _msg
        _msg.error(request, 'You do not have permission to access this module.')
        return redirect('daks:home')

    from .report_columns import MODULE_REGISTRY, DATE_FIELDS
    modules = {
        key: {
            'label': info['label'],
            'columns': info['columns'],
            'date_fields': [{'val': f[0], 'lbl': f[1]} for f in DATE_FIELDS.get(key, [])]
        }
        for key, info in MODULE_REGISTRY.items()
    }
    return render(request, 'daks/report_builder.html', {'modules_json': modules})

@login_required
def generate_module_report(request):
    """Generate the report builder's export."""
    if not request.user.is_staff:
        return HttpResponse("Staff access required.", status=403)
    if request.method != 'POST':
        return HttpResponse("POST required.", status=405)

    from .report_columns import MODULE_REGISTRY, _label_from_field_name

    module_key = request.POST.get('module')
    format_type = request.POST.get('format', 'pdf')
    selected_keys = request.POST.getlist('columns')
    watermark_text = request.POST.get('watermark', 'IIG-DCMM').strip() or None
    report_title = request.POST.get('report_title', '').strip() or None
    date_field = request.POST.get('date_field', '').strip()
    if not date_field:
        date_field = 'created_at' if module_key in ('edw', 'etot') else 'date_of_visit'

    info = MODULE_REGISTRY.get(module_key)
    if not info:
        return HttpResponse("Unknown module.", status=400)

    all_columns = {c['key']: c for c in info['columns']}
    columns = [all_columns[k] for k in selected_keys if k in all_columns]
    if not columns:
        return HttpResponse("Select at least one column.", status=400)

    queryset = info['model'].objects.all()

    start_date = end_date = None
    start_str = request.POST.get('start_date', '').strip()
    end_str = request.POST.get('end_date', '').strip()
    if start_str and end_str:
        try:
            start_date = datetime.strptime(start_str, '%Y-%m-%d').date()
            end_date = datetime.strptime(end_str, '%Y-%m-%d').date()
            is_datetime = (date_field in ('created_at', 'updated_at'))
            suffix = '__date' if is_datetime else ''
            queryset = queryset.filter(**{
                f"{date_field}{suffix}__gte": start_date,
                f"{date_field}{suffix}__lte": end_date
            })
        except ValueError:
            start_date = end_date = None

    queryset = queryset.order_by(date_field)

    # Prepend referencing date to columns list
    date_col = all_columns.get(date_field)
    if not date_col:
        date_col = {
            'key': date_field,
            'label': _label_from_field_name(date_field),
            'accessor': date_field
        }
    columns = [c for c in columns if c['key'] != date_field]
    columns.insert(0, date_col)

    title = report_title or f"{info['label']} Report"
    classification, signatories, placement = parse_report_extras(request.POST)

    if format_type == 'docx':
        return generate_module_docx_report(queryset, columns, title, watermark_text)
    return generate_module_pdf_report(queryset, columns, title, watermark_text, start_date, end_date,
                                       classification=classification, signatories=signatories, signature_placement=placement)

@login_required
def generate_category_report(request):
    """Generate category-wise report"""
    category = request.GET.get('category')
    format_type = request.GET.get('format', 'excel')
    report_title = request.GET.get('report_title', '').strip()
    date_field = request.GET.get('date_field', '').strip() or 'basis_date'
    today = datetime.now().date()
    start_date = today.replace(day=1)
    
    data = get_report_data(start_date, today, category=category, date_field=date_field)
    
    category_name = category if category else 'All'
    title = report_title or f'Category_{category_name}_Report'
    
    if format_type == 'excel':
        return generate_excel_report(data, title, date_field=date_field)
    elif format_type == 'csv':
        return generate_csv_report(data, title, date_field=date_field)
    elif format_type == 'pdf':
        classification, signatories, placement = parse_report_extras(request.GET)
        title_pdf = report_title or f'Category {category_name} Report'
        return generate_pdf_report(data, title_pdf, start_date, today,
                                    classification=classification, signatories=signatories, signature_placement=placement, date_field=date_field)
    
    return HttpResponse("Invalid format", status=400)

@login_required
def generate_pending_report(request):
    """Generate pending daks report"""
    format_type = request.GET.get('format', 'excel')
    report_title = request.GET.get('report_title', '').strip()
    
    data = DakMaster.objects.filter(
        is_active=True,
        reply_mode='NOT_YET'
    ).select_related(
        'dak_category', 'nature', 'thread', 'created_by', 'receiver_org', 'testing_group'
    ).prefetch_related(
        'party_mappings__organization', 'party_mappings__person__organization', 'party_mappings__party_role',
        'group_mappings__group'
    ).order_by('created_on')
    
    title = report_title or 'Pending_Daks_Report'
    title_pdf = report_title or 'Pending Daks Report'
    
    if format_type == 'excel':
        return generate_excel_report(data, title)
    elif format_type == 'csv':
        return generate_csv_report(data, title)
    elif format_type == 'pdf':
        today = datetime.now().date()
        classification, signatories, placement = parse_report_extras(request.GET)
        return generate_pdf_report(data, title_pdf, today, today,
                                    classification=classification, signatories=signatories, signature_placement=placement)
    
    return HttpResponse("Invalid format", status=400)

@login_required
def generate_thread_report(request):
    """Generate thread summary report"""
    format_type = request.GET.get('format', 'excel')
    report_title = request.GET.get('report_title', '').strip()
    
    threads = DakThread.objects.all().order_by('-last_activity')
    
    # Convert to list for report
    data = []
    for thread in threads:
        data.append({
            'thread_code': thread.thread_code,
            'subject_summary': thread.subject_summary[:100],
            'status': thread.status,
            'dak_count': thread.dak_count,
            'created_on': thread.created_on,
            'last_activity': thread.last_activity
        })
    
    title = report_title or 'Thread_Summary_Report'
    
    if format_type == 'excel':
        return generate_thread_excel(data, title)
    elif format_type == 'csv':
        return generate_thread_csv(data, title)
    
    return HttpResponse("Invalid format", status=400)

def generate_thread_excel(data, title):
    """Generate Excel for thread report"""
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment
    
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = title[:31]
    
    headers = ['S.No', 'Thread Code', 'Subject', 'Status', 'Total Daks', 'Created On', 'Last Activity']
    
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
    
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center')
    
    for row_idx, item in enumerate(data, 2):
        ws.cell(row=row_idx, column=1, value=row_idx-1)
        ws.cell(row=row_idx, column=2, value=item['thread_code'])
        ws.cell(row=row_idx, column=3, value=item['subject_summary'])
        ws.cell(row=row_idx, column=4, value=item['status'])
        ws.cell(row=row_idx, column=5, value=item['dak_count'])
        ws.cell(row=row_idx, column=6, value=item['created_on'].strftime('%d-%b-%Y'))
        ws.cell(row=row_idx, column=7, value=item['last_activity'].strftime('%d-%b-%Y %H:%M'))
    
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = f'attachment; filename="{title}_{datetime.now().strftime("%Y%m%d")}.xlsx"'
    wb.save(response)
    return response

def generate_thread_csv(data, title):
    """Generate CSV for thread report"""
    import csv
    
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="{title}_{datetime.now().strftime("%Y%m%d")}.csv"'
    
    writer = csv.writer(response)
    writer.writerow(['S.No', 'Thread Code', 'Subject', 'Status', 'Total Daks', 'Created On', 'Last Activity'])
    
    for idx, item in enumerate(data, 1):
        writer.writerow([
            idx, item['thread_code'], item['subject_summary'], item['status'],
            item['dak_count'], item['created_on'].strftime('%d-%b-%Y'),
            item['last_activity'].strftime('%d-%b-%Y %H:%M')
        ])
    
    return response