"""
Reporting Module for eDMS
Generates PDF, Excel, and CSV reports
"""

import pandas as pd
from io import BytesIO
from datetime import datetime, timedelta, date
from django.http import HttpResponse
from django.db.models import Count, Q
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, landscape
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.pdfgen import canvas as _canvas
import os
from django.conf import settings as _dj_settings
from .models import *

# ── Official DRDO / TBRL report template ────────────────────────────
# Matches the approved I2G-DCMM report format exactly: double border
# frame, RESTRICTED markings, DRDO/TBRL crest, I2G box, centered title
# block, a "Report / Period" line, and a footer with copyright, page
# count, and a generation timestamp. Used by every PDF report in the
# system (Dak reports and the eDW/eToT/eIIG module reports) via the two
# functions below, so every report in eDMS looks the same.

REPORT_BORDER_BLUE = colors.Color(0x0B / 255, 0x1F / 255, 0x73 / 255)
REPORT_RED = colors.Color(0xE1 / 255, 0x12 / 255, 0x12 / 255)
REPORT_HEADER_GRAY = colors.Color(0xEC / 255, 0xEC / 255, 0xEC / 255)

_DRDO_LOGO_PATH = os.path.join(_dj_settings.BASE_DIR, 'static', 'img', 'drdo_tbrl_logo.png')
_I2G_BOX_PATH = os.path.join(_dj_settings.BASE_DIR, 'static', 'img', 'i2g_box.png')


class NumberedCanvas(_canvas.Canvas):
    """Standard ReportLab two-pass pattern for 'Page X of Y' — the total
    page count isn't known until the whole document has been laid out,
    so each page's content is buffered and only actually drawn once
    save() is called and the final count is known.

    Also draws the signature block here, not in draw_official_report_frame
    — 'only on the last page' is only knowable in this second pass, since
    during the first pass (when onFirstPage/onLaterPages fire) there's no
    way to know yet whether the current page will turn out to be the last
    one."""

    def __init__(self, *args, signatories=None, signature_placement='last_page', **kwargs):
        _canvas.Canvas.__init__(self, *args, **kwargs)
        self._saved_page_states = []
        self._signatories = signatories or []
        self._signature_placement = signature_placement

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        total_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self._draw_page_count(total_pages)
            if self._signatories and (
                self._signature_placement == 'every_page'
                or self._pageNumber == total_pages
            ):
                self._draw_signature_block()
            _canvas.Canvas.showPage(self)
        _canvas.Canvas.save(self)

    def _draw_page_count(self, total_pages):
        page_w, page_h = self._pagesize
        self.setFont('Helvetica', 9)
        self.setFillColor(colors.black)
        self.drawCentredString(page_w / 2, 0.27 * inch, f"Page {self._pageNumber} of {total_pages}")


    def _draw_signature_block(self):
        """One evenly-spaced column per signatory, left to right in the
        order given (so the highest rank — entered first — ends up
        leftmost, as specified). Each column: a signature line, then
        Name / Rank / Designation underneath."""
        page_w, page_h = self._pagesize
        n = len(self._signatories)
        left_margin, right_margin = 0.40 * inch, 0.40 * inch
        usable_width = page_w - left_margin - right_margin
        col_width = usable_width / n
        line_y = 1.18 * inch

        self.saveState()
        for i, sig in enumerate(self._signatories):
            col_center = left_margin + col_width * i + col_width / 2
            self.setStrokeColor(colors.black)
            self.setLineWidth(0.75)
            self.line(col_center - 0.95 * inch, line_y, col_center + 0.95 * inch, line_y)

            self.setFont('Times-Bold', 9)
            self.setFillColor(colors.black)
            self.drawCentredString(col_center, line_y - 0.16 * inch, sig.get('name', ''))
            self.setFont('Times-Roman', 8)
            self.drawCentredString(col_center, line_y - 0.32 * inch, sig.get('rank', ''))
            self.drawCentredString(col_center, line_y - 0.48 * inch, sig.get('designation', ''))
        self.restoreState()


def draw_official_report_frame(canvas_obj, doc, report_name, start_date=None, end_date=None, classification='RESTRICTED'):
    """Draws the official report frame on the current page: border,
    classification markings, crest, title block, Report/Period line, and
    footer. Called for every page via onFirstPage/onLaterPages.

    classification is whatever the person generating the report selected
    (RESTRICTED / CONFIDENTIAL / SECRET / etc.) — drawn in exactly the
    same place, same styling, top and bottom, regardless of which word
    it is."""
    canvas_obj.saveState()
    page_w, page_h = doc.pagesize
    classification = (classification or 'RESTRICTED').upper()

    # ── Double border frame (MODIFIED: Removed outer thick border, keeping only inner thin border) ─────────────────
    canvas_obj.setStrokeColor(REPORT_BORDER_BLUE)
    canvas_obj.setLineWidth(0.75)
    canvas_obj.rect(0.22 * inch, 0.22 * inch, page_w - 0.44 * inch, page_h - 0.44 * inch)

    # ── Classification (top) (MODIFIED: Underlined) ──────────────────────────────────────────
    canvas_obj.setFont('Helvetica-Bold', 13)
    canvas_obj.setFillColor(REPORT_RED)
    canvas_obj.drawCentredString(page_w / 2, page_h - 0.42 * inch, classification)
    class_w = canvas_obj.stringWidth(classification, 'Helvetica-Bold', 13)
    canvas_obj.setStrokeColor(REPORT_RED)
    canvas_obj.setLineWidth(1)
    canvas_obj.line(page_w / 2 - class_w / 2, page_h - 0.45 * inch, page_w / 2 + class_w / 2, page_h - 0.45 * inch)

    # ── Crest (left) and I2G box (right) (MODIFIED: Uplifted) ─────────────────────────────
    logo_size = 0.78 * inch
    try:
        canvas_obj.drawImage(_DRDO_LOGO_PATH, 0.35 * inch, page_h - 1.15 * inch,
                              width=logo_size, height=logo_size, mask='auto')
    except Exception:
        pass
    try:
        canvas_obj.drawImage(_I2G_BOX_PATH, page_w - 1.55 * inch, page_h - 0.90 * inch,
                              width=1.15 * inch, height=0.58 * inch, mask='auto')
    except Exception:
        pass

    # ── Title block (center) (MODIFIED: Included Director's Email) ─────────────────────────
    canvas_obj.setFillColor(colors.black)
    canvas_obj.setFont('Times-Bold', 15)
    canvas_obj.drawCentredString(page_w / 2, page_h - 0.62 * inch, 'TERMINAL BALLISTICS RESEARCH LABORATORY')
    canvas_obj.setFont('Times-Roman', 10.5)
    canvas_obj.drawCentredString(page_w / 2, page_h - 0.80 * inch, 'Sector-30, Chandigarh - 160030  |  Email: director.tbrl@gov.in')
    canvas_obj.setFont('Times-Bold', 10.5)
    canvas_obj.drawCentredString(page_w / 2, page_h - 0.98 * inch, 'Dte of Control Materials & Management (DCMM)')
    canvas_obj.drawCentredString(page_w / 2, page_h - 1.15 * inch, 'Industry Interface Group (I2G)')

    # ── Divider under header ──────────────────────────────────────────
    canvas_obj.setStrokeColor(REPORT_BORDER_BLUE)
    canvas_obj.setLineWidth(1.2)
    canvas_obj.line(0.35 * inch, page_h - 1.42 * inch, page_w - 0.35 * inch, page_h - 1.42 * inch)

    # ── Report / Period line ──────────────────────────────────────────
    canvas_obj.setFillColor(colors.black)
    canvas_obj.setFont('Times-Bold', 10)
    canvas_obj.drawString(0.40 * inch, page_h - 1.62 * inch, 'Report :')
    canvas_obj.setFont('Times-Bold', 10)
    canvas_obj.setFillColor(REPORT_BORDER_BLUE)
    canvas_obj.drawString(0.95 * inch, page_h - 1.62 * inch, report_name)

    if start_date and end_date:
        canvas_obj.setFillColor(colors.black)
        canvas_obj.setFont('Times-Bold', 10)
        period_label_x = page_w - 3.55 * inch
        canvas_obj.drawString(period_label_x, page_h - 1.62 * inch, 'Period :')
        canvas_obj.setFillColor(REPORT_BORDER_BLUE)
        canvas_obj.drawString(period_label_x + 0.58 * inch, page_h - 1.62 * inch,
                               start_date.strftime('%d-%b-%Y'))
        canvas_obj.setFillColor(colors.black)
        canvas_obj.drawString(period_label_x + 1.55 * inch, page_h - 1.62 * inch, 'to')
        canvas_obj.setFillColor(REPORT_BORDER_BLUE)
        canvas_obj.drawString(period_label_x + 1.80 * inch, page_h - 1.62 * inch,
                               end_date.strftime('%d-%b-%Y'))

    # ── Stroke line under Report Name / Period (NEW) ──────────────────────────────────
    canvas_obj.setStrokeColor(REPORT_BORDER_BLUE)
    canvas_obj.setLineWidth(1)
    canvas_obj.line(0.35 * inch, page_h - 1.75 * inch, page_w - 0.35 * inch, page_h - 1.75 * inch)

    # ── Footer ─────────────────────────────────────────────────────────
    canvas_obj.setStrokeColor(REPORT_BORDER_BLUE)
    canvas_obj.setLineWidth(1)
    canvas_obj.line(0.35 * inch, 0.55 * inch, page_w - 0.35 * inch, 0.55 * inch)

    canvas_obj.setFont('Times-Roman', 9)
    canvas_obj.setFillColor(colors.black)
    canvas_obj.drawString(0.40 * inch, 0.35 * inch, 'Copyright :  I2G-DCMM')
    canvas_obj.drawRightString(page_w - 0.40 * inch, 0.35 * inch,
                                f"Generated on :  {datetime.now().strftime('%d-%b-%Y %H:%M')}")

    # Underlined classification in footer (NEW)
    canvas_obj.setFont('Helvetica-Bold', 10)
    canvas_obj.setFillColor(REPORT_RED)
    canvas_obj.drawCentredString(page_w / 2, 0.43 * inch, classification)
    class_foot_w = canvas_obj.stringWidth(classification, 'Helvetica-Bold', 10)
    canvas_obj.line(page_w / 2 - class_foot_w / 2, 0.39 * inch, page_w / 2 + class_foot_w / 2, 0.39 * inch)

    canvas_obj.restoreState()


def parse_report_extras(params):
    """Parse the shared 'classification + signature' fields out of a
    request's GET or POST data (anything with a dict-like .get()).
    Returns (classification, signatories, placement) ready to hand to
    generate_pdf_report / generate_module_pdf_report.
    """
    classification = (params.get('classification') or 'RESTRICTED').strip().upper()

    need_signature = str(params.get('need_signature', '')).lower() in ('on', 'true', '1', 'yes')
    signatories = []
    if need_signature:
        try:
            count = int(params.get('signature_count', 0))
        except (TypeError, ValueError):
            count = 0
        count = max(0, min(count, 5))  # hard cap at 5, per spec
        for i in range(1, count + 1):
            name = (params.get(f'sig{i}_name') or '').strip()
            rank = (params.get(f'sig{i}_rank') or '').strip()
            designation = (params.get(f'sig{i}_designation') or '').strip()
            if name or rank or designation:
                signatories.append({'name': name, 'rank': rank, 'designation': designation})

    placement = params.get('signature_placement', 'last_page')
    if placement not in ('every_page', 'last_page'):
        placement = 'last_page'

    return classification, signatories, placement


def get_date_range(report_type):
    """Get date range based on report type"""
    today = datetime.now().date()
    
    if report_type == 'daily':
        return today, today
    elif report_type == 'weekly':
        start = today - timedelta(days=7)
        return start, today
    elif report_type == 'monthly':
        start = today.replace(day=1)
        return start, today
    elif report_type == 'yearly':
        start = today.replace(month=1, day=1)
        return start, today
    else:
        return None, None


def get_dak_date_field_label(date_field):
    mapping = {
        'basis_date': 'Receipt/Dispatch Date',
        'receipt_date': 'Receipt Date',
        'dispatch_details__dispatch_date': 'Dispatch Date',
        'issue_date': 'Letter Issue Date',
        'created_on': 'Entry Date',
        'tbrl_date': 'TBRL Diary Date',
        'reply_due_date': 'Reply Due Date'
    }
    return mapping.get(date_field, 'Date')


def get_dak_date_field_value(dak, date_field):
    if date_field == 'basis_date' or not date_field:
        return report_basis_date(dak)
    elif date_field == 'dispatch_details__dispatch_date':
        try:
            return dak.dispatch_details.dispatch_date
        except Exception:
            return None
    elif date_field == 'created_on':
        return dak.created_on
    else:
        return getattr(dak, date_field, None)


def get_report_data(start_date, end_date, category=None, nature=None, date_field='basis_date'):
    """Fetch data for reports.

    Date basis: Filters and orders based on the chosen date_field.
    """
    if date_field == 'basis_date' or not date_field:
        date_q = (
            Q(dak_direction='INCOMING', receipt_date__gte=start_date, receipt_date__lte=end_date) |
            Q(dak_direction='OUTGOING', dispatch_details__dispatch_date__gte=start_date,
              dispatch_details__dispatch_date__lte=end_date)
        )
        order_field = 'created_on'
    elif date_field == 'created_on':
        date_q = Q(created_on__date__gte=start_date, created_on__date__lte=end_date)
        order_field = 'created_on'
    else:
        date_q = Q(**{f"{date_field}__gte": start_date, f"{date_field}__lte": end_date})
        order_field = date_field

    daks = DakMaster.objects.filter(
        is_active=True
    ).filter(date_q).select_related(
        'dak_category', 'nature', 'thread', 'created_by', 'dispatch_details', 'receiver_org', 'testing_group'
    ).prefetch_related(
        'party_mappings__organization', 'party_mappings__person__organization', 'party_mappings__party_role',
        'group_mappings__group'
    )

    if category:
        daks = daks.filter(dak_category__category_code=category)

    if nature:
        daks = daks.filter(nature__nature_name=nature)

    return daks.order_by(order_field)


def report_basis_date(dak):
    """The one date a report should show/sort by for this dak — receipt
    date if incoming, dispatch date if outgoing. Used by the export
    functions so the displayed date matches what was actually filtered on."""
    if dak.dak_direction == 'INCOMING':
        return dak.receipt_date
    try:
        return dak.dispatch_details.dispatch_date
    except DakDispatchDetails.DoesNotExist:
        return None


def get_dak_company_name(dak):
    if hasattr(dak, 'company') and dak.company:
        return dak.company.org_name
    if dak.dak_direction == 'INCOMING':
        try:
            sender = None
            for mapping in dak.party_mappings.all():
                if mapping.party_role.role_code == 'SENDER':
                    sender = mapping
                    break
            if sender:
                if sender.organization:
                    return sender.organization.org_name
                elif sender.person and sender.person.organization:
                    return sender.person.organization.org_name
        except Exception:
            pass
        return '-'
    else:
        return dak.receiver_org.org_name if dak.receiver_org else '-'


def get_dak_marked_to_person(dak):
    try:
        marked_to = []
        for mapping in dak.party_mappings.all():
            if mapping.party_role.role_code == 'MARKED_TO' and mapping.person:
                marked_to.append(mapping.person.person_name)
        return ", ".join(marked_to) if marked_to else '-'
    except Exception:
        return '-'


def get_dak_groups(dak):
    if dak.testing_group:
        return dak.testing_group.group_name
    try:
        groups = [mapping.group.group_name for mapping in dak.group_mappings.all() if mapping.group]
        return ", ".join(groups) if groups else '-'
    except Exception:
        return '-'


def generate_excel_report(data, title, date_field='basis_date'):
    """Generate Excel report"""
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment
    
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = title[:31]  # Excel sheet name max 31 chars
    
    # Headers - Prepend referencing date if non-default
    ref_label = get_dak_date_field_label(date_field)
    headers = [
        'S.No', f'Ref Date ({ref_label})', 'Dak Index', 'I2G Diary Number', 'Direction',
        'Nature', 'Subject', 'Company', 'Marked to Person', 'Group',
        'Replying To', 'Report Date', 'Issue Date', 'Reply Status', 'Created By', 'Created On'
    ]
    
    # Style headers
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
    
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center')
    
    # Add data
    for row_idx, dak in enumerate(data, 2):
        basis_date = report_basis_date(dak)
        ref_val = get_dak_date_field_value(dak, date_field)
        if isinstance(ref_val, datetime):
            ref_str = ref_val.strftime('%d-%b-%Y %H:%M')
        elif isinstance(ref_val, (date, datetime)):
            ref_str = ref_val.strftime('%d-%b-%Y')
        else:
            ref_str = str(ref_val) if ref_val is not None else '-'

        ws.cell(row=row_idx, column=1, value=row_idx-1)
        ws.cell(row=row_idx, column=2, value=ref_str)
        ws.cell(row=row_idx, column=3, value=dak.dak_index_no)
        ws.cell(row=row_idx, column=4, value=dak.iig_ref_no or '-')
        ws.cell(row=row_idx, column=5, value=dak.dak_direction)
        ws.cell(row=row_idx, column=6, value=dak.nature.nature_name if dak.nature else '-')
        ws.cell(row=row_idx, column=7, value=dak.subject)
        ws.cell(row=row_idx, column=8, value=get_dak_company_name(dak))
        ws.cell(row=row_idx, column=9, value=get_dak_marked_to_person(dak))
        ws.cell(row=row_idx, column=10, value=get_dak_groups(dak))
        ws.cell(row=row_idx, column=11, value=dak.reply_dak.dak_index_no if dak.reply_dak else '-')
        ws.cell(row=row_idx, column=12, value=basis_date.strftime('%d-%b-%Y') if basis_date else '-')
        ws.cell(row=row_idx, column=13, value=dak.issue_date.strftime('%d-%b-%Y') if dak.issue_date else '-')
        ws.cell(row=row_idx, column=14, value='Pending' if dak.reply_mode == 'NOT_YET' else 'Replied')
        ws.cell(row=row_idx, column=15, value=dak.created_by.username if dak.created_by else 'System')
        ws.cell(row=row_idx, column=16, value=dak.created_on.strftime('%d-%b-%Y %H:%M') if dak.created_on else '-')
    
    # Auto-adjust column widths
    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = len(str(cell.value))
            except:
                pass
        adjusted_width = min(max_length + 2, 50)
        ws.column_dimensions[column_letter].width = adjusted_width
    
    # Save to response
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = f'attachment; filename="{title}_{datetime.now().strftime("%Y%m%d")}.xlsx"'
    wb.save(response)
    return response


def generate_csv_report(data, title, date_field='basis_date'):
    """Generate CSV report"""
    import csv
    
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="{title}_{datetime.now().strftime("%Y%m%d")}.csv"'
    
    writer = csv.writer(response)
    
    # Write headers - Prepend referencing date if non-default
    ref_label = get_dak_date_field_label(date_field)
    writer.writerow([
        'S.No', f'Ref Date ({ref_label})', 'Dak Index', 'I2G Diary Number', 'Direction',
        'Nature', 'Subject', 'Company', 'Marked to Person', 'Group',
        'Replying To', 'Report Date', 'Issue Date', 'Reply Status', 'Created By', 'Created On'
    ])
    
    # Write data
    for idx, dak in enumerate(data, 1):
        basis_date = report_basis_date(dak)
        ref_val = get_dak_date_field_value(dak, date_field)
        if isinstance(ref_val, datetime):
            ref_str = ref_val.strftime('%d-%b-%Y %H:%M')
        elif isinstance(ref_val, (date, datetime)):
            ref_str = ref_val.strftime('%d-%b-%Y')
        else:
            ref_str = str(ref_val) if ref_val is not None else '-'

        writer.writerow([
            idx, ref_str, dak.dak_index_no, dak.iig_ref_no or '-', dak.dak_direction,
            dak.nature.nature_name if dak.nature else '-',
            dak.subject,
            get_dak_company_name(dak),
            get_dak_marked_to_person(dak),
            get_dak_groups(dak),
            dak.reply_dak.dak_index_no if dak.reply_dak else '-',
            basis_date.strftime('%d-%b-%Y') if basis_date else '-',
            dak.issue_date.strftime('%d-%b-%Y') if dak.issue_date else '-', 
            'Pending' if dak.reply_mode == 'NOT_YET' else 'Replied',
            dak.created_by.username if dak.created_by else 'System',
            dak.created_on.strftime('%d-%b-%Y %H:%M') if dak.created_on else '-'
        ])
    
    return response


def generate_module_pdf_report(queryset, columns, title, watermark_text=None, start_date=None, end_date=None,
                                classification='RESTRICTED', signatories=None, signature_placement='last_page'):
    """Generic PDF export for the report builder and the eDW/eToT/eIIG
    quick reports. Dynamic cell sizing based on content, splitting
    large column counts across multiple pages horizontally (dynamic pagination).
    """
    from .report_columns import resolve_value
    import functools

    signatories = signatories or []
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="{title}_{datetime.now().strftime("%Y%m%d")}.pdf"'

    bottom_margin = 1.75 * inch if signatories else 0.85 * inch
    doc = SimpleDocTemplate(
        response, pagesize=landscape(letter),
        topMargin=1.75 * inch, bottomMargin=bottom_margin,
        leftMargin=0.40 * inch, rightMargin=0.40 * inch,
    )
    elements = []

    from .dynamic_columns import prefetch_extra_col_values
    records = list(queryset)
    if records:
        model_name = records[0].__class__.__name__
        module_key = {'eDW': 'edw', 'eTOT': 'etot', 'eIIGVisit': 'eiig', 'DakMaster': 'dak'}.get(model_name)
        if module_key:
            prefetch_extra_col_values(module_key, records)
    queryset = records
    
    # 1. Compute dynamic column widths based on content
    font_size_base = 8.0
    char_width_pts = font_size_base * 0.45
    
    col_widths = [0.45 * inch]  # for S.No
    for c in columns:
        max_chars = len(c['label'])
        for obj in queryset:
            val = resolve_value(obj, c['accessor'])
            val_str = str(val) if val is not None else ''
            lines = val_str.split('\n')
            for line in lines:
                max_chars = max(max_chars, len(line))
        
        w_in = max(0.6 * inch, min(3.5 * inch, (max_chars * char_width_pts + 15) / 72.0))
        col_widths.append(w_in)

    # 2. Group columns into chunks that fit on the landscape page (10.1 inches usable width)
    max_page_width = 10.1 * inch
    column_chunks = []
    chunk_widths = []
    
    current_chunk = []
    current_chunk_widths = [0.45 * inch]  # S.No
    current_width = 0.45 * inch
    
    for col, width in zip(columns, col_widths[1:]):
        if current_width + width > max_page_width and current_chunk:
            column_chunks.append(current_chunk)
            chunk_widths.append(current_chunk_widths)
            current_chunk = [col]
            current_chunk_widths = [0.45 * inch, width]
            current_width = 0.45 * inch + width
        else:
            current_chunk.append(col)
            current_chunk_widths.append(width)
            current_width += width
            
    if current_chunk:
        column_chunks.append(current_chunk)
        chunk_widths.append(current_chunk_widths)

    # 3. For each chunk, render a separate table section
    for chunk_idx, chunk_cols in enumerate(column_chunks):
        if chunk_idx > 0:
            elements.append(PageBreak())

        # If there are multiple chunks, add a header to indicate which part it is
        if len(column_chunks) > 1:
            part_title = f"{title} — Part {chunk_idx + 1} of {len(column_chunks)}"
            title_style = ParagraphStyle(
                'part_title', fontName='Times-Bold', fontSize=10, leading=12,
                textColor=REPORT_BORDER_BLUE, spaceAfter=8
            )
            elements.append(Paragraph(part_title, title_style))

        n_cols = len(chunk_cols) + 1
        font_size = 8.5 if n_cols <= 6 else (7.5 if n_cols <= 10 else 6.5)

        header_style = ParagraphStyle('hdr', fontName='Times-Bold', fontSize=font_size,
                                       leading=font_size + 1.5, alignment=1, textColor=colors.black)
        cell_style = ParagraphStyle('cell', fontName='Times-Roman', fontSize=font_size,
                                     leading=font_size + 1.5, alignment=1, textColor=colors.black)

        header_row = [Paragraph('S.No', header_style)] + [Paragraph(c['label'], header_style) for c in chunk_cols]
        table_data = [header_row]
        for idx, obj in enumerate(queryset, 1):
            row = [Paragraph(str(idx), cell_style)]
            for c in chunk_cols:
                val = resolve_value(obj, c['accessor'])
                text = str(val) if val is not None else ''
                row.append(Paragraph(text, cell_style))
            table_data.append(row)

        c_widths = chunk_widths[chunk_idx]
        data_table = Table(table_data, colWidths=c_widths, repeatRows=1)
        data_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), REPORT_HEADER_GRAY),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('GRID', (0, 0), (-1, -1), 0.6, REPORT_BORDER_BLUE),
            ('TOPPADDING', (0, 0), (-1, -1), 3),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
            ('LEFTPADDING', (0, 0), (-1, -1), 3),
            ('RIGHTPADDING', (0, 0), (-1, -1), 3),
        ]))
        elements.append(data_table)

    if watermark_text:
        def _on_page(canvas_obj, doc_):
            draw_official_report_frame(canvas_obj, doc_, title, start_date, end_date, classification)
            canvas_obj.saveState()
            page_w, page_h = doc_.pagesize
            canvas_obj.setFont('Helvetica-Bold', 55)
            canvas_obj.setFillColor(colors.Color(0.6, 0.6, 0.6, alpha=0.14))
            canvas_obj.translate(page_w / 2, page_h / 2)
            canvas_obj.rotate(45)
            canvas_obj.drawCentredString(0, 0, watermark_text)
            canvas_obj.restoreState()
    else:
        def _on_page(canvas_obj, doc_):
            draw_official_report_frame(canvas_obj, doc_, title, start_date, end_date, classification)

    canvas_maker = functools.partial(NumberedCanvas, signatories=signatories, signature_placement=signature_placement)
    doc.build(elements, onFirstPage=_on_page, onLaterPages=_on_page, canvasmaker=canvas_maker)
    return response


def generate_module_docx_report(queryset, columns, title, watermark_text='IIG-DCMM'):
    """Generic DOCX export for the report builder. The watermark and
    title go in the page header, which Word repeats on every page by
    default (same intent as the PDF header fix, native to the format)."""
    from .dynamic_columns import prefetch_extra_col_values
    records = list(queryset)
    if records:
        model_name = records[0].__class__.__name__
        module_key = {'eDW': 'edw', 'eTOT': 'etot', 'eIIGVisit': 'eiig', 'DakMaster': 'dak'}.get(model_name)
        if module_key:
            prefetch_extra_col_values(module_key, records)
    queryset = records

    from docx import Document
    from docx.shared import Pt, RGBColor, Inches
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from .report_columns import resolve_value

    document = Document()
    section = document.sections[0]
    section.orientation = 1  # landscape
    section.page_width, section.page_height = section.page_height, section.page_width

    # Header — repeats on every page natively in Word
    header = section.header
    wm_para = header.paragraphs[0]
    wm_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    wm_run = wm_para.add_run(watermark_text or '')
    wm_run.font.size = Pt(36)
    wm_run.font.bold = True
    wm_run.font.color.rgb = RGBColor(0xD9, 0xD9, 0xD9)  # light grey, watermark-style

    title_para = header.add_paragraph()
    title_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title_run = title_para.add_run(title)
    title_run.font.size = Pt(14)
    title_run.font.bold = True

    date_para = header.add_paragraph()
    date_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    date_run = date_para.add_run(f"Generated {datetime.now().strftime('%d-%b-%Y %H:%M')}")
    date_run.font.size = Pt(8)

    document.add_paragraph()  # spacing after header content on page 1

    table = document.add_table(rows=1, cols=len(columns) + 1)
    table.style = 'Light Grid Accent 1'
    hdr_cells = table.rows[0].cells
    hdr_cells[0].text = 'S.No'
    for i, c in enumerate(columns, 1):
        hdr_cells[i].text = c['label']

    for idx, obj in enumerate(queryset, 1):
        row_cells = table.add_row().cells
        row_cells[0].text = str(idx)
        for i, c in enumerate(columns, 1):
            val = resolve_value(obj, c['accessor'])
            row_cells[i].text = str(val) if val is not None else ''

    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document')
    response['Content-Disposition'] = f'attachment; filename="{title}_{datetime.now().strftime("%Y%m%d")}.docx"'
    document.save(response)
    return response


def get_module_report_data(module_key, start_date=None, end_date=None, date_field=None):
    """Queryset for a module's quick report, optionally filtered by
    created_at date range. Each module gets its own select_related list
    matching the FK columns its default report columns actually use."""
    from .models import eDW, eTOT, eIIGVisit

    if module_key == 'edw':
        qs = eDW.objects.select_related('company_name', 'group', 'dak', 'created_by')
        default_date = 'created_at'
    elif module_key == 'etot':
        qs = eTOT.objects.select_related('technical_group', 'point_of_contact', 'licensee_company', 'created_by')
        default_date = 'created_at'
    elif module_key == 'eiig':
        qs = eIIGVisit.objects.select_related('created_by').prefetch_related('visitors')
        default_date = 'date_of_visit'
    else:
        return None

    if not date_field:
        date_field = default_date

    if start_date or end_date:
        is_datetime = (date_field in ('created_at', 'updated_at'))
        suffix = '__date' if is_datetime else ''
        filter_kwargs = {}
        if start_date:
            filter_kwargs[f"{date_field}{suffix}__gte"] = start_date
        if end_date:
            filter_kwargs[f"{date_field}{suffix}__lte"] = end_date
        qs = qs.filter(**filter_kwargs)

    return qs.order_by(date_field)


def generate_module_excel_report(queryset, columns, title):
    """Generic Excel export for any module (eDW/eToT/eIIG) and any column
    subset — same idea as generate_excel_report, but not hard-coded to
    Dak fields. Fills the Excel-shaped gap in the report builder, which
    previously only offered PDF and Word."""
    from .dynamic_columns import prefetch_extra_col_values
    records = list(queryset)
    if records:
        model_name = records[0].__class__.__name__
        module_key = {'eDW': 'edw', 'eTOT': 'etot', 'eIIGVisit': 'eiig', 'DakMaster': 'dak'}.get(model_name)
        if module_key:
            prefetch_extra_col_values(module_key, records)
    queryset = records

    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment
    from .report_columns import resolve_value

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = title[:31]

    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="0F766E", end_color="0F766E", fill_type="solid")

    ws.cell(row=1, column=1, value='S.No').font = header_font
    ws.cell(row=1, column=1).fill = header_fill
    for col, c in enumerate(columns, 2):
        cell = ws.cell(row=1, column=col, value=c['label'])
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center')

    for row_idx, obj in enumerate(queryset, 2):
        ws.cell(row=row_idx, column=1, value=row_idx - 1)
        for col, c in enumerate(columns, 2):
            val = resolve_value(obj, c['accessor'])
            ws.cell(row=row_idx, column=col, value=str(val) if val is not None else '')

    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = len(str(cell.value))
            except Exception:
                pass
        ws.column_dimensions[column_letter].width = min(max_length + 2, 50)

    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = f'attachment; filename="{title}_{datetime.now().strftime("%Y%m%d")}.xlsx"'
    wb.save(response)
    return response


def generate_module_csv_report(queryset, columns, title):
    """Generic CSV export for any module and any column subset."""
    from .dynamic_columns import prefetch_extra_col_values
    records = list(queryset)
    if records:
        model_name = records[0].__class__.__name__
        module_key = {'eDW': 'edw', 'eTOT': 'etot', 'eIIGVisit': 'eiig', 'DakMaster': 'dak'}.get(model_name)
        if module_key:
            prefetch_extra_col_values(module_key, records)
    queryset = records

    import csv
    from .report_columns import resolve_value

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="{title}_{datetime.now().strftime("%Y%m%d")}.csv"'
    writer = csv.writer(response)
    writer.writerow(['S.No'] + [c['label'] for c in columns])
    for idx, obj in enumerate(queryset, 1):
        row = [idx]
        for c in columns:
            val = resolve_value(obj, c['accessor'])
            row.append(val if val is not None else '')
        writer.writerow(row)
    return response


def generate_pdf_report(data, title, start_date, end_date, watermark_text=None,
                         classification='RESTRICTED', signatories=None, signature_placement='last_page', date_field='basis_date'):
    """Generate PDF report using the official DRDO/TBRL report frame.
    Prepend referencing date.
    """
    import functools
    signatories = signatories or []

    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="{title}_{datetime.now().strftime("%Y%m%d")}.pdf"'

    bottom_margin = 1.75 * inch if signatories else 0.85 * inch
    doc = SimpleDocTemplate(
        response, pagesize=landscape(letter),
        topMargin=1.75 * inch, bottomMargin=bottom_margin,
        leftMargin=0.40 * inch, rightMargin=0.40 * inch,
    )
    elements = []

    data = list(data)
    ref_label = get_dak_date_field_label(date_field)
    
    styles = getSampleStyleSheet()
    cell_style = ParagraphStyle(
        'TableCellStyle',
        parent=styles['Normal'],
        fontName='Times-Roman',
        fontSize=8,
        leading=9,
        alignment=1  # Center
    )
    cell_style_left = ParagraphStyle(
        'TableCellStyleLeft',
        parent=styles['Normal'],
        fontName='Times-Roman',
        fontSize=8,
        leading=9,
        alignment=0  # Left
    )

    header_style = ParagraphStyle(
        'TableHeaderStyle',
        parent=styles['Normal'],
        fontName='Times-Bold',
        fontSize=8,
        leading=9,
        alignment=1,  # Center
        textColor=colors.black
    )

    headers = [
        'S.No', ref_label, 'Dak Index', 'I2G Diary No', 'Direction',
        'Nature', 'Subject', 'Company', 'Marked to Person', 'Group', 'Reply Status'
    ]
    table_data = [[Paragraph(h, header_style) for h in headers]]
    for idx, dak in enumerate(data, 1):
        ref_val = get_dak_date_field_value(dak, date_field)
        if isinstance(ref_val, datetime):
            ref_str = ref_val.strftime('%d-%b-%Y')
        elif isinstance(ref_val, (date, datetime)):
            ref_str = ref_val.strftime('%d-%b-%Y')
        else:
            ref_str = str(ref_val) if ref_val is not None else '-'

        subject_p = Paragraph(dak.subject or '', cell_style_left)
        company_p = Paragraph(get_dak_company_name(dak), cell_style_left)
        marked_p = Paragraph(get_dak_marked_to_person(dak), cell_style_left)
        nature_p = Paragraph(dak.nature.nature_name if dak.nature else '-', cell_style)
        group_p = Paragraph(get_dak_groups(dak), cell_style)
        
        idx_p = Paragraph(str(idx), cell_style)
        ref_p = Paragraph(ref_str, cell_style)
        index_p = Paragraph(dak.dak_index_no or '-', cell_style)
        iig_p = Paragraph(dak.iig_ref_no or '-', cell_style)
        dir_p = Paragraph(dak.dak_direction or '-', cell_style)
        status_p = Paragraph('Pending' if dak.reply_mode == 'NOT_YET' else 'Replied', cell_style)

        table_data.append([
            idx_p, ref_p, index_p, iig_p, dir_p,
            nature_p, subject_p, company_p, marked_p, group_p,
            status_p
        ])

    data_table = Table(
        table_data,
        colWidths=[0.4 * inch, 0.8 * inch, 0.9 * inch, 1.0 * inch, 0.7 * inch, 0.8 * inch, 1.8 * inch, 1.1 * inch, 1.0 * inch, 0.8 * inch, 0.8 * inch],
        repeatRows=1,
    )
    data_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), REPORT_HEADER_GRAY),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Times-Bold'),
        ('FONTNAME', (0, 1), (-1, -1), 'Times-Roman'),
        ('FONTSIZE', (0, 0), (-1, 0), 8.5),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
        ('GRID', (0, 0), (-1, -1), 0.6, REPORT_BORDER_BLUE),
        ('FONTSIZE', (0, 1), (-1, -1), 8),
    ]))
    elements.append(data_table)

    if watermark_text:
        def _on_page(canvas_obj, doc_):
            draw_official_report_frame(canvas_obj, doc_, title, start_date, end_date, classification)
            canvas_obj.saveState()
            page_w, page_h = doc_.pagesize
            canvas_obj.setFont('Helvetica-Bold', 55)
            canvas_obj.setFillColor(colors.Color(0.6, 0.6, 0.6, alpha=0.14))
            canvas_obj.translate(page_w / 2, page_h / 2)
            canvas_obj.rotate(45)
            canvas_obj.drawCentredString(0, 0, watermark_text)
            canvas_obj.restoreState()
    else:
        def _on_page(canvas_obj, doc_):
            draw_official_report_frame(canvas_obj, doc_, title, start_date, end_date, classification)

    canvas_maker = functools.partial(NumberedCanvas, signatories=signatories, signature_placement=signature_placement)
    doc.build(elements, onFirstPage=_on_page, onLaterPages=_on_page, canvasmaker=canvas_maker)
    return response