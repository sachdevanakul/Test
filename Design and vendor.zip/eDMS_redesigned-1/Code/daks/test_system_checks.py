"""
7 test cases covering the highest-value checks across the work done.

Runs against a throwaway in-memory SQLite database (see test_settings.py)
so it can NEVER touch your real Postgres data, and doesn't need any
special database privileges.

HOW TO RUN
----------
1. Drop this file in as daks/test_system_checks.py
2. Drop test_settings.py in as edms/test_settings.py
3. From the Code/ folder (same level as manage.py):

     DJANGO_SETTINGS_MODULE=edms.test_settings python manage.py test daks.test_system_checks -v 2

   On Windows (cmd):
     set DJANGO_SETTINGS_MODULE=edms.test_settings
     python manage.py test daks.test_system_checks -v 2

Each test prints its own name and either passes silently or fails with a
clear message saying exactly what was expected vs what happened.
"""

import datetime
from django.test import TestCase, Client
from django.contrib.auth.models import User
from django.urls import reverse

from daks.models import (
    DakCategoryMaster, DakThread, DakMaster, DakFileAttachment,
    OrganizationTypeMaster, OrganizationMaster, PersonMaster, PartyRoleMaster,
    eDW, eTOT, eIIGVisit, UserProfile, DakDispatchDetails, DispatchModeMaster,
)


class SystemCheckTests(TestCase):

    def setUp(self):
        self.staff = User.objects.create_user(
            'staffchecker', 'staff@test.com', 'pass12345', is_staff=True)
        self.category = DakCategoryMaster.objects.create(
            category_code='GEN', category_name='General')
        self.org_type = OrganizationTypeMaster.objects.create(type_name='Industry')
        self.client = Client()
        self.client.login(username='staffchecker', password='pass12345')

    # ── 1. Nav permissions ────────────────────────────────────────────
    def test_1_nav_shows_only_granted_modules(self):
        """A user granted ONLY eDW should see eDW in their sidebar, and
        should NOT see eToT, eIIG, or the Admin link. This is the fix
        for 'ticking module permissions has no visible effect'."""
        user = User.objects.create_user('navcheck', 'n@test.com', 'pass12345')
        UserProfile.objects.filter(user=user).update(
            can_access_edw=True, can_access_etot=False, can_access_eiig=False)
        c = Client()
        c.login(username='navcheck', password='pass12345')
        html = c.get('/').content.decode()
        sidebar = html[html.index('<nav id="sidebar">'):html.index('</nav>')]

        self.assertIn('eDW', sidebar, "Granted module 'eDW' is missing from the sidebar — the nav-permission fix is not active.")
        self.assertNotIn('eToT', sidebar, "Ungranted module 'eToT' is showing in the sidebar — permissions aren't being respected.")
        self.assertNotIn('href="/admin/"', sidebar, "The Admin link is visible to a non-staff user — it should be staff-only.")

    # ── 2. Attachment security ────────────────────────────────────────
    def test_2_attachment_download_requires_login(self):
        """Downloading an attachment with no session at all must be
        refused, not silently served. This was the original critical
        vulnerability — attachments were public to anyone with the URL."""
        thread = DakThread.objects.create(
            thread_code='T-SEC-1', subject_summary='Security test', status='OPEN')
        dak = DakMaster.objects.create(
            thread=thread, dak_direction='INCOMING', dak_category=self.category,
            dak_index_no='IN-SEC-1', subject='Security test dak',
            issue_date=datetime.date.today(), created_by=self.staff)
        attachment = DakFileAttachment.objects.create(
            dak=dak, file_name='secret.txt', file_path='/tmp/does_not_matter.txt',
            file_size=10, mime_type='text/plain', checksum='x', is_encrypted=False,
            uploaded_by=self.staff)

        anonymous_client = Client()  # no login at all
        resp = anonymous_client.get(f'/attachment/{attachment.public_id}/download/')
        self.assertIn(resp.status_code, (302, 403),
            f"Attachment was reachable with NO login at all (got status {resp.status_code}, expected a redirect/forbidden).")

    # ── 3. Non-guessable URLs ──────────────────────────────────────────
    def test_3_dak_urls_use_random_id_not_sequential_number(self):
        """A dak's URL must use its random public_id, and the old-style
        '/dak/<small number>/' URL must no longer work at all."""
        thread = DakThread.objects.create(
            thread_code='T-ID-1', subject_summary='ID test', status='OPEN')
        dak = DakMaster.objects.create(
            thread=thread, dak_direction='INCOMING', dak_category=self.category,
            dak_index_no='IN-ID-1', subject='ID test dak',
            issue_date=datetime.date.today(), created_by=self.staff)

        resp_real = self.client.get(f'/dak/{dak.public_id}/')
        self.assertEqual(resp_real.status_code, 200, "The dak's real (UUID) URL should load successfully.")

        resp_old_style = self.client.get(f'/dak/{dak.id}/')
        self.assertEqual(resp_old_style.status_code, 404,
            f"The OLD-style numeric URL '/dak/{dak.id}/' still works (got {resp_old_style.status_code}) — "
            "it should 404, since URLs are supposed to use the random ID now.")

    # ── 4. eDW import doesn't crash on a new company ───────────────────
    def test_4_edw_import_accepts_new_company_without_crashing(self):
        """Importing an eDW row for a company that doesn't exist yet in
        the system must succeed, not crash with a database error. This
        was the bug that likely broke most real eDW imports."""
        from django.core.files.uploadedfile import SimpleUploadedFile
        import pandas as pd
        from io import BytesIO

        df = pd.DataFrame({
            'acn_no': ['ACN-CHECK-1'],
            'company_name': ['A Brand New Company Not In The System'],
        })
        buf = BytesIO()
        df.to_excel(buf, index=False, engine='openpyxl')
        buf.seek(0)
        upload = SimpleUploadedFile(
            "check.xlsx", buf.read(),
            content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

        resp = self.client.post('/edw/import/', {'import_file': upload})
        self.assertEqual(resp.status_code, 200, "The import request itself should return 200 (even if some rows are skipped).")
        self.assertTrue(
            eDW.objects.filter(acn_no='ACN-CHECK-1').exists(),
            "Importing a new, unrecognized company should still create the eDW record, not silently fail or crash.")

    # ── 5. Reports use receipt/dispatch date, not entry date ───────────
    def test_5_report_uses_receipt_date_not_entry_date(self):
        """A report for a given date should include a dak actually
        received/dispatched that day, even if it was typed into the
        system on a different day — and should NOT include it under the
        day it merely happened to be entered."""
        thread = DakThread.objects.create(
            thread_code='T-DATE-1', subject_summary='Date test', status='OPEN')
        DakMaster.objects.create(
            thread=thread, dak_direction='INCOMING', dak_category=self.category,
            dak_index_no='IN-DATE-1', subject='Date basis test dak',
            issue_date=datetime.date(2026, 1, 10),     # entered on the 10th
            receipt_date=datetime.date(2026, 1, 1),    # but actually received on the 1st
            created_by=self.staff)

        resp_receipt_date = self.client.get('/reports/range/?start_date=2026-01-01&end_date=2026-01-01&format=csv')
        self.assertIn('IN-DATE-1', resp_receipt_date.content.decode(),
            "A report for the RECEIPT date should include this dak — it currently doesn't.")

        resp_entry_date = self.client.get('/reports/range/?start_date=2026-01-10&end_date=2026-01-10&format=csv')
        self.assertNotIn('IN-DATE-1', resp_entry_date.content.decode(),
            "A report for the ENTRY date (when it was typed in) should NOT include this dak — "
            "if it does, the report is using the wrong date field.")

    # ── 6. eDW/eToT/eIIG quick reports generate with real data ─────────
    def test_6_module_quick_reports_generate_with_real_data(self):
        """Each of eDW/eToT/eIIG's one-click reports should produce a
        real file containing the actual data, in PDF, Excel, and CSV."""
        org = OrganizationMaster.objects.create(
            org_name='Quick Report Check Firm', org_type=self.org_type, created_by=self.staff)
        eDW.objects.create(acn_no='ACN-QUICK-1', company_name=org, created_by=self.staff)
        eTOT.objects.create(tot_file_no='TOT-QUICK-1', created_by=self.staff)
        eIIGVisit.objects.create(
            visit_id='V-QUICK-1', date_of_visit=datetime.date.today(),
            firm_name='Quick Visit Firm', company_category='INDUSTRY', created_by=self.staff)

        checks = [
            ('edw', 'ACN-QUICK-1'),
            ('etot', 'TOT-QUICK-1'),
            ('eiig', 'V-QUICK-1'),
        ]
        for module_key, expected_text in checks:
            for fmt in ['pdf', 'xlsx', 'csv']:
                resp = self.client.get(f'/reports/quick/{module_key}/?format={fmt}')
                self.assertEqual(resp.status_code, 200,
                    f"{module_key} report in {fmt} format failed (status {resp.status_code}).")
            # Confirm the CSV (easiest to read back as text) actually contains real data
            csv_resp = self.client.get(f'/reports/quick/{module_key}/?format=csv')
            self.assertIn(expected_text, csv_resp.content.decode(),
                f"{module_key}'s CSV report doesn't contain the expected data ({expected_text}) — it may be exporting an empty/wrong table.")

    # ── 7. Threads: same subject ≠ same thread across different firms ──
    def test_7_thread_separates_different_organizations_same_subject(self):
        """Two different organizations writing about the exact same
        subject text must end up in two DIFFERENT threads. (And the
        reverse — same organization, different subject, with the thread
        explicitly picked — must end up in the SAME thread; that part
        is covered implicitly since both paths use the same logic.)"""
        firm_a = OrganizationMaster.objects.create(
            org_name='Thread Check Firm A', org_type=self.org_type, created_by=self.staff)
        firm_b = OrganizationMaster.objects.create(
            org_name='Thread Check Firm B', org_type=self.org_type, created_by=self.staff)
        person_a = PersonMaster.objects.create(person_name='Contact A', organization=firm_a, created_by=self.staff)
        person_b = PersonMaster.objects.create(person_name='Contact B', organization=firm_b, created_by=self.staff)
        PartyRoleMaster.objects.get_or_create(role_code='SENDER', defaults={'role_name': 'Sender'})

        same_subject = 'Identical subject line used by both firms'
        self.client.post('/create/incoming/', {
            'dak_category': self.category.id, 'subject': same_subject,
            'issue_date': '2026-01-05', 'sender_org': firm_a.id, 'sender_person': person_a.id,
        })
        self.client.post('/create/incoming/', {
            'dak_category': self.category.id, 'subject': same_subject,
            'issue_date': '2026-01-06', 'sender_org': firm_b.id, 'sender_person': person_b.id,
        })

        dak_a = DakMaster.objects.get(subject=same_subject, dak_index_no__startswith='IN', issue_date='2026-01-05')
        dak_b = DakMaster.objects.get(subject=same_subject, dak_index_no__startswith='IN', issue_date='2026-01-06')
        self.assertNotEqual(dak_a.thread_id, dak_b.thread_id,
            "Two different organizations writing about the identical subject ended up in the SAME thread — "
            "this is the exact bug the thread redesign was meant to fix.")

    # ── 8. Chronological Ordering ─────────────────────────────────────
    def test_8_report_generation_order_is_chronological(self):
        """Reports should be generated in chronological order (oldest first)
        rather than reverse order."""
        thread = DakThread.objects.create(
            thread_code='T-CHRON-1', subject_summary='Chronological order test', status='OPEN')
        
        # Create Daks in sequence
        dak1 = DakMaster.objects.create(
            thread=thread, dak_direction='INCOMING', dak_category=self.category,
            dak_index_no='IN-CHRON-1', subject='First Dak',
            issue_date=datetime.date(2026, 1, 1), receipt_date=datetime.date(2026, 1, 1),
            created_by=self.staff)
        
        dak2 = DakMaster.objects.create(
            thread=thread, dak_direction='INCOMING', dak_category=self.category,
            dak_index_no='IN-CHRON-2', subject='Second Dak',
            issue_date=datetime.date(2026, 1, 2), receipt_date=datetime.date(2026, 1, 2),
            created_by=self.staff)
            
        dak3 = DakMaster.objects.create(
            thread=thread, dak_direction='INCOMING', dak_category=self.category,
            dak_index_no='IN-CHRON-3', subject='Third Dak',
            issue_date=datetime.date(2026, 1, 3), receipt_date=datetime.date(2026, 1, 3),
            created_by=self.staff)

        # Get CSV range report
        resp = self.client.get('/reports/range/?start_date=2026-01-01&end_date=2026-01-05&format=csv')
        csv_text = resp.content.decode()
        
        # Check that index numbers appear in chronological order (IN-CHRON-1, then IN-CHRON-2, then IN-CHRON-3)
        pos1 = csv_text.find('IN-CHRON-1')
        pos2 = csv_text.find('IN-CHRON-2')
        pos3 = csv_text.find('IN-CHRON-3')
        
        self.assertTrue(pos1 < pos2 < pos3, 
            f"Report is not sorted chronologically: pos1={pos1}, pos2={pos2}, pos3={pos3}")

    # ── 9. Date Field Referencing & First Column ──────────────────────
    def test_9_report_date_field_referencing(self):
        """Selecting a date field filters the queryset on that field and
        places it as the first data column in the report."""
        thread = DakThread.objects.create(
            thread_code='T-REF-1', subject_summary='Reference date test', status='OPEN')
        
        # Dak 1: issue_date=2026-01-01 (in range), receipt_date=2026-01-10 (out of range)
        dak1 = DakMaster.objects.create(
            thread=thread, dak_direction='INCOMING', dak_category=self.category,
            dak_index_no='IN-REF-1', subject='Ref Dak 1',
            issue_date=datetime.date(2026, 1, 1), receipt_date=datetime.date(2026, 1, 10),
            created_by=self.staff)
            
        # Dak 2: issue_date=2026-01-02 (in range), receipt_date=2026-01-11 (out of range)
        dak2 = DakMaster.objects.create(
            thread=thread, dak_direction='INCOMING', dak_category=self.category,
            dak_index_no='IN-REF-2', subject='Ref Dak 2',
            issue_date=datetime.date(2026, 1, 2), receipt_date=datetime.date(2026, 1, 11),
            created_by=self.staff)

        # Get CSV range report filtered by issue_date range (2026-01-01 to 2026-01-02)
        resp = self.client.get('/reports/range/?start_date=2026-01-01&end_date=2026-01-02&format=csv&date_field=issue_date')
        csv_text = resp.content.decode()
        
        # Verify both daks are included (which they would not be if filtered by receipt_date)
        self.assertIn('IN-REF-1', csv_text)
        self.assertIn('IN-REF-2', csv_text)
        
        # Verify the CSV header contains the selected date field name
        self.assertIn('Ref Date (Letter Issue Date)', csv_text)
        
        # Verify it has the correct formatting
        self.assertIn('01-Jan-2026', csv_text)
        self.assertIn('02-Jan-2026', csv_text)

    # ── 10. Custom Naming ─────────────────────────────────────────────
    def test_10_report_custom_naming_and_styling(self):
        """Providing a report_title custom name uses it in the filename."""
        resp = self.client.get('/reports/range/?start_date=2026-01-01&end_date=2026-01-02&format=csv&report_title=MyCustomTitle')
        disp = resp.headers.get('Content-Disposition', '')
        self.assertIn('MyCustomTitle', disp)

