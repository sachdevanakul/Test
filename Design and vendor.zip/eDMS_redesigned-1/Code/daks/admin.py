from django.contrib import admin
from django import forms
from django.utils.html import format_html
from django.urls import reverse
from .models import *
from django.core.cache import cache
from .models import UserNotes

# ============================================
# CONFIGURATION TABLES ADMIN
# ============================================
class CacheAdmin(admin.ModelAdmin):
    def has_add_permission(self, request):
        return False
    
    def changelist_view(self, request, extra_context=None):
        context = {
            'cache_keys': ['dropdown_data'],
            'cache_status': {}
        }
        for key in context['cache_keys']:
            context['cache_status'][key] = 'HIT' if cache.get(key) else 'MISS'
        return super().changelist_view(request, extra_context=context)

@admin.register(OrganizationTypeMaster)
class OrganizationTypeMasterAdmin(admin.ModelAdmin):
    list_display = ['type_name', 'is_system_defined', 'is_active', 'created_by', 'created_at']
    list_filter = ['is_system_defined', 'is_active', 'source']
    search_fields = ['type_name', 'description']
    readonly_fields = ['created_at', 'updated_at']
    ordering = ['type_name']
    
    def save_model(self, request, obj, form, change):
        if not change:
            obj.created_by = request.user
        super().save_model(request, obj, form, change)


@admin.register(DakCategoryMaster)
class DakCategoryMasterAdmin(admin.ModelAdmin):
    list_display = ['category_code', 'category_name', 'can_have_nature', 
                    'can_have_report_details', 'can_have_dispatch_details', 'is_active']
    list_filter = ['is_active', 'can_have_nature']
    search_fields = ['category_code', 'category_name']
    ordering = ['category_code']


@admin.register(PartyRoleMaster)
class PartyRoleMasterAdmin(admin.ModelAdmin):
    list_display = ['role_code', 'role_name', 'is_active']
    list_filter = ['is_active']
    search_fields = ['role_code', 'role_name']
    ordering = ['role_code']


@admin.register(DispatchModeMaster)
class DispatchModeMasterAdmin(admin.ModelAdmin):
    list_display = ['mode_code', 'mode_name', 'is_active']
    list_filter = ['is_active']
    search_fields = ['mode_code', 'mode_name']
    ordering = ['mode_code']


# ============================================
# DYNAMIC MASTER TABLES ADMIN - UPDATED
# ============================================

@admin.register(DakNatureMaster)
class DakNatureMasterAdmin(admin.ModelAdmin):
    list_display = ['nature_name', 'applicable_category', 'is_active', 'created_by', 'source']
    list_filter = ['is_active', 'source']
    search_fields = ['nature_name']
    readonly_fields = ['created_at', 'updated_at']
    ordering = ['nature_name']
    
    def save_model(self, request, obj, form, change):
        if not change:
            obj.created_by = request.user
        super().save_model(request, obj, form, change)


@admin.register(GroupMaster)
class GroupMasterAdmin(admin.ModelAdmin):
    list_display = ['group_code', 'group_name', 'member_count', 'is_active', 'created_by']
    list_filter = ['is_active']
    search_fields = ['group_code', 'group_name', 'description']
    readonly_fields = ['created_at', 'updated_at']
    ordering = ['group_code']
    
    def member_count(self, obj):
        return PersonMaster.objects.filter(group=obj, is_active=True).count()
    member_count.short_description = 'Members'
    
    def save_model(self, request, obj, form, change):
        if not change:
            obj.created_by = request.user
        super().save_model(request, obj, form, change)


@admin.register(OrganizationMaster)
class OrganizationMasterAdmin(admin.ModelAdmin):
    list_display = ['org_name', 'org_type', 'phone', 'email', 'is_active', 
                    'created_by', 'source', 'created_at']
    list_filter = ['org_type', 'is_active', 'source']
    search_fields = ['org_name', 'phone', 'email', 'address']
    readonly_fields = ['created_at', 'updated_at']
    raw_id_fields = ['created_by']
    ordering = ['org_name']
    
    def save_model(self, request, obj, form, change):
        if not change:
            obj.created_by = request.user
        super().save_model(request, obj, form, change)


@admin.register(PersonMaster)
class PersonMasterAdmin(admin.ModelAdmin):
    list_display = ['person_name', 'get_affiliation', 'designation', 'email', 
                    'mobile_no', 'is_iig_member', 'is_active']
    list_filter = ['is_active', 'is_iig_member', 'group', 'organization']
    search_fields = ['person_name', 'email', 'mobile_no', 'designation']
    raw_id_fields = ['organization', 'group', 'created_by']
    readonly_fields = ['created_at', 'updated_at']
    ordering = ['person_name']
    
    def get_affiliation(self, obj):
        if obj.group:
            return f"Group: {obj.group.group_code}"
        elif obj.organization:
            return f"Org: {obj.organization.org_name}"
        return "-"
    get_affiliation.short_description = 'Affiliation'
    
    def save_model(self, request, obj, form, change):
        if not change:
            obj.created_by = request.user
        super().save_model(request, obj, form, change)


# ============================================
# AUDIT & SYSTEM TABLES ADMIN
# ============================================

@admin.register(AuditLog)
class AuditLogAdmin(admin.ModelAdmin):
    list_display = ['user', 'action', 'entity_type', 'entity_name', 'created_at']
    list_filter = ['action', 'entity_type', 'created_at']
    search_fields = ['user__username', 'entity_name', 'details']
    readonly_fields = ['user', 'action', 'entity_type', 'entity_id', 'entity_name',
                      'details', 'ip_address', 'user_agent', 'created_at']
    ordering = ['-created_at']
    date_hierarchy = 'created_at'


@admin.register(SystemConfig)
class SystemConfigAdmin(admin.ModelAdmin):
    list_display = ['config_key', 'config_value', 'data_type', 'category', 'is_active']
    list_filter = ['category', 'data_type', 'is_active']
    search_fields = ['config_key', 'config_value', 'description']
    readonly_fields = ['created_at', 'updated_at']
    ordering = ['category', 'config_key']


# ============================================
# TRANSACTION TABLES ADMIN
# ============================================

@admin.register(DakThread)
class DakThreadAdmin(admin.ModelAdmin):
    list_display = ['thread_code', 'subject_summary', 'status', 'dak_count', 'created_on']
    list_filter = ['status']
    search_fields = ['thread_code', 'subject_summary']
    readonly_fields = ['thread_code', 'created_on', 'last_activity', 'dak_count']


class DakMasterAdminForm(forms.ModelForm):
    class Meta:
        model = DakMaster
        fields = '__all__'
        widgets = {
            'subject': forms.Textarea(attrs={'rows': 3}),
            'issue_date': forms.DateInput(attrs={'type': 'date'}),
            'receipt_date': forms.DateInput(attrs={'type': 'date'}),
        }


# Inline classes for DakMaster
class DakPartyMappingInline(admin.TabularInline):
    model = DakPartyMapping
    extra = 1
    raw_id_fields = ['person', 'organization']


class DakGroupMappingInline(admin.TabularInline):
    model = DakGroupMapping
    extra = 1
    raw_id_fields = ['group']


class DakReportDetailsInline(admin.StackedInline):
    model = DakReportDetails
    extra = 0


class DakDispatchDetailsInline(admin.StackedInline):
    model = DakDispatchDetails
    extra = 0


class DakFileAttachmentInline(admin.TabularInline):
    model = DakFileAttachment
    extra = 1
    readonly_fields = ['file_size', 'checksum', 'uploaded_at']


@admin.register(DakMaster)
class DakMasterAdmin(admin.ModelAdmin):
    form = DakMasterAdminForm
    inlines = [
        DakPartyMappingInline,
        DakGroupMappingInline,
        DakReportDetailsInline,
        DakDispatchDetailsInline,
        DakFileAttachmentInline
    ]
    list_display = ['dak_index_no', 'dak_direction', 'dak_category', 'nature', 'subject_short', 'issue_date']
    list_filter = ['dak_direction', 'dak_category', 'reply_mode']
    search_fields = ['dak_index_no', 'iig_ref_no', 'subject']
    raw_id_fields = ['thread', 'nature', 'reply_dak']
    readonly_fields = ['dak_index_no', 'iig_ref_no', 'created_on']
    
    def subject_short(self, obj):
        return obj.subject[:50] + '...' if len(obj.subject) > 50 else obj.subject
    subject_short.short_description = 'Subject'


# ============================================
# MAPPING TABLES ADMIN
# ============================================

@admin.register(DakPartyMapping)
class DakPartyMappingAdmin(admin.ModelAdmin):
    list_display = ['dak', 'person', 'party_role']
    list_filter = ['party_role']
    raw_id_fields = ['dak', 'person', 'organization']


@admin.register(DakGroupMapping)
class DakGroupMappingAdmin(admin.ModelAdmin):
    list_display = ['dak', 'group']
    raw_id_fields = ['dak', 'group']


@admin.register(DakReportDetails)
class DakReportDetailsAdmin(admin.ModelAdmin):
    list_display = ['dak', 'acn_no', 'acn_amount']
    raw_id_fields = ['dak']


@admin.register(DakDispatchDetails)
class DakDispatchDetailsAdmin(admin.ModelAdmin):
    list_display = ['dak', 'dispatch_mode', 'dispatch_date']
    list_filter = ['dispatch_mode']
    raw_id_fields = ['dak']


# ============================================
# FILE & ARCHIVE TABLES ADMIN
# ============================================

@admin.register(DakFileAttachment)
class DakFileAttachmentAdmin(admin.ModelAdmin):
    list_display = ['dak', 'file_name', 'file_size', 'uploaded_by', 'uploaded_at']
    list_filter = ['mime_type']
    search_fields = ['file_name']
    raw_id_fields = ['dak', 'uploaded_by']
    readonly_fields = ['checksum']


@admin.register(DakArchive)
class DakArchiveAdmin(admin.ModelAdmin):
    list_display = ['thread', 'dak_count', 'file_count', 'archived_at']
    readonly_fields = ['zip_file', 'zip_size', 'zip_checksum']


@admin.register(UserNotes)
class UserNotesAdmin(admin.ModelAdmin):
    list_display = ['user', 'content_preview', 'updated_at']
    list_filter = ['updated_at']
    search_fields = ['user__username', 'content']
    readonly_fields = ['created_at', 'updated_at']
    
    def content_preview(self, obj):
        return obj.content[:50] + '...' if obj.content and len(obj.content) > 50 else obj.content
    content_preview.short_description = 'Notes'

# ============================================
# eDW MODULE ADMIN
# ============================================

@admin.register(eDW)
class eDWAdmin(admin.ModelAdmin):
    list_display = [
        'acn_no', 
        'company_name', 
        'group', 
        'amount_paid_by_firm', 
        'status',
        'created_at'
    ]
    list_filter = ['status', 'group', 'dpsu_psu_private_capf']
    search_fields = ['acn_no', 'company_name__org_name', 'rdr_register_number']
    raw_id_fields = ['company_name', 'group', 'dak', 'created_by']
    readonly_fields = ['created_at', 'updated_at']
    
    fieldsets = (
        ('Basic Information', {
            'fields': ('acn_no', 'acn_date', 'rdr_register_number', 'company_name', 'group')
        }),
        ('ACN Details', {
            'fields': ('acn_request_received_date', 'intimation_acn_to_group')
        }),
        ('Financial - Payments', {
            'fields': ('amount_paid_by_firm', 'bank_reference_no', 'firm_payment_date', 
                      'amount_reflected_in_acn', 'amount_utilized', 'balance_unspent_amount',
                      'cancellation_amount', 'refund_amount')
        }),
        ('BQ & MRO', {
            'fields': ('bq_shared_to_firm_date', 'emro_payment_date', 'mro_outgoing_date',
                      'mro_number', 'mro_date')
        }),
        ('Testing & Trial', {
            'fields': ('testing_changes_receipt_no', 'testing_changes_receipt_date',
                      'trial_title', 'no_of_test_samples_planned', 'no_of_test_conducted',
                      'trial_tentative_date', 'account_date')
        }),
        ('Job & TE', {
            'fields': ('job_number_alloted_by_i2g', 'te_number_outgoing_date', 'te_number_incoming_date')
        }),
        ('Report & Dispatch', {
            'fields': ('report_received_from_group', 'trial_report_no', 'trial_report_issued_on',
                      'report_to_whom_dispatched', 'dispatch_date', 'speed_post_no', 'speed_post_date')
        }),
        ('GST', {
            'fields': ('gst_paid_on_rcm_basis_transaction_no', 'gst_paid_on_rcm_basis_date')
        }),
        ('Closure & Status', {
            'fields': ('for_closure', 'dpsu_psu_private_capf', 'code_head', 'status', 'remarks')
        }),
        ('Audit', {
            'fields': ('dak', 'created_by', 'created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
    
    def save_model(self, request, obj, form, change):
        if not change:
            obj.created_by = request.user
        super().save_model(request, obj, form, change)

# ── Work Task Admin ───────────────────────────────────────────────────────────

@admin.register(WorkTask)
class WorkTaskAdmin(admin.ModelAdmin):
    list_display  = ('title', 'assigned_to', 'assigned_by', 'priority', 'status', 'deadline', 'created_at')
    list_filter   = ('priority', 'status', 'assigned_to')
    search_fields = ('title', 'description', 'assigned_to__username')
    date_hierarchy = 'created_at'
    readonly_fields = ('created_at', 'updated_at', 'completed_at')
    autocomplete_fields = ['assigned_to', 'assigned_by']
    list_select_related = ('assigned_to', 'assigned_by', 'linked_dak')
    ordering = ('-created_at',)
    fieldsets = (
        ('Task Details', {
            'fields': ('title', 'description', 'priority', 'status', 'deadline')
        }),
        ('Assignment', {
            'fields': ('assigned_to', 'assigned_by', 'linked_dak')
        }),
        ('Completion', {
            'fields': ('completion_note', 'completed_at'),
            'classes': ('collapse',),
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',),
        }),
    )


@admin.register(NTR)
class NTRAdmin(admin.ModelAdmin):
    list_display  = ('ntr_number', 'title', 'group', 'organization', 'status', 'is_feasible', 'created_at')
    list_filter   = ('status', 'is_feasible', 'group', 'year')
    search_fields = ('ntr_number', 'title', 'organization__org_name')
    readonly_fields = ('ntr_number', 'sequence_no', 'year', 'created_at', 'updated_at')
    ordering = ('-created_at',)


@admin.register(BQ)
class BQAdmin(admin.ModelAdmin):
    list_display  = ('bq_number', 'ntr', 'revision_no', 'grand_total', 'status', 'issue_date')
    list_filter   = ('status',)
    search_fields = ('bq_number', 'ntr__ntr_number')
    readonly_fields = ('bq_number', 'grand_total', 'created_at', 'updated_at')
    ordering = ('-created_at',)
