"""
Column registry for the custom report builder (#21).

Rather than hand-listing every one of eDW's ~50 fields and eTOT's ~55
(error-prone, and goes stale the moment someone adds a field to the
model), this introspects each model's real fields and builds the
checklist from them automatically. A small per-model OVERRIDES dict
handles the handful of fields that need special treatment — mainly
foreign keys, where we want to show a human-readable related field
(e.g. the company's name, not "OrganizationMaster object (4)").
"""

from .models import eDW, eTOT, eIIGVisit

# Fields left out of the picker entirely — not meaningful to a human reading a report
_COMMON_EXCLUDE = {'id', 'public_id'}

# field_name -> (label override, dotted accessor override)
_OVERRIDES = {
    'eDW': {
        'company_name': ('Company Name', 'company_name.org_name'),
        'group':        ('Group', 'group.group_name'),
        'dak':          ('Linked Dak', 'dak.dak_index_no'),
        'created_by':   ('Created By', 'created_by.username'),
    },
    'eTOT': {
        'technical_group':  ('Technical Group', 'technical_group.group_name'),
        'point_of_contact': ('Point of Contact', 'point_of_contact.person_name'),
        'licensee_company': ('Licensee Company', 'licensee_company.org_name'),
        'created_by':       ('Created By', 'created_by.username'),
    },
    'eIIGVisit': {
        'created_by': ('Created By', 'created_by.username'),
        'visitor_names': ('Visitor Names', 'visitor_names'),
    },
}


_KNOWN_ACRONYMS = {
    'acn', 'rdr', 'bq', 'gst', 'rcm', 'dpsu', 'psu', 'capf', 'mro', 'te',
    'jcc', 'i2g', 'tnf', 'nom', 'eoi', 'cec', 'tac', 'dg', 'mss', 'peso',
    'latot', 'ttd', 'emro', 'ta', 'id', 'ntr', 'iig', 'dcmm', 'tot',
}


def _label_from_field_name(name):
    words = name.replace('_', ' ').strip().split(' ')
    return ' '.join(w.upper() if w.lower() in _KNOWN_ACRONYMS else w.title() for w in words)


def _build_columns(model, model_key):
    overrides = _OVERRIDES.get(model_key, {})
    columns = []
    for f in model._meta.get_fields():
        # Only real columns on THIS model's table — excludes reverse FK/M2M
        # relations (e.g. eDW.bqs, eDW.ntr, eDW.dak_links) which aren't
        # single values a report row could show.
        if not getattr(f, 'concrete', False):
            continue
        name = f.name
        if name in _COMMON_EXCLUDE:
            continue
        if name in overrides:
            label, accessor = overrides[name]
        else:
            label = _label_from_field_name(name)
            accessor = name
        columns.append({'key': name, 'label': label, 'accessor': accessor})
    
    # Also append any overrides that were NOT added
    for name, (label, accessor) in overrides.items():
        if name not in [c['key'] for c in columns]:
            columns.append({'key': name, 'label': label, 'accessor': accessor})
            
    return columns


EDW_COLUMNS = _build_columns(eDW, 'eDW')
ETOT_COLUMNS = _build_columns(eTOT, 'eTOT')
EIIG_COLUMNS = _build_columns(eIIGVisit, 'eIIGVisit')

# Curated default column set for each module's one-click "quick report" —
# as opposed to the full picker, which exposes every field. Keeps the
# same field choices used for the read-only SQL views (migration 0004)
# for consistency between what a direct DB query and a generated report
# both consider "the sensible summary" of each module.
DEFAULT_REPORT_COLUMNS = {
    'edw': ['acn_no', 'rdr_register_number', 'company_name', 'group', 'acn_date',
            'workflow_stage', 'status', 'is_closed', 'amount_paid_by_firm',
            'dak', 'created_by', 'created_at'],
    'etot': ['tot_file_no', 'product_technology', 'technology_category', 'stage',
              'licensee_name', 'latot_no', 'ttd_no', 'no_of_licenses_approved',
              'technical_group', 'point_of_contact', 'licensee_company',
              'created_by', 'created_at'],
    'eiig': ['visit_id', 'date_of_visit', 'visitor_names', 'firm_name', 'firm_state', 'company_category',
             'company_sub_category', 'created_by', 'created_at'],
}


def get_default_columns(module_key):
    """The curated column subset for module_key, in registry order, filtered
    down to the keys in DEFAULT_REPORT_COLUMNS (skips silently if a key
    listed above doesn't actually exist on the model, instead of raising)."""
    info = MODULE_REGISTRY.get(module_key)
    if not info:
        return []
    by_key = {c['key']: c for c in info['columns']}
    default_cols = [by_key[k] for k in DEFAULT_REPORT_COLUMNS.get(module_key, []) if k in by_key]
    
    # Append active dynamic columns automatically
    for c in info['columns']:
        if c['key'].startswith('extra_col_') and c['key'] not in [col['key'] for col in default_cols]:
            default_cols.append(c)
            
    return default_cols

DATE_FIELDS = {
    'dak': [
        ('basis_date', 'Receipt/Dispatch Date (Default)'),
        ('receipt_date', 'Receipt Date'),
        ('dispatch_details__dispatch_date', 'Dispatch Date'),
        ('issue_date', 'Letter Issue Date'),
        ('created_on', 'Entry Date'),
        ('tbrl_date', 'TBRL Diary Date'),
        ('reply_due_date', 'Reply Due Date'),
    ],
    'edw': [
        ('created_at', 'Entry Date (Default)'),
        ('acn_date', 'ACN Date'),
        ('acn_request_received_date', 'ACN Request Received'),
        ('bq_shared_to_firm_date', 'BQ Shared to Firm'),
        ('firm_payment_date', 'Firm Payment Date'),
        ('testing_changes_receipt_date', 'Testing Changes Receipt'),
        ('emro_payment_date', 'e-MRO Payment Date'),
        ('mro_outgoing_date', 'MRO Outgoing Date'),
        ('mro_date', 'MRO Date'),
        ('trial_tentative_date', 'Trial Tentative Date'),
        ('account_date', 'Account Date'),
        ('te_number_outgoing_date', 'T.E. Outgoing Date'),
        ('te_number_incoming_date', 'T.E. Incoming Date'),
        ('report_received_from_group', 'Report Received from Group'),
        ('trial_report_issued_on', 'Trial Report Issued On'),
        ('dispatch_date', 'Dispatch Date'),
        ('speed_post_date', 'Speed Post Date'),
    ],
    'etot': [
        ('created_at', 'Entry Date (Default)'),
        ('meeting_held_on', 'Meeting Held On'),
        ('minute_signed_by_chairman_on', 'Minute Signed by Chairman'),
        ('minute_approved_by_director_on', 'Minute Approved by Director'),
        ('tnf_initiated_by_group_on', 'TNF Initiated by Group'),
        ('tnf_certificate_issued_by_director_on', 'TNF Certificate Issued'),
        ('tnf_no_allotted_by_diitm_on', 'TNF No. Allotted by DIITM'),
        ('eoi_hosting_on_portal', 'EOI Hosting on Portal'),
        ('cec_constitution_on', 'CEC Constitution'),
        ('cec_meeting_held_on', 'CEC Meeting Held On'),
        ('cec_report_signed_by_chairman_on', 'CEC Report Signed by Chairman'),
        ('cec_min_forwarded_by_director_on', 'CEC Min Forwarded by Director'),
        ('cec_recommended_by_dg_mss_on', 'CEC Recommended by DG(MSS)'),
        ('recommended_cec_report_to_diitm_on', 'Recommended CEC Report to DIITM'),
        ('cec_approved_by_dg_pc_s7_on', 'CEC Approved by DG(PC & S7)'),
        ('tac_constitution_by_dir_dg_mss_on', 'TAC Constitution by Dir/DG(MSS)'),
    ],
    'eiig': [
        ('date_of_visit', 'Date of Visit (Default)'),
        ('created_at', 'Entry Date'),
    ]
}

class DynamicModuleRegistry(dict):
    def get(self, key, default=None):
        val = super().get(key, default)
        if val:
            return self._inject_extra_columns(key, val)
        return val

    def __getitem__(self, key):
        val = super().__getitem__(key)
        return self._inject_extra_columns(key, val)

    def items(self):
        for k, v in super().items():
            yield k, self._inject_extra_columns(k, v)

    def values(self):
        for k, v in super().items():
            yield self._inject_extra_columns(k, v)

    def _inject_extra_columns(self, module_key, info_dict):
        new_info = dict(info_dict)
        from .models import ModuleExtraColumn
        try:
            extra_cols = ModuleExtraColumn.objects.filter(module=module_key, is_active=True).order_by('sort_order')
            dynamic_cols = []
            for col in extra_cols:
                dynamic_cols.append({
                    'key': f'extra_col_{col.column_key}',
                    'label': col.column_label,
                    'accessor': f'extra_col_{col.column_key}',
                })
            new_info['columns'] = list(info_dict['columns']) + dynamic_cols
        except Exception:
            pass
        return new_info


MODULE_REGISTRY = DynamicModuleRegistry({
    'edw':  {'label': 'eDW',  'model': eDW,       'columns': EDW_COLUMNS},
    'etot': {'label': 'eToT', 'model': eTOT,      'columns': ETOT_COLUMNS},
    'eiig': {'label': 'eIIG', 'model': eIIGVisit, 'columns': EIIG_COLUMNS},
})


def resolve_value(obj, accessor):
    """Resolve a dotted accessor path against an instance, e.g.
    'company_name.org_name' -> obj.company_name.org_name. Returns '' for
    any broken link (null FK, missing attr) instead of raising — a
    half-filled eDW record shouldn't crash the whole report."""
    if accessor.startswith('extra_col_'):
        col_key = accessor[10:]
        if hasattr(obj, '_extra_col_values'):
            return obj._extra_col_values.get(col_key, '')
        
        from .models import ModuleExtraColumnValue
        val_obj = ModuleExtraColumnValue.objects.filter(
            record_pk=str(obj.pk),
            column__column_label__iexact=col_key.replace('_', ' ')
        ).first()
        if not val_obj:
            if col_key.isdigit():
                val_obj = ModuleExtraColumnValue.objects.filter(
                    record_pk=str(obj.pk),
                    column_id=int(col_key)
                ).first()
            else:
                from .models import ModuleExtraColumn
                active_col = ModuleExtraColumn.objects.filter(is_active=True).all()
                target_col = next((c for c in active_col if c.column_key == col_key), None)
                if target_col:
                    val_obj = ModuleExtraColumnValue.objects.filter(
                        record_pk=str(obj.pk),
                        column=target_col
                    ).first()
        return val_obj.value if val_obj else ''

    value = obj
    for part in accessor.split('.'):
        if value is None:
            return ''
        value = getattr(value, part, None)
    if value is None:
        return ''
    if callable(value):
        try:
            value = value()
        except Exception:
            return ''
    import datetime as _dt
    if isinstance(value, _dt.datetime):
        return value.strftime('%d-%b-%Y %H:%M')
    if isinstance(value, _dt.date):
        return value.strftime('%d-%b-%Y')
    return value
