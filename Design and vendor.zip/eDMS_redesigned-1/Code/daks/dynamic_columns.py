import collections
from django.db import transaction

def get_extra_col_context(module_key, record_pk):
    """
    Return a list of dicts ready for templates:
      [{'col': ModuleExtraColumn instance, 'value': str or ''}, ...]
    """
    try:
        from .models import ModuleExtraColumn, ModuleExtraColumnValue
        cols = ModuleExtraColumn.objects.filter(
            module=module_key, is_active=True
        ).order_by('sort_order')
        
        if not record_pk:
            return [{'col': c, 'value': ''} for c in cols]
            
        val_map = {
            v.column_id: v.value
            for v in ModuleExtraColumnValue.objects.filter(
                column__in=cols, record_pk=str(record_pk)
            )
        }
        return [{'col': c, 'value': val_map.get(c.pk, '')} for c in cols]
    except Exception:
        return []

def save_extra_col_values(module_key, record_pk, post_data):
    """
    Persist extra column values POSTed as extra_col_<pk>=<value> or extra_col_<column_key>=<value>.
    """
    try:
        from .models import ModuleExtraColumn, ModuleExtraColumnValue
        cols = ModuleExtraColumn.objects.filter(module=module_key, is_active=True)
        
        with transaction.atomic():
            for col in cols:
                # Try finding value by PK first, then by column_key
                key_pk = f'extra_col_{col.pk}'
                key_name = f'extra_col_{col.column_key}'
                value = post_data.get(key_pk)
                if value is None:
                    value = post_data.get(key_name)
                
                if value is not None:
                    value = str(value).strip()
                    ModuleExtraColumnValue.objects.update_or_create(
                        column=col,
                        record_pk=str(record_pk),
                        defaults={'value': value},
                    )
    except Exception:
        pass  # Never block the main save flow

def prefetch_extra_col_values(module_key, records):
    """
    Prefetches active dynamic column values for a list of records in a single query.
    Attaches to each record:
      - `_extra_col_values`: dict of column_key -> value
      - `extra_values`: list of values matching the sorted active columns order.
    Returns the queryset of active columns for this module.
    """
    try:
        from .models import ModuleExtraColumn, ModuleExtraColumnValue
        
        cols = ModuleExtraColumn.objects.filter(
            module=module_key, is_active=True
        ).order_by('sort_order')
        
        record_pks = [str(r.pk) for r in records if r.pk]
        
        if not record_pks or not cols.exists():
            for r in records:
                r._extra_col_values = {}
                r.extra_values = [''] * cols.count()
            return cols
            
        vals = ModuleExtraColumnValue.objects.filter(
            column__in=cols, record_pk__in=record_pks
        ).select_related('column')
        
        val_map = collections.defaultdict(dict)
        for v in vals:
            val_map[v.record_pk][v.column_id] = v.value
            val_map[v.record_pk][v.column.column_key] = v.value
            
        for r in records:
            r_pk = str(r.pk)
            r_vals = val_map.get(r_pk, {})
            r._extra_col_values = r_vals
            r.extra_values = [r_vals.get(c.pk, '') for c in cols]
            
        return cols
    except Exception:
        return []
