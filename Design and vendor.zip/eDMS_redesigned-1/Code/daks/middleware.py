"""
Custom middleware for eDMS.

NoCacheForAuthenticatedMiddleware
----------------------------------
Why this exists:
The "Logout doesn't work" complaint usually isn't a server-side bug — Django's
logout view does clear the session correctly. The real cause is the browser's
own page cache: after logging out, pressing the Back button reloads a
previously cached, already-rendered authenticated page from disk/memory
cache instead of asking the server again, so it *looks* like the user is
still logged in.

This middleware stops the browser (and any proxy) from caching responses
served while the request had an authenticated user, so Back/forward always
re-validates with the server, which will correctly redirect to /login/.
"""

from django.utils.cache import add_never_cache_headers


class NoCacheForAuthenticatedMiddleware:
    """Add no-store/no-cache headers to every response for logged-in users."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)

        user = getattr(request, 'user', None)
        if user is not None and getattr(user, 'is_authenticated', False):
            add_never_cache_headers(response)
            response['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
            response['Pragma'] = 'no-cache'

        return response
