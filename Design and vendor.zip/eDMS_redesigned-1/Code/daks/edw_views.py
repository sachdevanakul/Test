"""
eDW Module — Deposit Work Views
Complete workflow: Inquiry → NTR → Feasibility → BQ → Payment → 
ACN Request → ACN Received → Trial → Report → JCC → Final Report → Closure
Every stage is linked to one or more Daks.
"""

from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.http import HttpResponse, JsonResponse
from django.db.models import Q, Sum, Count, Avg
from django.db import transaction
from django.utils import timezone
from .models import (
    eDW, eDWDakLink, eDWNTR, eDWBQ,
    OrganizationMaster, OrganizationTypeMaster, GroupMaster,
    DakMaster, DakPartyMapping, DakGroupMapping
)
from .forms import eDWForm
import pandas as pd
from io import BytesIO
from decimal import Decimal


# ─────────────────────────────────────────────────────────────────────────────
# HELPER: Auto-populate eDW from linked Dak
# When a dak is linked as the initial inquiry, pull sender org/group from it
# ─────────────────────────────────────────────────────────────────────────────

def _sync_edw_from_dak(edw_obj, dak_obj):
    """Pull sender org, group, and date from inquiry dak into eDW record."""
    changed = False
    try:
        if not edw_obj.company_name_id:
            sender = (DakPartyMapping.objects
                      .filter(dak=dak_obj, party_role__role_code='SENDER')
                      .select_related('organization', 'person__organization')
                      .first())
            if sender:
                org = sender.organization or (
                    sender.person.organization if sender.person else None
                )
                if org:
                    edw_obj.company_name_id = org.id
                    changed = True

        if not edw_obj.group_id:
            grp = dak_obj.testing_group_id or (DakGroupMapping.objects.filter(dak=dak_obj)
                   .values_list('group_id', flat=True).first())
            if grp:
                edw_obj.group_id = grp
                changed = True

        if not edw_obj.acn_date and dak_obj.issue_date:
            edw_obj.acn_date = dak_obj.issue_date
            changed = True
    except Exception:
        pass
    return changed


# ─────────────────────────────────────────────────────────────────────────────
# HELPER: Graph context for eDW form tabs
# ─────────────────────────────────────────────────────────────────────────────

def _edw_graph_context():
    qs = eDW.objects.all()
    fin = qs.aggregate(
        avg_paid=Avg('amount_paid_by_firm'),
        avg_acn=Avg('amount_reflected_in_acn'),
        avg_utilized=Avg('amount_utilized'),
        avg_balance=Avg('balance_unspent_amount'),
        total_utilized=Sum('amount_utilized'),
        total_balance=Sum('balance_unspent_amount'),
    )
    return {
        'edw_status_counts': {
            'active':  qs.filter(status='ONGOING').count(),
            'closed':  qs.filter(status='COMPLETED').count() + qs.filter(workflow_stage='CLOSED').count(),
            'pending': qs.filter(status='PENDING').count(),
        },
        'edw_closure_counts': {
            'closure': qs.filter(for_closure=True).count(),
            'active':  qs.filter(for_closure=False).count(),
        },
        'edw_category_counts': {
            'dpsu':    qs.filter(dpsu_psu_private_capf='DPSU').count(),
            'psu':     qs.filter(dpsu_psu_private_capf='PSU').count(),
            'private': qs.filter(dpsu_psu_private_capf='PRIVATE').count(),
            'capf':    qs.filter(dpsu_psu_private_capf='CAPF').count(),
            'msme':    qs.filter(dpsu_psu_private_capf='MSME').count(),
        },
        'edw_fin': {k: float(v or 0) for k, v in fin.items()},
        'edw_bq':  {
            'shared':  qs.exclude(bq_shared_to_firm_date__isnull=True).count(),
            'pending': qs.filter(bq_shared_to_firm_date__isnull=True).count(),
        },
        'edw_mro': {
            'issued':  qs.exclude(mro_number='').exclude(mro_number__isnull=True).count(),
            'pending': qs.filter(Q(mro_number='') | Q(mro_number__isnull=True)).count(),
        },
        'edw_trial': {
            'planned':   int(qs.aggregate(s=Sum('no_of_test_samples_planned'))['s'] or 0),
            'conducted': int(qs.aggregate(s=Sum('no_of_test_conducted'))['s'] or 0),
        },
        'edw_report': {
            'dispatched': qs.exclude(dispatch_date__isnull=True).count(),
            'pending':    qs.filter(dispatch_date__isnull=True).count(),
        },
        # Workflow stage counts
        'edw_workflow': {
            stage: qs.filter(workflow_stage=stage).count()
            for stage, _ in eDW.WORKFLOW_STAGE_CHOICES
        } if hasattr(eDW, 'WORKFLOW_STAGE_CHOICES') else {},
    }


# ─────────────────────────────────────────────────────────────────────────────
# HELPER: Build dak auto-link from a stage dak
# ─────────────────────────────────────────────────────────────────────────────

def _link_dak_to_edw(edw_obj, dak, stage, user, notes=''):
    """Link a dak to an eDW record at a specific workflow stage."""
    try:
        obj, created = eDWDakLink.objects.get_or_create(
            edw=edw_obj, dak=dak, stage=stage,
            defaults={'linked_by': user, 'notes': notes}
        )
        return obj, created
    except Exception:
        return None, False


# ─────────────────────────────────────────────────────────────────────────────
# DASHBOARD
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def edw_dashboard(request):

    # ── Module access guard ──────────────────────────────────────
    if not request.user.is_staff:
        from .models import UserProfile
        try:
            profile = request.user.profile
        except UserProfile.DoesNotExist:
            profile = UserProfile.objects.create(user=request.user)
        if not getattr(profile, 'can_access_edw', False):
            from django.contrib import messages as _msg
            _msg.error(request, 'You do not have permission to access this module.')
            return redirect('daks:home')
    # ─────────────────────────────────────────────────────────────
    qs = (eDW.objects.all()
          .select_related('company_name', 'group', 'created_by', 'dak', 'thread', 'dak__thread')
          .prefetch_related('dak_links', 'bqs')
          .order_by('-created_at'))

    search = request.GET.get('search', '').strip()
    if search:
        qs = qs.filter(
            Q(acn_no__icontains=search) |
            Q(company_name__org_name__icontains=search) |
            Q(rdr_register_number__icontains=search) |
            Q(trial_title__icontains=search)
        )
    if request.GET.get('status'):
        qs = qs.filter(status=request.GET['status'])
    if request.GET.get('group'):
        qs = qs.filter(group_id=request.GET['group'])
    if request.GET.get('stage'):
        # Accept both old and new stage codes for backward compatibility
        stage_val = request.GET['stage']
        qs = qs.filter(workflow_stage=request.GET['stage'])

    stats = qs.aggregate(
        total_paid=Sum('amount_paid_by_firm'),
        total_utilized=Sum('amount_utilized'),
        total_balance=Sum('balance_unspent_amount'),
        total_records=Count('id'),
    )

    paginator = Paginator(qs, 50)
    try:
        page_obj = paginator.page(request.GET.get('page', 1))
    except (PageNotAnInteger, EmptyPage):
        page_obj = paginator.page(1)

    # Use the full unfiltered queryset for global status counts so the stat
    # cards always reflect reality regardless of the current filter.
    _all_edw = eDW.objects.all()
    ongoing_count   = _all_edw.filter(status='ONGOING').count()
    completed_count = _all_edw.filter(status='COMPLETED').count()

    from .dynamic_columns import prefetch_extra_col_values
    extra_cols = prefetch_extra_col_values('edw', page_obj.object_list)

    return render(request, 'daks/edw_dashboard.html', {
        'page_obj':       page_obj,
        'total_count':    stats['total_records'] or 0,
        'ongoing_count':  ongoing_count,
        'completed_count': completed_count,
        'search_query':   search,
        'status_filter':  request.GET.get('status', ''),
        'group_filter':   request.GET.get('group', ''),
        'stage_filter':   request.GET.get('stage', ''),
        'groups':         list(GroupMaster.objects.filter(is_active=True).values('id', 'group_name')),
        'total_paid':     stats['total_paid'] or Decimal('0'),
        'total_utilized': stats['total_utilized'] or Decimal('0'),
        'total_balance':  stats['total_balance'] or Decimal('0'),
        'workflow_stages': getattr(eDW, 'WORKFLOW_STAGE_CHOICES', []),
        'extra_cols':     extra_cols,
    })


# ─────────────────────────────────────────────────────────────────────────────
# DETAIL
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def edw_detail(request, public_id):
    record = get_object_or_404(
        eDW.objects.select_related(
            'company_name', 'group', 'created_by', 'dak'
        ).prefetch_related(
            'dak_links__dak', 'dak_links__linked_by',
            'bqs', 'ntr'
        ),
        public_id=public_id
    )
    # All daks linked at any stage — for the workflow timeline
    dak_links = record.dak_links.all().select_related('dak', 'linked_by').order_by('linked_at')

    # NTR if exists
    ntr = getattr(record, 'ntr', None)

    # BQs
    bqs = record.bqs.all().order_by('-created_at')

    # Pending daks from dak_list that mention this firm — for easy linking
    firm_daks = []
    if record.company_name:
        firm_daks = (DakMaster.objects.filter(
            is_active=True,
        ).filter(
            Q(party_mappings__organization=record.company_name) |
            Q(party_mappings__person__organization=record.company_name)
        ).exclude(
            edw_links__edw=record
        ).distinct().order_by('-created_on')[:50])

    return render(request, 'daks/edw_detail.html', {
        'record':    record,
        'dak_links': dak_links,
        'ntr':       ntr,
        'bqs':       bqs,
        'firm_daks': firm_daks,
        'stage_choices': eDWDakLink.STAGE_CHOICES,
        'extra_cols': _extra_col_context('edw', record.pk),
    })


# ─────────────────────────────────────────────────────────────────────────────
# CREATE — when creating from a Dak, auto-fill everything
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def edw_create(request):
    prefill_dak = None
    dak_id = request.GET.get('dak') or request.POST.get('dak_id')
    if dak_id:
        try:
            prefill_dak = DakMaster.objects.select_related(
                'dak_category', 'thread', 'header'
            ).get(pk=dak_id)
        except DakMaster.DoesNotExist:
            pass

    # Check for duplicate creation in the same thread
    if prefill_dak and prefill_dak.thread:
        existing_edw = eDW.objects.filter(thread=prefill_dak.thread).first()
        if existing_edw:
            messages.warning(request, f"An eDW record already exists for this thread: {existing_edw.acn_no}")
            return redirect('daks:edw_detail', public_id=existing_edw.public_id)

    if request.method == 'POST':
        form = eDWForm(request.POST)
        if form.is_valid():
            with transaction.atomic():
                edw = form.save(commit=False)
                edw.created_by = request.user
                edw.workflow_stage = 'IFA'

                # Link the inquiry dak and bind the thread backbone
                if prefill_dak:
                    edw.dak = prefill_dak
                    edw.thread = prefill_dak.thread
                    
                    # Auto-fill from Dak
                    if not edw.trial_title and prefill_dak.subject:
                        edw.trial_title = prefill_dak.subject
                    
                    # Determine route path based on prefill_dak's header
                    header_name = prefill_dak.header.header_name.upper() if prefill_dak.header else ''
                    if 'NTR' in header_name:
                        edw.ntr_dak = prefill_dak
                        edw.workflow_stage = 'NTR'
                    else:
                        # Default is Workflow A: IFA
                        edw.ifa_dak = prefill_dak
                        edw.workflow_stage = 'IFA'

                    _sync_edw_from_dak(edw, prefill_dak)

                edw.save()
                form.save_extra_fields(edw)

                # Auto-create eDWDakLink for backward compatibility of timeline
                if prefill_dak:
                    stage_lbl = 'NTR' if 'NTR' in (prefill_dak.header.header_name.upper() if prefill_dak.header else '') else 'IFA'
                    _link_dak_to_edw(edw, prefill_dak, stage_lbl, request.user,
                                     'Initial inquiry/trigger dak — auto-linked on eDW creation')

                # Auto-create NTR only for Workflow B (Direct NTR)
                header_name = prefill_dak.header.header_name.upper() if (prefill_dak and prefill_dak.header) else ''
                is_direct_ntr = 'NTR' in header_name
                
                if prefill_dak and edw.group and is_direct_ntr:
                    year = timezone.now().year
                    ntr_num, seq = eDWNTR.generate_number(edw.group, year)
                    eDWNTR.objects.create(
                        edw=edw,
                        ntr_number=ntr_num,
                        sequence_no=seq,
                        year=year,
                        inquiry_dak=prefill_dak,
                        ntr_date=timezone.now().date(),
                        created_by=request.user,
                        status='DRAFT',
                    )
                    edw.workflow_stage = 'NTR'
                    edw.save(update_fields=['workflow_stage'])

            messages.success(request,
                f'eDW record {edw.acn_no} created.')
            return redirect('daks:edw_detail', public_id=edw.public_id)
    else:
        initial = {}
        if prefill_dak:
            initial['dak'] = prefill_dak.pk
            # Auto-fill org from dak sender
            sender = (DakPartyMapping.objects
                      .filter(dak=prefill_dak, party_role__role_code='SENDER')
                      .select_related('organization', 'person__organization')
                      .first())
            if sender:
                org = sender.organization or (
                    sender.person.organization if sender.person else None)
                if org:
                    initial['company_name'] = org.pk
            # Auto-fill group
            grp = (DakGroupMapping.objects.filter(dak=prefill_dak)
                   .values_list('group_id', flat=True).first())
            if grp:
                initial['group'] = grp
            # Auto-fill date from dak issue date
            initial['acn_date'] = prefill_dak.issue_date
            initial['ifa_mail_date'] = prefill_dak.issue_date
            if prefill_dak.subject:
                initial['trial_title'] = prefill_dak.subject
            
            initial['ifa_no'] = eDW.generate_ifa_no()

        form = eDWForm(initial=initial)

    ctx = {
        'form':        form,
        'title':       'Create eDW Record',
        'prefill_dak': prefill_dak,
        'existing_records': eDW.objects.all().select_related('company_name').order_by('-created_at'),
        'groups': GroupMaster.objects.filter(is_active=True).order_by('group_name'),
    }
    ctx.update(_edw_graph_context())
    return render(request, 'daks/edw_form.html', ctx)


# ─────────────────────────────────────────────────────────────────────────────
# EDIT
# ─────────────────────────────────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def edw_edit(request, public_id):
    record = get_object_or_404(eDW, public_id=public_id)

    # Prevent editing closed records
    if record.is_closed and not request.user.is_superuser:
        messages.error(request, 'This eDW record is closed and cannot be edited.')
        return redirect('daks:edw_detail', public_id=public_id)

    if request.method == 'POST':
        form = eDWForm(request.POST, instance=record)
        if form.is_valid():
            with transaction.atomic():
                edw = form.save(commit=False)
                if edw.dak_id and not edw.thread_id:
                    edw.thread = edw.dak.thread
                if edw.dak_id:
                    _sync_edw_from_dak(edw, edw.dak)
                edw.save()
                form.save_extra_fields(edw)
            messages.success(request, f'eDW record {record.acn_no} updated.')
            return redirect('daks:edw_detail', public_id=record.public_id)
    else:
        form = eDWForm(instance=record)

    ctx = {
        'form':       form,
        'title':      f'Edit eDW — {record.acn_no}',
        'record':     record,
        'extra_cols': _extra_col_context('edw', record.pk),
        'existing_records': eDW.objects.all().select_related('company_name').exclude(pk=record.pk).order_by('-created_at'),
        'groups': GroupMaster.objects.filter(is_active=True).order_by('group_name'),
    }
    ctx.update(_edw_graph_context())
    return render(request, 'daks/edw_form.html', ctx)


# ─────────────────────────────────────────────────────────────────────────────
# LINK DAK TO EDW WORKFLOW STAGE (AJAX)
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def edw_link_dak(request, public_id):
    """Link any existing dak to an eDW record at a specific workflow stage."""
    record = get_object_or_404(eDW, public_id=public_id)

    if request.method == 'POST':
        dak_id = request.POST.get('dak_id')
        stage  = request.POST.get('stage')
        notes  = request.POST.get('notes', '')

        if not dak_id or not stage:
            messages.error(request, 'Dak and stage are required.')
            return redirect('daks:edw_detail', public_id=public_id)

        try:
            dak = DakMaster.objects.get(pk=dak_id, is_active=True)
        except DakMaster.DoesNotExist:
            messages.error(request, 'Dak not found.')
            return redirect('daks:edw_detail', public_id=public_id)

        obj, created = _link_dak_to_edw(record, dak, stage, request.user, notes)

        if created:
            # Auto-advance workflow stage
            stage_order = {
                'IFA':           'IFA',
                'NTR':           'NTR',
                'NTR_FORWARD':   'NTR',
                'FEASIBILITY':   'NTR',
                'BQ':            'BQ',
                'EMRO':          'EMRO',
                'ACN':           'ACN',
                'ACN_TO_GROUP':  'ACN',
                'TE':            'TE',
                'TRIAL':         'TRIAL',
                'REPORT':        'REPORT',
                'CLOSURE':       'REPORT',
            }
            # Stage ordering for comparison
            STAGE_ORDER = ['IFA','NFA','NTR','BQ','EMRO','ACN','TE','TRIAL','REPORT','CLOSED']
            new_stage = stage_order.get(stage)
            if new_stage and record.workflow_stage != 'CLOSED':
                # Only advance forward, never go backward
                cur_idx = STAGE_ORDER.index(record.workflow_stage) if record.workflow_stage in STAGE_ORDER else -1
                new_idx = STAGE_ORDER.index(new_stage) if new_stage in STAGE_ORDER else -1
                if new_idx > cur_idx:
                    record.workflow_stage = new_stage
                    record.save(update_fields=['workflow_stage'])

            # Special: if this is a feasibility reply and it's the NTR forward stage,
            # update NTR status too
            if stage == 'FEASIBILITY' and hasattr(record, 'ntr') and record.ntr:
                record.ntr.feasibility_dak = dak
                record.ntr.feasibility_date = dak.issue_date or timezone.now().date()
                record.ntr.is_feasible = True
                record.ntr.status = 'FEASIBLE'
                record.ntr.save()

            messages.success(request,
                f'Dak {dak.dak_index_no} linked at stage "{obj.get_stage_display()}".')
        else:
            messages.info(request, f'Dak already linked at this stage.')

    return redirect('daks:edw_detail', public_id=public_id)


# ─────────────────────────────────────────────────────────────────────────────
# UNLINK DAK FROM EDW
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def edw_unlink_dak(request, public_id, link_pk):
    record = get_object_or_404(eDW, public_id=public_id)
    link   = get_object_or_404(eDWDakLink, pk=link_pk, edw=record)
    if request.method == 'POST':
        dak_no = link.dak.dak_index_no
        link.delete()
        messages.success(request, f'Dak {dak_no} unlinked.')
    return redirect('daks:edw_detail', public_id=public_id)


# ─────────────────────────────────────────────────────────────────────────────
# NTR MANAGEMENT (within eDW context)
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def edw_ntr_create(request, public_id):
    """Create NTR for an eDW record (if not already created)."""
    record = get_object_or_404(eDW, public_id=public_id)
    if hasattr(record, 'ntr') and record.ntr:
        messages.info(request, f'NTR {record.ntr.ntr_number} already exists for this record.')
        return redirect('daks:edw_detail', public_id=public_id)

    if request.method == 'POST':
        year    = timezone.now().year
        grp     = record.group
        if not grp:
            messages.error(request, 'Assign a Group to this eDW record before creating NTR.')
            return redirect('daks:edw_detail', public_id=public_id)

        ntr_num, seq = eDWNTR.generate_number(grp, year)
        ntr = eDWNTR.objects.create(
            edw=record,
            ntr_number=ntr_num,
            sequence_no=seq,
            year=year,
            inquiry_dak=record.dak,
            ntr_date=timezone.now().date(),
            is_feasible=request.POST.get('is_feasible', 'true') == 'true',
            feasibility_remarks=request.POST.get('remarks', ''),
            status='DRAFT',
            created_by=request.user,
        )
        record.workflow_stage = 'NTR'
        record.save(update_fields=['workflow_stage'])
        messages.success(request, f'NTR {ntr.ntr_number} created successfully.')
    return redirect('daks:edw_detail', public_id=public_id)


@login_required
def edw_ntr_forward(request, public_id):
    """Mark NTR as forwarded to group — link the forwarding dak."""
    record = get_object_or_404(eDW, public_id=public_id)
    ntr    = get_object_or_404(eDWNTR, edw=record)

    if request.method == 'POST':
        dak_id = request.POST.get('forward_dak_id')
        if dak_id:
            try:
                dak = DakMaster.objects.get(pk=dak_id, is_active=True)
                ntr.forwarded_dak  = dak
                ntr.forwarded_date = dak.issue_date or timezone.now().date()
                ntr.status = 'FORWARDED'
                ntr.save()
                _link_dak_to_edw(record, dak, 'NTR_FORWARD', request.user,
                                 f'NTR {ntr.ntr_number} forwarded to group')
                record.workflow_stage = 'NTR'
                record.save(update_fields=['workflow_stage'])
                messages.success(request, f'NTR forwarded to group via {dak.dak_index_no}.')
            except DakMaster.DoesNotExist:
                messages.error(request, 'Dak not found.')
    return redirect('daks:edw_detail', public_id=public_id)


# ─────────────────────────────────────────────────────────────────────────────
# BQ MANAGEMENT (within eDW context)
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def edw_bq_create(request, public_id):
    """Create a new BQ for an eDW record."""
    record = get_object_or_404(eDW, public_id=public_id)

    if request.method == 'POST':
        from decimal import Decimal as D
        rev = record.bqs.count() + 1
        bq  = eDWBQ.objects.create(
            edw=record,
            bq_number=f'BQ-{record.acn_no}-R{rev:02d}',
            revision_no=rev,
            total_amount=D(request.POST.get('total_amount', '0') or '0'),
            gst_amount=D(request.POST.get('gst_amount', '0') or '0'),
            bq_date=request.POST.get('bq_date') or None,
            bq_received_from_group_date=request.POST.get('bq_received_from_group_date') or None,
            valid_until=request.POST.get('valid_until') or None,
            description=request.POST.get('description', ''),
            vendor_registration_no=request.POST.get('vendor_registration_no', '').strip() or None,
            status='DRAFT',
            created_by=request.user,
        )
        # Link BQ sent dak if provided
        bq_dak_id = request.POST.get('bq_dak_id')
        if bq_dak_id:
            try:
                bq_dak = DakMaster.objects.get(pk=bq_dak_id, is_active=True)
                bq.bq_dak = bq_dak
                bq.status = 'SENT'
                bq.save()
                _link_dak_to_edw(record, bq_dak, 'BQ_SENT', request.user,
                                 f'BQ {bq.bq_number} sent to firm')
                record.workflow_stage = 'BQ'
                record.save(update_fields=['workflow_stage'])
            except DakMaster.DoesNotExist:
                pass

        # Update NTR status
        if hasattr(record, 'ntr') and record.ntr:
            record.ntr.status = 'BQ_ISSUED'
            record.ntr.save(update_fields=['status'])

        messages.success(request, f'BQ {bq.bq_number} created.')
    return redirect('daks:edw_detail', public_id=public_id)


# ─────────────────────────────────────────────────────────────────────────────
# CLOSE DW RECORD
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def edw_close(request, public_id):
    """Mark an eDW record as closed — prevents further editing."""
    if not request.user.is_staff:
        messages.error(request, 'Only admins can close eDW records.')
        return redirect('daks:edw_detail', public_id=public_id)

    record = get_object_or_404(eDW, public_id=public_id)
    if request.method == 'POST':
        record.is_closed              = True
        record.workflow_stage         = 'CLOSED'
        record.dw_closed_on           = timezone.now().date()
        record.closure_request_sent_on= request.POST.get('closure_request_sent_on') or None
        record.te_closure_on          = request.POST.get('te_closure_on') or None
        record.te_closure_no          = request.POST.get('te_closure_no', '')
        amt = request.POST.get('treasury_deposit_amount', '0') or '0'
        from decimal import Decimal as D
        record.treasury_deposit_amount = D(amt)
        record.save()
        messages.success(request, f'eDW record {record.acn_no} closed.')
    return redirect('daks:edw_detail', public_id=public_id)


# ─────────────────────────────────────────────────────────────────────────────
# WORKFLOW STAGE API — returns available daks for a given stage
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def edw_api_daks_for_stage(request, public_id):
    """
    AJAX: return only daks valid for linking at a specific workflow stage.

    Stage -> Direction rules (enforced strictly):
      INCOMING stages (firm/group sends TO IIG):
        IFA         - Incoming: firm's initial inquiry letter
        NTR         - Incoming: NTR received from firm/group
        FEASIBILITY - Incoming: group's feasibility reply to IIG
        EMRO        - Incoming: firm's eMRO / payment dak
        ACN         - Incoming: ACN received from finance (DFMM)
        TRIAL       - Incoming: group sends trial report to IIG
        REPORT      - Incoming: report received from group

      OUTGOING stages (IIG sends OUT):
        NTR_FORWARD - Outgoing: IIG forwards NTR to testing group
        BQ          - Outgoing: IIG sends BQ to firm
        ACN_TO_GROUP- Outgoing: IIG shares ACN with group
        TE          - Outgoing: IIG's TE letter to AO
        CLOSURE     - Outgoing: closure correspondence

      OTHER - both directions allowed

    Thread scoping: if the eDW has a linked thread, prefer daks from that
    thread first. Falls back to company/group filtering if thread yields nothing.
    """
    record = get_object_or_404(eDW, public_id=public_id)
    stage  = request.GET.get('stage', '').strip()
    search = request.GET.get('q', '').strip()

    # Direction map
    INCOMING_STAGES = {'IFA', 'NTR', 'FEASIBILITY', 'EMRO', 'ACN', 'TRIAL', 'REPORT'}
    OUTGOING_STAGES = {'NTR_FORWARD', 'BQ', 'ACN_TO_GROUP', 'TE', 'CLOSURE'}

    if stage in OUTGOING_STAGES:
        direction = 'OUTGOING'
    elif stage in INCOMING_STAGES:
        direction = 'INCOMING'
    else:
        direction = None  # OTHER / unknown - no direction filter

    # Base queryset
    qs = DakMaster.objects.filter(is_active=True)
    if direction:
        qs = qs.filter(dak_direction=direction)

    # Thread-scoped filter (primary): daks from same thread are always the right ones
    thread_filtered = False
    if record.thread_id:
        thread_qs = qs.filter(thread_id=record.thread_id)
        if search:
            thread_qs = thread_qs.filter(
                Q(dak_index_no__icontains=search) | Q(subject__icontains=search)
            )
        if thread_qs.exists():
            qs = thread_qs
            thread_filtered = True

    # Fallback: filter by firm/group when not thread-scoped
    if not thread_filtered:
        if direction == 'INCOMING' and record.company_name:
            firm_q = (
                Q(party_mappings__organization=record.company_name) |
                Q(party_mappings__person__organization=record.company_name)
            )
            if record.group:
                firm_q |= Q(testing_group=record.group)
            qs = qs.filter(firm_q).distinct()
        # OUTGOING: no firm-filter needed - show all outgoing daks from IIG

        if search:
            qs = qs.filter(
                Q(dak_index_no__icontains=search) | Q(subject__icontains=search)
            )

    # Exclude daks already linked to THIS eDW at THIS SAME stage
    already_linked = set(
        eDWDakLink.objects.filter(edw=record, stage=stage)
                          .values_list('dak_id', flat=True)
    )
    if already_linked:
        qs = qs.exclude(pk__in=already_linked)

    daks = list(
        qs.values('id', 'dak_index_no', 'subject', 'issue_date', 'dak_direction')
          .order_by('-created_on')[:40]
    )
    for d in daks:
        d['issue_date'] = d['issue_date'].strftime('%d %b %Y') if d['issue_date'] else ''
        dir_tag = '[IN]' if d['dak_direction'] == 'INCOMING' else '[OUT]'
        d['label'] = f"{dir_tag} {d['dak_index_no']} — {d['subject'][:55]}"

    return JsonResponse({
        'daks':          daks,
        'direction':     direction or 'ANY',
        'thread_scoped': thread_filtered,
        'stage':         stage,
    })


# ─────────────────────────────────────────────────────────────────────────────
# EXPORT
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def edw_export_excel(request):
    qs = (eDW.objects.all()
          .select_related('company_name', 'group', 'dak', 'created_by')
          .order_by('-created_at'))

    search = request.GET.get('search', '').strip()
    if search:
        qs = qs.filter(
            Q(acn_no__icontains=search) |
            Q(company_name__org_name__icontains=search) |
            Q(rdr_register_number__icontains=search)
        )
    if request.GET.get('status'):
        qs = qs.filter(status=request.GET['status'])
    if request.GET.get('group'):
        qs = qs.filter(group_id=request.GET['group'])

    from .report_columns import get_default_columns
    from .reports import generate_module_excel_report
    columns = get_default_columns('edw')
    return generate_module_excel_report(qs, columns, 'eDW_Records')


# ─────────────────────────────────────────────────────────────────────────────
# ADMIN-ONLY HARD DELETE
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def edw_delete(request, public_id):
    """Superuser-only: permanently delete an eDW record and all related data."""
    if not request.user.is_superuser:
        messages.error(request, 'Only superusers can delete eDW records.')
        return redirect('daks:edw_detail', public_id=public_id)

    record = get_object_or_404(eDW, public_id=public_id)

    if request.method == 'POST':
        identifier = record.acn_no
        record.delete()
        messages.success(request, f'eDW record "{identifier}" permanently deleted.')
        return redirect('daks:edw_dashboard')

    return render(request, 'daks/edw_confirm_delete.html', {'record': record})


# ─────────────────────────────────────────────────────────────────────────────
# FIX 6 — EXTRA COLUMNS: shared helpers used by detail + edit views
# ─────────────────────────────────────────────────────────────────────────────

def _extra_col_context(module_key, record_pk):
    """Wrapper calling unified helper."""
    from .dynamic_columns import get_extra_col_context
    return get_extra_col_context(module_key, record_pk)


def _save_extra_cols(module_key, record_pk, post_data):
    """Wrapper calling unified helper."""
    from .dynamic_columns import save_extra_col_values
    return save_extra_col_values(module_key, record_pk, post_data)


@login_required
def edw_mark_nfa(request, public_id):
    """Mark an eDW record as NFA (Not Feasible / Archived) and auto-close it."""
    record = get_object_or_404(eDW, public_id=public_id)
    if request.method == 'POST':
        from django.utils import timezone as tz
        reason = request.POST.get('nfa_reason', '').strip()
        record.workflow_stage = 'NFA'
        record.status = 'COMPLETED'
        record.is_closed = True
        record.dw_closed_on = tz.now().date()
        record.nfa_date = tz.now().date()
        record.nfa_reason = reason or 'Marked NFA — not feasible as per testing group.'

        # Auto-generate NFA number: NFA/YYYY-YY/XXXX
        year = tz.now().year
        short = str(year + 1)[2:]
        prefix = f"NFA/{year}-{short}/"
        last_nfa = eDW.objects.filter(nfa_number__startswith=prefix).order_by('-id').first()
        if last_nfa and last_nfa.nfa_number:
            try:
                seq = int(last_nfa.nfa_number.split('/')[-1]) + 1
            except Exception:
                seq = 1
        else:
            seq = 1
        record.nfa_number = f"{prefix}{seq:04d}"
        record.save()
        messages.success(request, f'Record marked NFA — {record.nfa_number}. Record is now closed.')
    return redirect('daks:edw_detail', public_id=public_id)


@login_required
def api_edw_prefill_data(request, public_id):
    """Prefill AJAX endpoint to get details of a previous stage record."""
    try:
        edw = eDW.objects.select_related('company_name', 'group', 'dak').get(public_id=public_id)
    except eDW.DoesNotExist:
        return JsonResponse({'error': 'Record not found'}, status=404)
        
    ntr = getattr(edw, 'ntr', None)
    
    data = {
        'ifa_no': edw.ifa_no or '',
        'acn_no': edw.acn_no or '',
        'rdr_register_number': edw.rdr_register_number or '',
        'company_name': edw.company_name_id or '',
        'company_name_text': edw.company_name.org_name if edw.company_name else '',
        'dpsu_psu_private_capf': edw.dpsu_psu_private_capf or '',
        'group': edw.group_id or '',
        'group_text': edw.group.group_name if edw.group else '',
        'trial_title': edw.trial_title or '',
        'code_head': edw.code_head or '',
        'category_head': edw.category_head or '',
        'dw_activity': edw.dw_activity or '',
        'funding_agency': edw.funding_agency or '',
        # NTR
        'ntr_number': ntr.ntr_number if ntr else '',
        'ntr_date': ntr.ntr_date.isoformat() if (ntr and ntr.ntr_date) else '',
        'forwarded_date': ntr.forwarded_date.isoformat() if (ntr and ntr.forwarded_date) else '',
        'is_feasible': ntr.is_feasible if ntr else True,
        # eMRO
        'emro_payment_mode': edw.emro_payment_mode or '',
        'emro_payment_date': edw.emro_payment_date.isoformat() if edw.emro_payment_date else '',
        'emro_received_on': edw.emro_received_on.isoformat() if edw.emro_received_on else '',
        'mro_number': edw.mro_number or '',
        'mro_date': edw.mro_date.isoformat() if edw.mro_date else '',
        'mro_outgoing_date': edw.mro_outgoing_date.isoformat() if edw.mro_outgoing_date else '',
        'amount_paid_by_firm': str(edw.amount_paid_by_firm) if edw.amount_paid_by_firm else '',
        'bank_reference_no': edw.bank_reference_no or '',
        'firm_payment_date': edw.firm_payment_date.isoformat() if edw.firm_payment_date else '',
        'gst_commitment': edw.gst_commitment,
        'gst_cin_no': edw.gst_cin_no or '',
        'gst_cin_date': edw.gst_cin_date.isoformat() if edw.gst_cin_date else '',
        'gst_cin_amount': str(edw.gst_cin_amount) if edw.gst_cin_amount else '',
        'acn_request_send_to_group_on': edw.acn_request_send_to_group_on.isoformat() if edw.acn_request_send_to_group_on else '',
        # ACN
        'acn_request_received_date': edw.acn_request_received_date.isoformat() if edw.acn_request_received_date else '',
        'job_number_alloted_by_i2g': edw.job_number_alloted_by_i2g or '',
        'job_no_date': edw.job_no_date.isoformat() if edw.job_no_date else '',
        'rdr_no': edw.rdr_no or '',
        'acn_amount': str(edw.acn_amount) if edw.acn_amount else '',
        'trial_tentative_date_acn': edw.trial_tentative_date_acn.isoformat() if edw.trial_tentative_date_acn else '',
        'sanction_no': edw.sanction_no or '',
        'sanction_date': edw.sanction_date.isoformat() if edw.sanction_date else '',
        'acn_letter_no': edw.acn_letter_no or '',
        'acn_letter_date': edw.acn_letter_date.isoformat() if edw.acn_letter_date else '',
        'remarks': edw.remarks or '',
        'acn_no_field': edw.acn_no or '',
        'acn_allotted_on': edw.acn_allotted_on.isoformat() if edw.acn_allotted_on else '',
        'acn_forwarded_to_group_on': edw.acn_forwarded_to_group_on.isoformat() if edw.acn_forwarded_to_group_on else '',
        'amount_reflected_in_acn': str(edw.amount_reflected_in_acn) if edw.amount_reflected_in_acn else '',
        'intimation_acn_to_group': edw.intimation_acn_to_group or '',
        # TE
        'rdr_code_head': edw.rdr_code_head or '',
        'te_amount': str(edw.te_amount) if edw.te_amount else '',
        'te_letter_no': edw.te_letter_no or '',
        'te_letter_date': edw.te_letter_date.isoformat() if edw.te_letter_date else '',
        'te_sent_to_ao_on': edw.te_sent_to_ao_on.isoformat() if edw.te_sent_to_ao_on else '',
        'te_no': edw.te_no or '',
        'te_received_on': edw.te_received_on.isoformat() if edw.te_received_on else '',
        'te_initiated_to_group_on': edw.te_initiated_to_group_on.isoformat() if edw.te_initiated_to_group_on else '',
        'te_number_outgoing_date': edw.te_number_outgoing_date.isoformat() if edw.te_number_outgoing_date else '',
        'te_number_incoming_date': edw.te_number_incoming_date.isoformat() if edw.te_number_incoming_date else '',
        # Trial
        'trial_conducted': edw.trial_conducted or '',
        'actual_trial_date': edw.actual_trial_date.isoformat() if edw.actual_trial_date else '',
        'no_of_test_samples_planned': edw.no_of_test_samples_planned or '',
        'no_of_test_conducted': edw.no_of_test_conducted or '',
        'trial_tentative_date': edw.trial_tentative_date.isoformat() if edw.trial_tentative_date else '',
        'trial_report_received_on': edw.trial_report_received_on.isoformat() if edw.trial_report_received_on else '',
        'jcc_submitted_on': edw.jcc_submitted_on.isoformat() if edw.jcc_submitted_on else '',
        'fa_gst_submitted_on': edw.fa_gst_submitted_on.isoformat() if edw.fa_gst_submitted_on else '',
        'report_no_request_sent_on': edw.report_no_request_sent_on.isoformat() if edw.report_no_request_sent_on else '',
        'account_date': edw.account_date.isoformat() if edw.account_date else '',
        'testing_changes_receipt_no': edw.testing_changes_receipt_no or '',
        'testing_changes_receipt_date': edw.testing_changes_receipt_date.isoformat() if edw.testing_changes_receipt_date else '',
        # Report
        'trial_report_no': edw.trial_report_no or '',
        'trial_report_issued_on': edw.trial_report_issued_on.isoformat() if edw.trial_report_issued_on else '',
        'report_letter_no': edw.report_letter_no or '',
        'report_dispatched_on': edw.report_dispatched_on.isoformat() if edw.report_dispatched_on else '',
        'speed_post_no': edw.speed_post_no or '',
        'speed_post_date': edw.speed_post_date.isoformat() if edw.speed_post_date else '',
        'ion_issued_on': edw.ion_issued_on.isoformat() if edw.ion_issued_on else '',
        'report_mail_to_company_on': edw.report_mail_to_company_on.isoformat() if edw.report_mail_to_company_on else '',
        'report_to_tirc_on': edw.report_to_tirc_on.isoformat() if edw.report_to_tirc_on else '',
        'report_to_group_on': edw.report_to_group_on.isoformat() if edw.report_to_group_on else '',
        'report_to_whom_dispatched': edw.report_to_whom_dispatched or '',
        'dispatch_date': edw.dispatch_date.isoformat() if edw.dispatch_date else '',
    }
    return JsonResponse(data)
