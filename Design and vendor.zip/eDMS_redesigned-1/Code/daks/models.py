import uuid
from django.db import models
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.utils import timezone

# ============================================
# PART 1: CONFIGURATION TABLES
# ============================================

class OrganizationTypeMaster(models.Model):
    """Dynamic organization types - users can add new types"""
    type_name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True, null=True)
    is_active = models.BooleanField(default=True)
    is_system_defined = models.BooleanField(default=False)
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    source = models.CharField(max_length=20, choices=[
        ('SYSTEM', 'System Defined'),
        ('MANUAL', 'Manually Added'),
        ('DYNAMIC', 'Created During Entry'),
        ('IMPORT', 'Imported')
    ], default='SYSTEM')
    
    def __str__(self):
        return self.type_name
    
    class Meta:
        db_table = 'organization_type_master'


class DakCategoryMaster(models.Model):
    """Dak categories: LETTER, FAX, MAIL, REPORT, ION"""
    category_code = models.CharField(max_length=20, unique=True)
    category_name = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)
    can_have_nature = models.BooleanField(default=True)
    can_have_report_details = models.BooleanField(default=False)
    can_have_dispatch_details = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    
    def __str__(self):
        return f"{self.category_code} - {self.category_name}"
    
    class Meta:
        db_table = 'dak_category_master'


class PartyRoleMaster(models.Model):
    """Roles: SENDER, RECEIVER, MARKED_TO"""
    role_code = models.CharField(max_length=20, unique=True)
    role_name = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)
    is_active = models.BooleanField(default=True)
    
    def __str__(self):
        return f"{self.role_code} - {self.role_name}"
    
    class Meta:
        db_table = 'party_role_master'


class DispatchModeMaster(models.Model):
    """Dispatch modes: REGULAR_POST, SPEED_POST, COURIER, etc."""
    mode_code = models.CharField(max_length=20, unique=True)
    mode_name = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)
    is_active = models.BooleanField(default=True)
    
    def __str__(self):
        return f"{self.mode_code} - {self.mode_name}"
    
    class Meta:
        db_table = 'dispatch_mode_master'


# ============================================
# PART 2: DYNAMIC MASTER TABLES
# ============================================

class DakNatureMaster(models.Model):
    """Nature/Sub-category of daks"""
    nature_name = models.CharField(max_length=100, unique=True)
    applicable_category = models.CharField(
        max_length=50, 
        blank=True, 
        null=True,
        verbose_name="Applicable Category",
        help_text="Comma-separated categories (e.g., LETTER,FAX,MAIL)"
    )
    is_active = models.BooleanField(default=True)
    is_system_defined = models.BooleanField(default=False)
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    source = models.CharField(max_length=20, default='MANUAL')
    
    def __str__(self):
        return self.nature_name
    
    class Meta:
        db_table = 'dak_nature_master'


class DakHeaderMaster(models.Model):
    """Header/Sub-nature of daks under a specific Nature"""
    header_name = models.CharField(max_length=100)
    nature = models.ForeignKey(DakNatureMaster, on_delete=models.CASCADE, related_name='headers')
    is_active = models.BooleanField(default=True)
    is_system_defined = models.BooleanField(default=False)
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    source = models.CharField(max_length=20, default='MANUAL')
    
    def __str__(self):
        return f"{self.header_name} (Nature: {self.nature.nature_name})"
    
    class Meta:
        db_table = 'dak_header_master'
        unique_together = ['header_name', 'nature']



class GroupMaster(models.Model):
    """Internal groups (IIG, MMG, C4I, etc.) - All at same level"""
    group_code = models.CharField(max_length=10, unique=True)
    group_name = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)
    is_active = models.BooleanField(default=True)
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    source = models.CharField(max_length=20, default='MANUAL')
    
    def __str__(self):
        return f"{self.group_code} - {self.group_name}"
    
    class Meta:
        db_table = 'group_master'
        verbose_name = 'Group'
        verbose_name_plural = 'Groups'
        ordering = ['group_name']  # ← Change from 'group_code' to 'group_name'


class OrganizationMaster(models.Model):
    """Companies, DRDO units, departments"""
    org_name = models.CharField(max_length=200)
    org_type = models.ForeignKey(OrganizationTypeMaster, on_delete=models.SET_NULL, null=True, blank=True)
    address = models.TextField(blank=True, null=True)
    phone = models.CharField(max_length=20, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    website = models.URLField(blank=True, null=True)
    is_active = models.BooleanField(default=True)
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    source = models.CharField(max_length=20, default='MANUAL')
    verified = models.BooleanField(default=False)
    notes = models.TextField(blank=True, null=True)
    
    def __str__(self):
        type_name = self.org_type.type_name if self.org_type else "No Type"
        return f"{self.org_name} ({type_name})"
    
    class Meta:
        db_table = 'organization_master'


class PersonMaster(models.Model):
    """Contact persons - UPDATED with group field"""
    
    # Organization (external companies, DRDO units)
    organization = models.ForeignKey(
        OrganizationMaster, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True,
        verbose_name="External Organization"
    )
    
    # NEW: Group (IIG, MMG, C4I, etc.) - for internal members
    group = models.ForeignKey(
        GroupMaster,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name="Internal Group",
        help_text="Which group this person belongs to (IIG, MMG, C4I, etc.)"
    )
    
    # NEW: Flag to identify IIG members
    is_iig_member = models.BooleanField(
        default=False,
        verbose_name="IIG Member",
        help_text="Is this person a member of IIG department?"
    )
    
    person_name = models.CharField(max_length=150)
    designation = models.CharField(max_length=100, blank=True, null=True)
    department = models.CharField(max_length=100, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    mobile_no = models.CharField(max_length=15, blank=True, null=True)
    phone_extension = models.CharField(max_length=10, blank=True, null=True)
    is_active = models.BooleanField(default=True)
    
    # Audit fields
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    source = models.CharField(max_length=20, default='MANUAL')
    is_primary_contact = models.BooleanField(default=False)
    notes = models.TextField(blank=True, null=True)
    
    def __str__(self):
        if self.group:
            return f"{self.person_name} ({self.group.group_code})"
        elif self.organization:
            return f"{self.person_name} - {self.organization.org_name}"
        else:
            return self.person_name
    
    class Meta:
        db_table = 'person_master'
        verbose_name = 'Person'
        verbose_name_plural = 'Persons'
        ordering = ['person_name']
        indexes = [
            models.Index(fields=['person_name']),
            models.Index(fields=['group', 'is_active']),
        ]


# ============================================
# PART 3: CORE TRANSACTION TABLES
# ============================================
class DakThread(models.Model):
    """Communication threads grouping related daks"""

    # Non-guessable ID used in URLs instead of the sequential pk
    public_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True, db_index=True)
    
    THREAD_STATUS_CHOICES = [
        ('OPEN', 'Open - Active Communication'),
        ('CLOSED', 'Closed - Communication Complete'),
        ('ARCHIVED', 'Archived - Read Only'),
    ]
    
    # ========== FIELDS ==========
    thread_code = models.CharField(
        max_length=50, 
        unique=True,
        verbose_name="Thread Code",
        help_text="Auto-generated: THREAD-YYYY-MM-XXXX"
    )
    
    subject_summary = models.TextField(
        verbose_name="Subject Summary",
        help_text="Brief description of the communication topic"
    )
    
    status = models.CharField(
        max_length=20,
        choices=THREAD_STATUS_CHOICES,
        default='OPEN',
        verbose_name="Status"
    )
    
    # Timestamps
    created_on = models.DateTimeField(
        auto_now_add=True,
        verbose_name="Created On"
    )
    
    closed_on = models.DateTimeField(
        null=True, 
        blank=True,
        verbose_name="Closed On"
    )
    
    last_activity = models.DateTimeField(
        auto_now=True,
        verbose_name="Last Activity"
    )
    
    # User tracking
    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        verbose_name="Created By",
        related_name='created_threads'
    )
    
    closed_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name="Closed By",
        related_name='closed_threads'
    )
    
    # Statistics
    dak_count = models.IntegerField(
        default=0,
        verbose_name="Total Daks",
        help_text="Number of daks in this thread (auto-updated)"
    )
    
    # ========== METHODS ==========
    
    def __str__(self):
        return f"{self.thread_code} - {self.subject_summary[:50]}"
    
    @classmethod
    def generate_thread_code(cls):
        """
        Generate unique thread code.
        Format: THREAD-YYYY-MM-XXXX
        """
        from django.utils import timezone
        now = timezone.now()
        year = now.year
        month = now.month
        
        # Count threads this month
        thread_count = cls.objects.filter(
            thread_code__startswith=f"THREAD-{year}-{month:02d}"
        ).count()
        
        new_number = thread_count + 1
        return f"THREAD-{year}-{month:02d}-{new_number:04d}"
    
    def update_dak_count(self):
        """Update the count of daks in this thread"""
        from django.db.models import Count
        count = self.dak_set.filter(is_active=True).count()
        self.dak_count = count
        self.save(update_fields=['dak_count'])
        return count
    
    def close_thread(self, user):
        """Close the thread and mark as complete"""
        from django.utils import timezone
        self.status = 'CLOSED'
        self.closed_on = timezone.now()
        self.closed_by = user
        self.save(update_fields=['status', 'closed_on', 'closed_by'])
        
        # Log the action if you have AuditLog
        try:
            from .models import AuditLog
            AuditLog.log_action(
                user=user,
                action='UPDATE',
                entity_type='THREAD',
                entity_id=self.id,
                entity_name=self.thread_code,
                details={'action': 'closed', 'status': 'CLOSED'}
            )
        except:
            pass  # AuditLog might not exist
    
    def archive_thread(self, user):
        """Archive the thread (read-only)"""
        self.status = 'ARCHIVED'
        self.save(update_fields=['status'])
        
        # Log the action
        try:
            from .models import AuditLog
            AuditLog.log_action(
                user=user,
                action='UPDATE',
                entity_type='THREAD',
                entity_id=self.id,
                entity_name=self.thread_code,
                details={'action': 'archived', 'status': 'ARCHIVED'}
            )
        except:
            pass
    
    def get_absolute_url(self):
        """Return URL to thread detail page"""
        from django.urls import reverse
        return reverse('daks:thread_detail', args=[str(self.id)])
    
    def get_all_daks(self):
        """Get all daks in this thread ordered by date"""
        return self.dak_set.filter(is_active=True).order_by('created_on')
    
    def get_incoming_daks(self):
        """Get only incoming daks in this thread"""
        return self.dak_set.filter(dak_direction='INCOMING', is_active=True).order_by('created_on')
    
    def get_outgoing_daks(self):
        """Get only outgoing daks in this thread"""
        return self.dak_set.filter(dak_direction='OUTGOING', is_active=True).order_by('created_on')
    
    def has_unreplied_daks(self):
        """Check if any daks in thread are pending reply"""
        return self.dak_set.filter(reply_mode='NOT_YET', is_active=True).exists()
    
    # ========== META ==========
    
    class Meta:
        db_table = 'dak_thread'
        verbose_name = 'Communication Thread'
        verbose_name_plural = 'Communication Threads'
        ordering = ['-last_activity']
        indexes = [
            models.Index(fields=['thread_code']),
            models.Index(fields=['status', 'last_activity']),
            models.Index(fields=['created_on']),
        ]
class DakMaster(models.Model):
    """Main dak registry - HEART of the system"""

    # Non-guessable ID used in URLs instead of the sequential pk
    public_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True, db_index=True)

    DAK_DIRECTION_CHOICES = [
        ('INCOMING', 'Incoming Dak'),
        ('OUTGOING', 'Outgoing Dak'),
    ]
    REPLY_MODE_CHOICES = [
        ('MAIL', 'Reply Sent by Mail'),
        ('LETTER', 'Reply Sent by Letter'),
        ('ION', 'Reply Sent by ION'),
        ('NOT_YET', 'Reply Not Sent Yet'),
    ]
    
    REPLY_TYPE_CHOICES = [
        ('NONE', 'New Outgoing (Not a Reply)'),
        ('COMPANY', 'Replying to a Company'),
        ('GOVT', 'Replying to a Govt Body'),
    ]

    thread = models.ForeignKey('DakThread', on_delete=models.CASCADE, related_name='dak_set')
    dak_direction = models.CharField(max_length=20, choices=DAK_DIRECTION_CHOICES)
    dak_category = models.ForeignKey('DakCategoryMaster', on_delete=models.PROTECT)
    nature = models.ForeignKey('DakNatureMaster', on_delete=models.PROTECT, null=True, blank=True)
    header = models.ForeignKey('DakHeaderMaster', on_delete=models.PROTECT, null=True, blank=True)
    dak_index_no = models.CharField(max_length=50, unique=True)
    iig_ref_no = models.CharField(max_length=50, unique=True, null=True, blank=True)
    # Outgoing: user-supplied letter number (e.g. DCMM/IIG/2026/123)
    letter_no = models.CharField(max_length=100, blank=True, null=True, verbose_name='Letter No.')
    tbrl_diary_no = models.CharField(max_length=100, blank=True, null=True, verbose_name='TBRL Diary No.')
    tbrl_date = models.DateField(blank=True, null=True, verbose_name='TBRL Date')
    file_location = models.CharField(max_length=500, blank=True, null=True, verbose_name='File Location')
    reply_file_location = models.CharField(max_length=500, blank=True, null=True, verbose_name='Reply File Location')
    reply_due_date = models.DateField(blank=True, null=True, verbose_name='Reply Due Date',
        help_text='Optional reply deadline. Triggers daily reminder if <5 days, alternate-day if >=5 days.')
    subject = models.TextField()
    issue_date = models.DateField()
    receipt_date = models.DateField(null=True, blank=True)
    reply_mode = models.CharField(max_length=20, choices=REPLY_MODE_CHOICES, default='NOT_YET')
    reply_dak = models.ForeignKey('self', on_delete=models.SET_NULL, null=True, blank=True, related_name='replies')
    # Outgoing: whether this is a reply and to what type of entity
    reply_type = models.CharField(max_length=10, choices=REPLY_TYPE_CHOICES, default='NONE', blank=True)
    # Outgoing: receiver details
    receiver_org = models.ForeignKey(
        'OrganizationMaster', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='received_daks',
        verbose_name='Receiver Organization'
    )
    receiver_person = models.ForeignKey(
        'PersonMaster', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='received_daks',
        verbose_name='Receiver Person'
    )
    testing_group = models.ForeignKey(
        'GroupMaster', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='testing_daks',
        verbose_name='Testing Group'
    )
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    created_on = models.DateTimeField(auto_now_add=True)
    updated_on = models.DateTimeField(auto_now=True)
    is_active = models.BooleanField(default=True)
    imported_from_legacy = models.BooleanField(default=False)
    legacy_id = models.CharField(max_length=100, blank=True, null=True)
    
    def __str__(self):
        return f"{self.dak_index_no} - {self.subject[:50]}"
    
    # ========== METHODS (MUST BE INDENTED INSIDE CLASS) ==========
    
    def generate_index_number(self):
        """
        Generate unique dak index number.
        Format: IN-YYYY-XXXX for incoming
                OUT-YYYY-XXXX for outgoing
        """
        from django.utils import timezone
        year = timezone.now().year
        prefix = 'IN' if self.dak_direction == 'INCOMING' else 'OUT'
        
        last_dak = DakMaster.objects.filter(
            dak_index_no__startswith=f"{prefix}-{year}",
            dak_index_no__isnull=False
        ).exclude(dak_index_no='').order_by('dak_index_no').last()
        
        if last_dak:
            try:
                parts = last_dak.dak_index_no.split('-')
                if len(parts) >= 3:
                    last_num = int(parts[-1])
                    new_num = last_num + 1
                else:
                    new_num = 1
            except (ValueError, IndexError):
                new_num = 1
        else:
            new_num = 1
        
        return f"{prefix}-{year}-{new_num:04d}"
    
    def generate_iig_ref(self):
        """
        Generate IIG reference number for incoming daks.
        Format: DCMM/IIG/YYYY/XXXX
        """
        from django.utils import timezone
        year = timezone.now().year
        
        last_dak = DakMaster.objects.filter(
            iig_ref_no__contains=f'/{year}/',
            iig_ref_no__isnull=False
        ).exclude(iig_ref_no='').order_by('iig_ref_no').last()
        
        if last_dak:
            try:
                parts = last_dak.iig_ref_no.split('/')
                if len(parts) >= 4:
                    last_num = int(parts[-1])
                    new_num = last_num + 1
                else:
                    new_num = 1
            except (ValueError, IndexError):
                new_num = 1
        else:
            new_num = 1
        
        return f"DCMM/IIG/{year}/{new_num:04d}"
    
    def save(self, *args, **kwargs):
        """Auto-generate reference numbers if not set"""
        # Generate dak_index_no if not provided or empty
        if not self.dak_index_no or self.dak_index_no == '':
            self.dak_index_no = self.generate_index_number()
        
        # Auto-set receipt_date for incoming
        if self.dak_direction == 'INCOMING' and not self.receipt_date:
            from django.utils import timezone
            self.receipt_date = timezone.now().date()
        
        # Save the instance
        super().save(*args, **kwargs)
        
        # Update thread dak count if thread exists
        if self.thread_id and hasattr(self.thread, 'update_dak_count'):
            try:
                self.thread.update_dak_count()
            except:
                pass  # Silently fail if thread doesn't exist or method missing
    
    def get_absolute_url(self):
        """Return URL to dak detail page"""
        from django.urls import reverse
        return reverse('daks:dak_detail', args=[str(self.id)])
    
    class Meta:
        db_table = 'dak_master'
        verbose_name = 'Dak Master'
        verbose_name_plural = 'Dak Masters'
        ordering = ['-created_on']
        indexes = [
            models.Index(fields=['dak_index_no']),
            models.Index(fields=['iig_ref_no']),
            models.Index(fields=['thread', 'created_on']),
            models.Index(fields=['dak_direction', 'dak_category']),
            models.Index(fields=['issue_date']),
        ]


class DakPartyMapping(models.Model):
    """Links daks to people with roles"""
    dak = models.ForeignKey(DakMaster, on_delete=models.CASCADE, related_name='party_mappings')
    person = models.ForeignKey(PersonMaster, on_delete=models.CASCADE)
    party_role = models.ForeignKey(PartyRoleMaster, on_delete=models.PROTECT)
    organization = models.ForeignKey(OrganizationMaster, on_delete=models.SET_NULL, null=True, blank=True)
    remarks = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'dak_party_mapping'
        unique_together = ['dak', 'person', 'party_role']


class DakGroupMapping(models.Model):
    """Links daks to internal groups (IIG, MMG, C4I, etc.)"""
    dak = models.ForeignKey(DakMaster, on_delete=models.CASCADE, related_name='group_mappings')
    group = models.ForeignKey(GroupMaster, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'dak_group_mapping'
        unique_together = ['dak', 'group']


class DakReportDetails(models.Model):
    """ACN details for REPORT category daks"""
    dak = models.OneToOneField(DakMaster, on_delete=models.CASCADE, related_name='report_details')
    acn_no = models.CharField(max_length=50)
    acn_amount = models.DecimalField(max_digits=15, decimal_places=2)
    company_name = models.CharField(max_length=200)
    remarks = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'dak_report_details'


class DakDispatchDetails(models.Model):
    """Dispatch tracking for outgoing daks"""
    dak = models.OneToOneField(DakMaster, on_delete=models.CASCADE, related_name='dispatch_details')
    dispatch_mode = models.ForeignKey(DispatchModeMaster, on_delete=models.PROTECT)
    dispatch_date = models.DateField()
    tracking_no = models.CharField(max_length=100, blank=True, null=True)
    admin_handled = models.BooleanField(default=False)
    remarks = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'dak_dispatch_details'


# ============================================
# PART 4: FILE & ARCHIVE TABLES
# ============================================

class DakFileAttachment(models.Model):
    """File attachments with encryption and integrity"""

    # Non-guessable ID used in URLs instead of the sequential pk
    public_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True, db_index=True)

    dak = models.ForeignKey(DakMaster, on_delete=models.CASCADE, related_name='attachments')
    file_name = models.CharField(max_length=255)
    file_path = models.CharField(max_length=500)
    file_size = models.IntegerField()
    mime_type = models.CharField(max_length=100)
    checksum = models.CharField(max_length=64)
    is_encrypted = models.BooleanField(default=True)
    uploaded_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    description = models.TextField(blank=True, null=True)
    
    def __str__(self):
        return f"{self.dak.dak_index_no} - {self.file_name}"
    
    class Meta:
        db_table = 'dak_file_attachment'


class DakArchive(models.Model):
    """Archived threads as ZIP files"""
    thread = models.OneToOneField(DakThread, on_delete=models.CASCADE, related_name='archive')
    zip_file = models.CharField(max_length=500)
    zip_size = models.IntegerField()
    zip_checksum = models.CharField(max_length=64)
    dak_count = models.IntegerField()
    file_count = models.IntegerField()
    date_from = models.DateField()
    date_to = models.DateField()
    archived_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    archived_at = models.DateTimeField(auto_now_add=True)
    notes = models.TextField(blank=True, null=True)
    
    def __str__(self):
        return f"Archive: {self.thread.thread_code}"
    
    class Meta:
        db_table = 'dak_archive'


# ============================================
# PART 5: AUDIT & SYSTEM TABLES
# ============================================

class AuditLog(models.Model):
    """Complete audit trail"""
    ACTION_CHOICES = [
        ('CREATE', 'Create'),
        ('UPDATE', 'Update'),
        ('DELETE', 'Delete'),
        ('DYNAMIC_CREATE', 'Dynamic Create'),
        ('IMPORT', 'Import'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    action = models.CharField(max_length=20, choices=ACTION_CHOICES)
    entity_type = models.CharField(max_length=20)
    entity_id = models.IntegerField()
    entity_name = models.CharField(max_length=200)
    details = models.JSONField(blank=True, null=True)
    ip_address = models.GenericIPAddressField(blank=True, null=True)
    user_agent = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'audit_log'


class SystemConfig(models.Model):
    """System settings"""
    config_key = models.CharField(max_length=100, unique=True)
    config_value = models.TextField()
    data_type = models.CharField(max_length=20, default='STRING')
    description = models.TextField(blank=True, null=True)
    category = models.CharField(max_length=50, default='GENERAL')
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.config_key} = {self.config_value[:50]}"
    
    class Meta:
        db_table = 'system_config'

class UserNotes(models.Model):
    """User notes for quick reminders and key points"""
    
    user = models.OneToOneField(
        User, 
        on_delete=models.CASCADE,
        related_name='notes',
        verbose_name="User"
    )
    
    content = models.TextField(
        blank=True,
        null=True,
        verbose_name="Notes Content",
        help_text="Quick notes, reminders, key points"
    )
    
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name="Last Updated"
    )
    
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name="Created At"
    )
    
    def __str__(self):
        return f"Notes for {self.user.username}"
    
    class Meta:
        db_table = 'user_notes'
        verbose_name = 'User Note'
        verbose_name_plural = 'User Notes'

# ============================================
# eDW MODULE (Deposit Work)
# ============================================


class WorkTask(models.Model):
    # Non-guessable ID used in URLs instead of the sequential pk
    public_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True, db_index=True)

    PRIORITY_CHOICES = [('LOW','Low'),('MEDIUM','Medium'),('HIGH','High'),('URGENT','Urgent')]
    STATUS_CHOICES   = [('PENDING','Pending'),('IN_PROGRESS','In Progress'),('COMPLETED','Completed'),('CANCELLED','Cancelled')]
    title          = models.CharField(max_length=200)
    description    = models.TextField(blank=True, null=True)
    priority       = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default='MEDIUM')
    status         = models.CharField(max_length=15, choices=STATUS_CHOICES, default='PENDING')
    deadline       = models.DateField(blank=True, null=True)
    assigned_to    = models.ForeignKey(User, on_delete=models.CASCADE, related_name='assigned_tasks')
    assigned_by    = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='created_tasks')
    linked_dak     = models.ForeignKey('DakMaster', on_delete=models.SET_NULL, null=True, blank=True, related_name='tasks')
    completion_note= models.TextField(blank=True, null=True)
    completed_at   = models.DateTimeField(blank=True, null=True)
    created_at     = models.DateTimeField(auto_now_add=True)
    updated_at     = models.DateTimeField(auto_now=True)
    class Meta:
        db_table = 'work_task'; ordering = ['-created_at']
    def __str__(self): return f"[{self.priority}] {self.title}"
    @property
    def is_overdue(self):
        from django.utils import timezone
        return bool(self.deadline and self.status not in ('COMPLETED','CANCELLED') and self.deadline < timezone.now().date())
    @property
    def days_until_deadline(self):
        from django.utils import timezone
        return (self.deadline - timezone.now().date()).days if self.deadline else None


class NTR(models.Model):
    STATUS_CHOICES = [('DRAFT','Draft'),('SUBMITTED','Submitted'),('APPROVED','Approved'),
                      ('REJECTED','Rejected'),('BQ_RAISED','BQ Raised'),('CLOSED','Closed')]
    ntr_number   = models.CharField(max_length=50, unique=True)
    sequence_no  = models.PositiveIntegerField()
    year         = models.PositiveIntegerField()
    linked_dak   = models.ForeignKey('DakMaster', on_delete=models.SET_NULL, null=True, blank=True, related_name='ntrs')
    group        = models.ForeignKey('GroupMaster', on_delete=models.SET_NULL, null=True, blank=True, related_name='ntrs')
    organization = models.ForeignKey('OrganizationMaster', on_delete=models.SET_NULL, null=True, blank=True, related_name='ntrs')
    title        = models.CharField(max_length=500)
    description  = models.TextField(blank=True, null=True)
    feasibility_remarks = models.TextField(blank=True, null=True)
    status       = models.CharField(max_length=15, choices=STATUS_CHOICES, default='DRAFT')
    is_feasible  = models.BooleanField(default=True)
    inquiry_date    = models.DateField(blank=True, null=True)
    submission_date = models.DateField(blank=True, null=True)
    approval_date   = models.DateField(blank=True, null=True)
    created_by   = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='created_ntrs')
    created_at   = models.DateTimeField(auto_now_add=True)
    updated_at   = models.DateTimeField(auto_now=True)
    class Meta:
        db_table = 'ntr'; ordering = ['-created_at']
    def __str__(self): return self.ntr_number
    @classmethod
    def generate_number(cls, group):
        from django.utils import timezone
        year = timezone.now().year
        code = (getattr(group,'group_code',None) or group.group_name[:6]).upper().replace(' ','')
        last = cls.objects.filter(year=year, group=group).order_by('-sequence_no').first()
        seq  = (last.sequence_no + 1) if last else 1
        return f'NTR-{seq:03d}-{code}-{year}', seq, year


class BQ(models.Model):
    STATUS_CHOICES = [('DRAFT','Draft'),('SENT','Sent'),('ACCEPTED','Accepted'),('REJECTED','Rejected'),('REVISED','Revised')]
    ntr         = models.ForeignKey(NTR, on_delete=models.CASCADE, related_name='bqs')
    bq_number   = models.CharField(max_length=80, unique=True)
    revision_no = models.PositiveSmallIntegerField(default=1)
    total_amount= models.DecimalField(max_digits=14, decimal_places=2, default=0)
    gst_amount  = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    grand_total = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    status      = models.CharField(max_length=10, choices=STATUS_CHOICES, default='DRAFT')
    description = models.TextField(blank=True, null=True)
    remarks     = models.TextField(blank=True, null=True)
    issue_date  = models.DateField(blank=True, null=True)
    valid_until = models.DateField(blank=True, null=True)
    accepted_on = models.DateField(blank=True, null=True)
    created_by  = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='created_bqs')
    created_at  = models.DateTimeField(auto_now_add=True)
    updated_at  = models.DateTimeField(auto_now=True)
    class Meta:
        db_table = 'bq'; ordering = ['-created_at']
    def __str__(self): return f'{self.bq_number} (Rev {self.revision_no})'
    def save(self, *args, **kwargs):
        self.grand_total = self.total_amount + self.gst_amount
        super().save(*args, **kwargs)

class eDW(models.Model):
    """eDW Module - Deposit Work Tracking"""

    # Non-guessable ID used in URLs instead of the sequential pk
    public_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True, db_index=True)

    # Unique identifiers
    ifa_no = models.CharField(
        max_length=50,
        unique=True,
        null=True,
        blank=True,
        verbose_name="IFA No."
    )

    acn_no = models.CharField(
        max_length=50,
        unique=True,
        null=True,
        blank=True,
        verbose_name="ACN No.",
        help_text="Activity Code Number - Unique per firm"
    )
    
    # Registration & Identification
    rdr_register_number = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        verbose_name="Rdr register number"
    )
    
    acn_date = models.DateField(
        blank=True,
        null=True,
        verbose_name="ACN date"
    )
    
    company_name = models.ForeignKey(
        OrganizationMaster,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name="company name"
    )
    
    group = models.ForeignKey(
        GroupMaster,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name="group",
        help_text="Group responsible for conducting trials"
    )
    
    # ACN & Intimation
    acn_request_received_date = models.DateField(
        blank=True,
        null=True,
        verbose_name="ACN request received in I2G"
    )
    
    intimation_acn_to_group = models.CharField(
        max_length=50,
        choices=[('MAIL', 'Mail'), ('HARD_COPY', 'Hard Copy')],
        blank=True,
        null=True,
        verbose_name="intimation of ACN to group on (mail/hard copy)"
    )
    
    # BQ (Budget Quotation)
    bq_shared_to_firm_date = models.DateField(
        blank=True,
        null=True,
        verbose_name="BQ shared to firm (date)"
    )
    
    # Financial - Payments
    amount_paid_by_firm = models.DecimalField(
        max_digits=15,
        decimal_places=2,
        blank=True,
        null=True,
        verbose_name="amount paid by firm"
    )
    
    bank_reference_no = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        verbose_name="bank reference no."
    )
    
    firm_payment_date = models.DateField(
        blank=True,
        null=True,
        verbose_name="firm's payment date"
    )
    
    amount_reflected_in_acn = models.DecimalField(
        max_digits=15,
        decimal_places=2,
        blank=True,
        null=True,
        verbose_name="amount reflected in ACN"
    )
    
    # Testing Changes
    testing_changes_receipt_no = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        verbose_name="testing changes receipt no."
    )
    
    testing_changes_receipt_date = models.DateField(
        blank=True,
        null=True,
        verbose_name="testing changes receipt date"
    )
    
    # e-MRO
    emro_payment_date = models.DateField(
        blank=True,
        null=True,
        verbose_name="e-MRO payment date"
    )
    
    mro_outgoing_date = models.DateField(
        blank=True,
        null=True,
        verbose_name="MRO outgoing date"
    )
    
    mro_number = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        verbose_name="MRO no."
    )
    
    mro_date = models.DateField(
        blank=True,
        null=True,
        verbose_name="MRO date"
    )
    
    # Trial
    trial_title = models.CharField(
        max_length=500,
        blank=True,
        null=True,
        verbose_name="Trial title"
    )
    
    no_of_test_samples_planned = models.IntegerField(
        blank=True,
        null=True,
        verbose_name="no. Of test samples planned"
    )
    
    no_of_test_conducted = models.IntegerField(
        blank=True,
        null=True,
        verbose_name="no. Of test conducted"
    )
    
    trial_tentative_date = models.DateField(
        blank=True,
        null=True,
        verbose_name="Trial Tentative date"
    )
    
    account_date = models.DateField(
        blank=True,
        null=True,
        verbose_name="Account Date"
    )
    
    # Job Number
    job_number_alloted_by_i2g = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        verbose_name="job number alloyed by I2G"
    )
    
    # T.E. (Technical Evaluation)
    te_number_outgoing_date = models.DateField(
        blank=True,
        null=True,
        verbose_name="T.E. number outgoing date"
    )
    
    te_number_incoming_date = models.DateField(
        blank=True,
        null=True,
        verbose_name="T.E. number incoming date"
    )
    
    # Report
    report_received_from_group = models.DateField(
        blank=True,
        null=True,
        verbose_name="Report received from group"
    )
    
    trial_report_no = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        verbose_name="Trial Report No."
    )
    
    trial_report_issued_on = models.DateField(
        blank=True,
        null=True,
        verbose_name="Trial Report issued on"
    )
    
    report_to_whom_dispatched = models.CharField(
        max_length=500,
        blank=True,
        null=True,
        verbose_name="report to whom Dispatched"
    )
    
    dispatch_date = models.DateField(
        blank=True,
        null=True,
        verbose_name="dispatch date"
    )
    
    speed_post_no = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        verbose_name="speed post no."
    )
    
    speed_post_date = models.DateField(
        blank=True,
        null=True,
        verbose_name="speed post date"
    )
    
    # Financial - Utilization
    amount_utilized = models.DecimalField(
        max_digits=15,
        decimal_places=2,
        blank=True,
        null=True,
        verbose_name="amount utilized"
    )
    
    balance_unspent_amount = models.DecimalField(
        max_digits=15,
        decimal_places=2,
        blank=True,
        null=True,
        verbose_name="balance/unspent amount"
    )
    
    cancellation_amount = models.DecimalField(
        max_digits=15,
        decimal_places=2,
        blank=True,
        null=True,
        verbose_name="cancellation amount(if any)"
    )
    
    refund_amount = models.DecimalField(
        max_digits=15,
        decimal_places=2,
        blank=True,
        null=True,
        verbose_name="refund amount (if any)"
    )
    
    # GST
    gst_paid_on_rcm_basis_transaction_no = models.CharField(
        max_length=100,
        blank=True,
        null=True,
        verbose_name="GST paid on RCM basis transaction no."
    )
    
    gst_paid_on_rcm_basis_date = models.DateField(
        blank=True,
        null=True,
        verbose_name="GST paid on RCM basis date"
    )
    
    # Closure & Status
    for_closure = models.BooleanField(
        default=False,
        verbose_name="For closure (yes/no)"
    )
    
    dpsu_psu_private_capf = models.CharField(
        max_length=100,
        choices=[
            ('DPSU', 'DPSU'),
            ('PSU', 'PSU'),
            ('PRIVATE', 'Private Industry'),
            ('SERVICES', 'Services'),
            ('CAPF', 'CAPF')
        ],
        blank=True,
        null=True,
        verbose_name="DPSU/PSU and Pvt Industry and services/ CAPF"
    )
    
    code_head = models.CharField(
        max_length=50,
        blank=True,
        null=True,
        verbose_name="code head (xx, 017,05)"
    )
    
    status = models.CharField(
        max_length=20,
        choices=[('COMPLETED', 'Completed'), ('ONGOING', 'Ongoing')],
        default='ONGOING',
        verbose_name="status (completed/on going)"
    )
    
    remarks = models.TextField(
        blank=True,
        null=True,
        verbose_name="remarks"
    )
    
    # Primary Dak link (initial inquiry dak from firm)
    dak = models.ForeignKey(
        'DakMaster',
        on_delete=models.SET_NULL,
        related_name='edw_records',
        null=True,
        blank=True,
        verbose_name="Initial Inquiry Dak"
    )
    
    # Communication Thread (1-to-1 connection as backbone)
    thread = models.OneToOneField(
        'DakThread',
        on_delete=models.SET_NULL,
        related_name='edw_record',
        null=True,
        blank=True,
        verbose_name="Communication Thread"
    )

    # Future stage placeholder foreign keys (architectural foundation)
    ifa_dak = models.ForeignKey(
        'DakMaster',
        on_delete=models.SET_NULL,
        related_name='edw_ifa_daks',
        null=True,
        blank=True,
        verbose_name="IFA Dak"
    )
    ntr_dak = models.ForeignKey(
        'DakMaster',
        on_delete=models.SET_NULL,
        related_name='edw_ntr_daks',
        null=True,
        blank=True,
        verbose_name="NTR Dak"
    )
    bq_dak = models.ForeignKey(
        'DakMaster',
        on_delete=models.SET_NULL,
        related_name='edw_bq_daks',
        null=True,
        blank=True,
        verbose_name="BQ Dak"
    )
    emro_dak = models.ForeignKey(
        'DakMaster',
        on_delete=models.SET_NULL,
        related_name='edw_emro_daks',
        null=True,
        blank=True,
        verbose_name="eMRO Dak"
    )
    acn_dak = models.ForeignKey(
        'DakMaster',
        on_delete=models.SET_NULL,
        related_name='edw_acn_daks',
        null=True,
        blank=True,
        verbose_name="ACN Dak"
    )
    te_dak = models.ForeignKey(
        'DakMaster',
        on_delete=models.SET_NULL,
        related_name='edw_te_daks',
        null=True,
        blank=True,
        verbose_name="TE Dak"
    )
    trial_dak = models.ForeignKey(
        'DakMaster',
        on_delete=models.SET_NULL,
        related_name='edw_trial_daks',
        null=True,
        blank=True,
        verbose_name="Trial Dak"
    )
    report_dak = models.ForeignKey(
        'DakMaster',
        on_delete=models.SET_NULL,
        related_name='edw_report_daks',
        null=True,
        blank=True,
        verbose_name="Report Dak"
    )
    
    # Current workflow stage
    WORKFLOW_STAGE_CHOICES = [
        ('IFA',     'IFA — Inquiry from Applicant'),
        ('NFA',     'NFA — Not Feasible, Archived'),
        ('NTR',     'NTR — New Test Requirement'),
        ('BQ',      'BQ — Budget Quotation'),
        ('EMRO',    'eMRO — Payment Received'),
        ('ACN',     'ACN — Allotment Credit Note'),
        ('TE',      'TE — Technical Evaluation'),
        ('TRIAL',   'Trial/Test In Progress'),
        ('REPORT',  'Trial/Test Report'),
        ('CLOSED',  'DW Closed'),
    ]
    workflow_stage = models.CharField(
        max_length=20,
        choices=WORKFLOW_STAGE_CHOICES,
        default='IFA',
        verbose_name='Current Workflow Stage'
    )
    
    # GST Challan from firm (separate from EMRO GST)
    gst_challan_amount = models.DecimalField(
        max_digits=14, decimal_places=2, blank=True, null=True,
        verbose_name='GST Challan Amount from Firm'
    )
    gst_challan_date = models.DateField(blank=True, null=True, verbose_name='GST Challan Date')
    gst_challan_no   = models.CharField(max_length=100, blank=True, null=True, verbose_name='GST Challan No.')
    
    # JCC (Job Completion Certificate)
    jcc_received_date = models.DateField(blank=True, null=True, verbose_name='JCC Received Date')
    jcc_number        = models.CharField(max_length=100, blank=True, null=True, verbose_name='JCC Number')
    
    # Final GST = EMRO GST + Challan GST (auto-calculated)
    final_gst_amount = models.DecimalField(
        max_digits=14, decimal_places=2, blank=True, null=True,
        verbose_name='Final GST Amount (EMRO + Challan)'
    )
    
    # ── IFA (Inquiry Feasibility Assessment) extra fields ──────────────────
    ifa_mail_date = models.DateField(blank=True, null=True, verbose_name='IFA Mail Date')
    # company_name, dpsu_psu_private_capf (Company Category), group (Testing Group) already exist

    # ── NTR (New Test Requirement) extra fields ─────────────────────────────
    ntr_mail_received_on = models.DateField(blank=True, null=True, verbose_name='NTR Mail Received On')
    funding_agency = models.CharField(max_length=200, blank=True, null=True, verbose_name='Funding Agency')
    dw_activity = models.CharField(
        max_length=20,
        choices=[('TEST', 'Test'), ('TRIAL', 'Trial'), ('FABRICATION', 'Fabrication')],
        blank=True, null=True, verbose_name='DW Activity (Test/Trial/Fabrication)'
    )
    category_head = models.CharField(max_length=100, blank=True, null=True, verbose_name='Category Head')
    # ntr_number auto-generated; company_name, group, trial_title already exist

    # ── NFA fields ──────────────────────────────────────────────────────────
    nfa_number = models.CharField(max_length=50, blank=True, null=True, verbose_name='NFA Number')
    nfa_date   = models.DateField(blank=True, null=True, verbose_name='NFA Date')
    nfa_reason = models.TextField(blank=True, null=True, verbose_name='NFA Reason')

    # ── BQ extra fields ─────────────────────────────────────────────────────
    # bq_shared_to_firm_date, company_name, dpsu_psu_private_capf, group already exist
    bq_received_from_group_on = models.DateField(blank=True, null=True, verbose_name='BQ Received from Testing Group On')
    trial_type   = models.CharField(max_length=100, blank=True, null=True, verbose_name='Type of Trial')
    no_of_samples = models.IntegerField(blank=True, null=True, verbose_name='No. of Samples')
    bq_amount_per_trial = models.DecimalField(max_digits=15, decimal_places=2, blank=True, null=True, verbose_name='Amount per Trial / Total (₹)')

    # ── eMRO extra fields ───────────────────────────────────────────────────
    emro_payment_mode = models.CharField(
        max_length=20,
        choices=[('EMRO', 'eMRO'), ('DIRECTOR_ACCOUNT', 'Director Account')],
        blank=True, null=True, verbose_name='Payment Done By'
    )
    # group (Testing Group), category_head, mro_number, emro_payment_date already exist
    emro_received_on  = models.DateField(blank=True, null=True, verbose_name='eMRO Received On')
    gst_commitment    = models.BooleanField(default=False, verbose_name='GST Commitment')
    gst_cin_no        = models.CharField(max_length=100, blank=True, null=True, verbose_name='GST CIN No.')
    gst_cin_date      = models.DateField(blank=True, null=True, verbose_name='GST CIN Date')
    gst_cin_amount    = models.DecimalField(max_digits=15, decimal_places=2, blank=True, null=True, verbose_name='GST CIN Amount (₹)')
    acn_request_send_to_group_on = models.DateField(blank=True, null=True, verbose_name='ACN Request Send to Group On')
    # If Director Account: refund_amount already exists

    # ── ACN extra fields ────────────────────────────────────────────────────
    # acn_request_received_date (ACN request received from group) already exists
    # job_number_alloted_by_i2g (Job No.) already exists
    job_no_date     = models.DateField(blank=True, null=True, verbose_name='Job No. Date')
    rdr_no          = models.CharField(max_length=100, blank=True, null=True, verbose_name='RDR No.')
    # trial_title (DW Activity Title), company_name already exist
    acn_amount      = models.DecimalField(max_digits=15, decimal_places=2, blank=True, null=True, verbose_name='ACN Amount (₹)')
    trial_tentative_date_acn = models.DateField(blank=True, null=True, verbose_name='Trial Tentative Date (ACN Stage)')
    sanction_no     = models.CharField(max_length=100, blank=True, null=True, verbose_name='Sanction No.')
    sanction_date   = models.DateField(blank=True, null=True, verbose_name='Sanction Date')
    acn_letter_no   = models.CharField(max_length=100, blank=True, null=True, verbose_name='ACN Letter No.')
    acn_letter_date = models.DateField(blank=True, null=True, verbose_name='ACN Letter Date')
    # acn_no (ACN No.) auto-generated, acn_date already exist
    acn_allotted_on = models.DateField(blank=True, null=True, verbose_name='ACN Allotted On')
    acn_forwarded_to_group_on = models.DateField(blank=True, null=True, verbose_name='ACN Forwarded to Testing Group On')

    # ── TE extra fields ─────────────────────────────────────────────────────
    # rdr_register_number (RDR No.), acn_no (ACN No.), trial_title, company_name already exist
    te_amount       = models.DecimalField(max_digits=15, decimal_places=2, blank=True, null=True, verbose_name='TE Amount (₹)')
    rdr_code_head   = models.CharField(max_length=100, blank=True, null=True, verbose_name='RDR Code Head')
    te_letter_no    = models.CharField(max_length=100, blank=True, null=True, verbose_name='TE Letter No.')
    te_letter_date  = models.DateField(blank=True, null=True, verbose_name='TE Letter Date')
    te_sent_to_ao_on = models.DateField(blank=True, null=True, verbose_name='Sent to AO (R&D) Chandigarh On')
    te_no           = models.CharField(max_length=100, blank=True, null=True, verbose_name='TE No.')
    te_received_on  = models.DateField(blank=True, null=True, verbose_name='TE No. Received On')
    te_initiated_to_group_on = models.DateField(blank=True, null=True, verbose_name='Initiated to Group via Mail On')

    # ── Trial Details extra fields ──────────────────────────────────────────
    trial_conducted = models.CharField(
        max_length=15,
        choices=[('YES', 'Yes'), ('NO', 'No'), ('PROCESSING', 'Processing')],
        blank=True, null=True, verbose_name='Trial Conducted'
    )
    actual_trial_date = models.DateField(blank=True, null=True, verbose_name='Trial Conducted On (Actual Date)')
    trial_report_received_on = models.DateField(blank=True, null=True, verbose_name='Trial Report Received On')
    jcc_submitted_on  = models.DateField(blank=True, null=True, verbose_name='Company Submitted JCC On')
    fa_gst_submitted_on = models.DateField(blank=True, null=True, verbose_name='FA Submitted GST On')
    report_no_request_sent_on = models.DateField(blank=True, null=True, verbose_name='Request Sent for Report No. On')

    # ── Report Dispatch extra fields ────────────────────────────────────────
    # trial_report_no (Report No.), trial_report_issued_on (Report Date) already exist
    report_letter_no    = models.CharField(max_length=100, blank=True, null=True, verbose_name='Report Letter No.')
    report_dispatched_on = models.DateField(blank=True, null=True, verbose_name='Report Dispatched On (to Company)')
    # speed_post_no already exists
    ion_issued_on       = models.DateField(blank=True, null=True, verbose_name='ION Issued On')
    report_mail_to_company_on = models.DateField(blank=True, null=True, verbose_name='Mail Sent to Company On')
    report_to_tirc_on   = models.DateField(blank=True, null=True, verbose_name='Report Dispatch to TIRC (Copy 2) On')
    report_to_group_on  = models.DateField(blank=True, null=True, verbose_name='Report Dispatch to Testing Group (Copy 3) On')

    # Closure fields
    closure_request_sent_on = models.DateField(blank=True, null=True, verbose_name='Closure Request Sent On')
    te_closure_on   = models.DateField(blank=True, null=True, verbose_name='TE Closure On')
    te_closure_no   = models.CharField(max_length=100, blank=True, null=True, verbose_name='TE Closure Number')
    treasury_deposit_amount = models.DecimalField(
        max_digits=14, decimal_places=2, blank=True, null=True,
        verbose_name='Treasury/Bank Deposit Amount'
    )
    dw_closed_on    = models.DateField(blank=True, null=True, verbose_name='DW Closed On')
    is_closed       = models.BooleanField(default=False, verbose_name='DW Closed')
    
    # Audit fields
    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name="Created By"
    )
    
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name="Created At"
    )
    
    updated_at = models.DateTimeField(
        auto_now=True,
        verbose_name="Updated At"
    )
    
    class Meta:
        db_table = 'edw_master'
        verbose_name = 'eDW Record'
        verbose_name_plural = 'eDW Records'
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.ifa_no or self.acn_no or 'eDW'} - {self.company_name.org_name if self.company_name else 'No Company'}"
    
    @classmethod
    def generate_ifa_no(cls):
        """
        Generate a sequential IFA number.
        Format: IFA/XXX (e.g. IFA/003)
        """
        last = cls.objects.filter(ifa_no__startswith='IFA/').order_by('ifa_no').last()
        if last:
            try:
                parts = last.ifa_no.split('/')
                seq = int(parts[-1]) + 1
            except (ValueError, IndexError):
                seq = 1
        else:
            seq = 1
        return f'IFA/{seq:03d}'

    def save(self, *args, **kwargs):
        """Auto-calculate balance and final GST on save"""
        if not self.ifa_no:
            self.ifa_no = self.generate_ifa_no()

        if self.amount_paid_by_firm and self.amount_utilized:
            self.balance_unspent_amount = self.amount_paid_by_firm - self.amount_utilized
        # Final GST = GST through EMRO + GST challan from company
        emro_gst    = self.gst_paid_on_rcm_basis_transaction_no and 0 or 0  # populated from EMRO field
        challan_gst = self.gst_challan_amount or 0
        if challan_gst:
            self.final_gst_amount = challan_gst  # Add EMRO GST when EMRO model linked
        super().save(*args, **kwargs)
        


# ════════════════════════════════════════════════════════════════════
# eDW WORKFLOW DAK LINKS
# Tracks every Dak exchanged during the Deposit Work lifecycle.
# Each stage of the workflow has one or more associated Daks.
# ════════════════════════════════════════════════════════════════════

class eDWDakLink(models.Model):
    """
    Links a DakMaster record to an eDW record at a specific workflow stage.
    This is how every communication (letter/fax/ION/mail) in the DW 
    lifecycle is tracked against the eDW record.
    
    Workflow stages and their typical dak directions:
      INQUIRY        - Incoming  (firm sends initial request to IIG)
      NTR_FORWARD    - Outgoing  (IIG forwards to Testing Group)
      FEASIBILITY    - Incoming  (Group replies with feasibility)
      BQ_SENT        - Outgoing  (IIG sends BQ to Firm)
      PAYMENT        - Incoming  (Firm sends eMRO/payment dak)
      ACN_REQUEST    - Outgoing  (Group requests ACN from DFMM)
      ACN_RECEIVED   - Incoming  (DFMM issues ACN to IIG)
      ACN_TO_GROUP   - Outgoing  (IIG shares ACN with Group)
      TRIAL_REPORT   - Incoming  (Group sends trial report to IIG)
      JCC_DEMAND     - Outgoing  (IIG demands JCC + GST from Firm)
      JCC_RECEIVED   - Incoming  (Firm sends JCC + GST challan)
      REPORT_ISSUED  - Outgoing  (IIG issues final report to Firm)
      OTHER          - Any       (Miscellaneous correspondence)
    """
    STAGE_CHOICES = [
        ('IFA',           'IFA — Inquiry from Applicant'),
        ('NTR',           'NTR — New Test Requirement'),
        ('NTR_FORWARD',   'NTR Forwarded to Group'),
        ('FEASIBILITY',   'Feasibility Reply from Group'),
        ('BQ',            'BQ — Sent to Firm'),
        ('EMRO',          'eMRO — Payment from Firm'),
        ('ACN',           'ACN — Allotment Credit Note'),
        ('ACN_TO_GROUP',  'ACN Shared with Group'),
        ('TE',            'TE — Technical Evaluation'),
        ('TRIAL',         'Trial/Test Details'),
        ('REPORT',        'Trial/Test Report'),
        ('CLOSURE',       'Closure Correspondence'),
        ('OTHER',         'Other Correspondence'),
    ]

    edw      = models.ForeignKey(
        'eDW', on_delete=models.CASCADE,
        related_name='dak_links',
        verbose_name='eDW Record'
    )
    dak      = models.ForeignKey(
        'DakMaster', on_delete=models.CASCADE,
        related_name='edw_links',
        verbose_name='Linked Dak'
    )
    stage    = models.CharField(
        max_length=20, choices=STAGE_CHOICES,
        verbose_name='Workflow Stage'
    )
    notes    = models.TextField(blank=True, null=True, verbose_name='Notes')
    linked_by= models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True,
        related_name='edw_dak_links'
    )
    linked_at= models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'edw_dak_link'
        verbose_name = 'eDW Dak Link'
        verbose_name_plural = 'eDW Dak Links'
        ordering = ['linked_at']
        unique_together = [('edw', 'dak', 'stage')]

    def __str__(self):
        return f"{self.edw.acn_no} ← [{self.stage}] → {self.dak.dak_index_no}"


# ════════════════════════════════════════════════════════════════════
# eDW NTR — New Test Requirement (part of eDW workflow)
# IIG creates NTR from the initial inquiry dak.
# NTR number format: NTR-001-GROUPNAME-YEAR
# ════════════════════════════════════════════════════════════════════

class eDWNTR(models.Model):
    """
    NTR created by IIG after receiving inquiry dak from firm.
    Directly linked to eDW record and the triggering Dak.
    """
    STATUS_CHOICES = [
        ('DRAFT',      'Draft'),
        ('FORWARDED',  'Forwarded to Group'),
        ('FEASIBLE',   'Group Confirmed Feasible'),
        ('INFEASIBLE', 'Group Confirmed Infeasible'),
        ('BQ_ISSUED',  'BQ Issued to Firm'),
        ('CANCELLED',  'Cancelled'),
    ]

    edw          = models.OneToOneField(
        'eDW', on_delete=models.CASCADE,
        related_name='ntr',
        verbose_name='eDW Record'
    )
    ntr_number   = models.CharField(max_length=60, unique=True, verbose_name='NTR Number')
    sequence_no  = models.PositiveIntegerField(verbose_name='Sequence No.')
    year         = models.PositiveIntegerField(verbose_name='Year')
    status       = models.CharField(
        max_length=12, choices=STATUS_CHOICES, default='DRAFT'
    )
    # Dak that triggered NTR creation (initial inquiry from firm)
    inquiry_dak  = models.ForeignKey(
        'DakMaster', on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='ntr_inquiry',
        verbose_name='Inquiry Dak (from Firm)'
    )
    # Dak sent to group for feasibility check
    forwarded_dak= models.ForeignKey(
        'DakMaster', on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='ntr_forwarded',
        verbose_name='Dak Forwarded to Group'
    )
    # Dak received from group confirming feasibility
    feasibility_dak = models.ForeignKey(
        'DakMaster', on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='ntr_feasibility',
        verbose_name='Feasibility Reply Dak'
    )
    is_feasible     = models.BooleanField(default=True)
    feasibility_remarks = models.TextField(blank=True, null=True)
    ntr_date        = models.DateField(blank=True, null=True, verbose_name='NTR Date')
    forwarded_date  = models.DateField(blank=True, null=True, verbose_name='Forwarded to Group On')
    feasibility_date= models.DateField(blank=True, null=True, verbose_name='Feasibility Confirmed On')
    created_by      = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, related_name='edw_ntrs'
    )
    created_at      = models.DateTimeField(auto_now_add=True)
    updated_at      = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'edw_ntr'
        verbose_name = 'eDW NTR'
        verbose_name_plural = 'eDW NTRs'

    def __str__(self):
        return self.ntr_number

    @classmethod
    def generate_number(cls, group, year):
        # Format: NTR/YYYY-YY/XXXX  e.g. NTR/2026-27/0001
        short_year = str(year)[2:]
        next_year_short = str(year + 1)[2:]
        fiscal_suffix = f"{year}-{next_year_short}"
        prefix = f"NTR/{fiscal_suffix}/"
        last = cls.objects.filter(ntr_number__startswith=prefix).order_by('-sequence_no').first()
        seq  = (last.sequence_no + 1) if last else 1
        return f"{prefix}{seq:04d}", seq


# ════════════════════════════════════════════════════════════════════
# eDW BQ — Budgetary Quotation (part of eDW workflow)
# Issued by IIG to firm after feasibility confirmed.
# ════════════════════════════════════════════════════════════════════

class eDWBQ(models.Model):
    """
    BQ prepared by IIG and sent to firm.
    Directly linked to eDW record.
    """
    STATUS_CHOICES = [
        ('DRAFT',    'Draft'),
        ('SENT',     'Sent to Firm'),
        ('ACCEPTED', 'Accepted by Firm'),
        ('REVISED',  'Revised'),
        ('REJECTED', 'Rejected'),
    ]

    edw          = models.ForeignKey(
        'eDW', on_delete=models.CASCADE,
        related_name='bqs',
        verbose_name='eDW Record'
    )
    bq_number    = models.CharField(max_length=80, unique=True, verbose_name='BQ Number')
    revision_no  = models.PositiveSmallIntegerField(default=1)
    status       = models.CharField(max_length=10, choices=STATUS_CHOICES, default='DRAFT')
    vendor_registration_no = models.CharField(
        max_length=100, blank=True, null=True,
        verbose_name='Vendor Registration No.'
    )

    # Dak through which BQ was sent to firm
    bq_dak       = models.ForeignKey(
        'DakMaster', on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='bq_sent',
        verbose_name='BQ Sent via Dak'
    )

    # Financial
    total_amount = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    gst_amount   = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    grand_total  = models.DecimalField(max_digits=14, decimal_places=2, default=0)

    bq_date      = models.DateField(blank=True, null=True, verbose_name='BQ Date')
    bq_received_from_group_date = models.DateField(blank=True, null=True, verbose_name='BQ Received from Testing Group Date')
    valid_until  = models.DateField(blank=True, null=True)
    accepted_on  = models.DateField(blank=True, null=True)
    description  = models.TextField(blank=True, null=True)
    remarks      = models.TextField(blank=True, null=True)

    created_by   = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, related_name='edw_bqs'
    )
    created_at   = models.DateTimeField(auto_now_add=True)
    updated_at   = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'edw_bq'
        verbose_name = 'eDW BQ'
        verbose_name_plural = 'eDW BQs'

    def __str__(self):
        return f'{self.bq_number} (Rev {self.revision_no})'

    def save(self, *args, **kwargs):
        self.grand_total = self.total_amount + self.gst_amount
        super().save(*args, **kwargs)

# ═══════════════════════════════════════════════════════════════════════════════
# eTOT — Transfer of Technology Module
# ═══════════════════════════════════════════════════════════════════════════════

class eTOT(models.Model):
    """
    eTOT — Transfer of Technology.
    One row = one Licensee receiving a technology.
    Same ToT File No. can appear in multiple rows (one per industry/licensee).
    LAToT No. and TTD No. are unique per row.
    Multiple Daks linked via eTOTDakLink.
    """

    # Non-guessable ID used in URLs instead of the sequential pk
    public_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True, db_index=True)

    STAGE_CHOICES = [
        ('INITIATED',      'Initiated'),
        ('TNF',            'TNF Stage'),
        ('EOI',            'EOI Stage'),
        ('CEC',            'CEC Stage'),
        ('TAC',            'TAC Stage'),
        ('LAToT',          'LAToT Stage'),
        ('TTD',            'TTD Stage'),
        ('TA_CERTIFICATE', 'TA Certificate Stage'),
        ('COMPLETED',      'Completed'),
        ('TERMINATED',     'Terminated'),
    ]

    CATEGORY_CHOICES = [
        ('A', 'Category A'),
        ('B', 'Category B'),
    ]

    # ── 1. IDENTIFICATION ─────────────────────────────────────────────────────
    tot_file_no = models.CharField(
        max_length=100,
        verbose_name="ToT File No.",
        help_text="e.g. ToT-0103 — same file no. can appear for multiple licensees"
    )

    product_technology = models.CharField(
        max_length=500,
        verbose_name="Product / Technology"
    )

    technology_category = models.CharField(
        max_length=2,
        choices=CATEGORY_CHOICES,
        blank=True, null=True,
        verbose_name="Categorization of Technology (A/B)"
    )

    stage = models.CharField(
        max_length=20,
        choices=STAGE_CHOICES,
        default='INITIATED',
        verbose_name="Current Stage"
    )

    # ── 2. STAKEHOLDERS ───────────────────────────────────────────────────────
    technical_group = models.ForeignKey(
        'GroupMaster',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='etot_records',
        verbose_name="Technical Group"
    )

    point_of_contact = models.ForeignKey(
        'PersonMaster',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='etot_poc_records',
        verbose_name="Point of Contact from TBRL"
    )

    # Licensee / awarded industry
    licensee_name = models.CharField(
        max_length=500,
        blank=True, null=True,
        verbose_name="Name of Awarded Licensee"
    )

    licensee_company = models.ForeignKey(
        'OrganizationMaster',
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='etot_licensee_records',
        verbose_name="Licensee Company (from Organization Master)"
    )

    licensee_address = models.TextField(
        blank=True, null=True,
        verbose_name="Address of Recipient Industry"
    )

    # ── 3. MEETING & MINUTE DETAILS ───────────────────────────────────────────
    meeting_held_on = models.DateField(
        blank=True, null=True,
        verbose_name="Meeting Held On"
    )

    minute_signed_by_chairman_on = models.DateField(
        blank=True, null=True,
        verbose_name="Minute Signed by Chairman"
    )

    minute_approved_by_director_on = models.DateField(
        blank=True, null=True,
        verbose_name="Minute Approved by Director, TBRL"
    )

    # ── 4. TNF DETAILS ────────────────────────────────────────────────────────
    tnf_initiated_by_group_on = models.DateField(
        blank=True, null=True,
        verbose_name="TNF Initiated by Group"
    )

    tnf_certificate_issued_by_director_on = models.DateField(
        blank=True, null=True,
        verbose_name="TNF Certificate Issued by Director On"
    )

    tnf_nom_no = models.CharField(
        max_length=100,
        blank=True, null=True,
        verbose_name="TNF NOM No."
    )

    tnf_no_allotted_by_diitm_on = models.DateField(
        blank=True, null=True,
        verbose_name="TNF No. Allotted by DIITM On"
    )

    # ── 5. LICENSE COUNT ──────────────────────────────────────────────────────
    no_of_licenses_approved = models.PositiveIntegerField(
        blank=True, null=True,
        verbose_name="No. of Licenses Approved"
    )

    additional_no_of_licenses = models.PositiveIntegerField(
        blank=True, null=True,
        default=0,
        verbose_name="Additional No. of Licenses"
    )

    total_no_of_awarded_licenses = models.PositiveIntegerField(
        blank=True, null=True,
        verbose_name="Total No. of Awarded Licenses",
        help_text="Auto-calculated: Licenses Approved + Additional Licenses"
    )

    licenses_awarded_to_industry = models.PositiveIntegerField(
        blank=True, null=True,
        default=0,
        verbose_name="Licenses Awarded to Industry (actual)"
    )

    no_of_available_licensee = models.IntegerField(
        blank=True, null=True,
        verbose_name="No. of Available Licensee",
        help_text="Auto-calculated: Total Licenses − Licenses Awarded to Industry"
    )

    # ── 6. EOI DETAILS ────────────────────────────────────────────────────────
    eoi_hosting_on_portal = models.DateField(
        blank=True, null=True,
        verbose_name="EOI Hosting on Portal"
    )

    # ── 7. CEC DETAILS ────────────────────────────────────────────────────────
    cec_constitution_on = models.DateField(
        blank=True, null=True,
        verbose_name="CEC Constitution"
    )

    cec_meeting_held_on = models.DateField(
        blank=True, null=True,
        verbose_name="CEC Meeting Held On"
    )

    cec_report_signed_by_chairman_on = models.DateField(
        blank=True, null=True,
        verbose_name="CEC Report Signed by Chairman"
    )

    cec_min_forwarded_by_director_on = models.DateField(
        blank=True, null=True,
        verbose_name="CEC Min Forwarded by Director"
    )

    cec_recommended_by_dg_mss_on = models.DateField(
        blank=True, null=True,
        verbose_name="CEC Recommended by DG(MSS)"
    )

    recommended_cec_report_to_diitm_on = models.DateField(
        blank=True, null=True,
        verbose_name="Recommended CEC Report to DIITM"
    )

    cec_approved_by_dg_pc_s7_on = models.DateField(
        blank=True, null=True,
        verbose_name="CEC Approved by DG(PC & S7)"
    )

    # ── 8. TAC DETAILS ────────────────────────────────────────────────────────
    tac_constitution_by_dir_dg_mss_on = models.DateField(
        blank=True, null=True,
        verbose_name="TAC Constitution by Dir/DG(MSS) On"
    )

    tac1_no_of_eoi_received = models.PositiveIntegerField(
        blank=True, null=True,
        verbose_name="TAC-1 No. of EOI Received from Industry"
    )

    defence_industrial_license_no = models.CharField(
        max_length=200,
        blank=True, null=True,
        verbose_name="Defence Industrial License No."
    )

    defence_industrial_license_date = models.DateField(
        blank=True, null=True,
        verbose_name="Defence Industrial License Date"
    )

    peso_license_no = models.CharField(
        max_length=200,
        blank=True, null=True,
        verbose_name="PESO License No."
    )

    peso_license_date = models.DateField(
        blank=True, null=True,
        verbose_name="PESO License Date"
    )

    tac1_meeting_held_on = models.DateField(
        blank=True, null=True,
        verbose_name="TAC-1 Meeting Held On"
    )

    tac1_report_signed_by_chairman_on = models.DateField(
        blank=True, null=True,
        verbose_name="TAC-1 Report Signed by Chairman"
    )

    tac1_report_recommended_by_director_on = models.DateField(
        blank=True, null=True,
        verbose_name="TAC-1 Report Recommended by Director, TBRL"
    )

    tac1_report_approved_by_dg_mss_on = models.DateField(
        blank=True, null=True,
        verbose_name="TAC-1 Report Approved by DG(MSS)"
    )

    tac1_recommended_firms = models.TextField(
        blank=True, null=True,
        verbose_name="TAC-1 Recommended Firms / Industry"
    )

    tac1_report_forwarded_to_diitm_on = models.DateField(
        blank=True, null=True,
        verbose_name="TAC-1 Report (approved by DG(MSS)) Forwarded to DIITM On"
    )

    # ── 9. LAToT DETAILS ──────────────────────────────────────────────────────
    vetted_latot_shared_with_industry_on = models.DateField(
        blank=True, null=True,
        verbose_name="Vetted LAToT Shared with Industry"
    )

    signed_stamped_latot_received_on = models.DateField(
        blank=True, null=True,
        verbose_name="Duly Signed & Stamped LAToT Paper by Industry Received On"
    )

    emro_no = models.CharField(
        max_length=100,
        blank=True, null=True,
        verbose_name="eMRO No."
    )

    tot_fee_paid_by_licensee = models.DecimalField(
        max_digits=15, decimal_places=2,
        blank=True, null=True,
        verbose_name="ToT Fee Paid by Licensee (₹)"
    )

    tot_fee_paid_on = models.DateField(
        blank=True, null=True,
        verbose_name="ToT Fee Paid On"
    )

    gst_details = models.CharField(
        max_length=500,
        blank=True, null=True,
        verbose_name="GST Details"
    )

    latot_no = models.CharField(
        max_length=100,
        blank=True, null=True,
        unique=True,
        verbose_name="LAToT No.",
        help_text="Unique License Agreement for Transfer of Technology number"
    )

    latot_signed_on = models.DateField(
        blank=True, null=True,
        verbose_name="LAToT Signed On"
    )

    latot_signed_year = models.CharField(
        max_length=10,
        blank=True, null=True,
        verbose_name="LAToT Signed Year"
    )

    # ── 10. TTD DETAILS ───────────────────────────────────────────────────────
    ttd_no = models.CharField(
        max_length=100,
        blank=True, null=True,
        unique=True,
        verbose_name="TTD No.",
        help_text="Unique Technology Transfer Document number"
    )

    ttd_issued_on = models.DateField(
        blank=True, null=True,
        verbose_name="TTD Issued On"
    )

    hand_holding_support_weeks = models.PositiveIntegerField(
        blank=True, null=True,
        verbose_name="Hand Holding Support Period (Weeks)"
    )

    # ── 11. ToT ABSORPTION ────────────────────────────────────────────────────
    tot_absorption_request_received_on = models.DateField(
        blank=True, null=True,
        verbose_name="ToT Absorption Request Received On"
    )

    tot_absorption_recommendation_from_group_on = models.DateField(
        blank=True, null=True,
        verbose_name="ToT Absorption Recommendation Received from User Group"
    )

    director_tbrl_recommendation_for_ta_on = models.DateField(
        blank=True, null=True,
        verbose_name="Director, TBRL Recommendation for TA Certificate"
    )

    # ── 12. TA CERTIFICATE ────────────────────────────────────────────────────
    ta_certificate_no = models.CharField(
        max_length=100,
        blank=True, null=True,
        verbose_name="TA Certificate No."
    )

    ta_certificate_issued_on = models.DateField(
        blank=True, null=True,
        verbose_name="TA Certificate Issued On"
    )

    ta_certificate_validity = models.CharField(
        max_length=100,
        blank=True, null=True,
        verbose_name="Validity of TA Certificate"
    )

    # ── 13. ROYALTY ───────────────────────────────────────────────────────────
    royalty_fee_received = models.DecimalField(
        max_digits=15, decimal_places=2,
        blank=True, null=True,
        verbose_name="Royalty Fee Received from Licensee (₹)"
    )

    # ── 14. REMARKS ───────────────────────────────────────────────────────────
    remarks = models.TextField(
        blank=True, null=True,
        verbose_name="Remarks"
    )

    # ── AUDIT ─────────────────────────────────────────────────────────────────
    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='etot_created',
        verbose_name="Created By"
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'etot_master'
        verbose_name = 'eTOT Record'
        verbose_name_plural = 'eTOT Records'
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.tot_file_no} — {self.product_technology[:50]}"

    def save(self, *args, **kwargs):
        """Auto-calculate license counts on save"""
        approved = self.no_of_licenses_approved or 0
        additional = self.additional_no_of_licenses or 0
        awarded = self.licenses_awarded_to_industry or 0
        self.total_no_of_awarded_licenses = approved + additional
        self.no_of_available_licensee = self.total_no_of_awarded_licenses - awarded
        super().save(*args, **kwargs)


class eTOTDakLink(models.Model):
    """
    Links multiple DakMaster records to one eTOT record.
    Each link has a label so you know what the Dak represents
    (e.g. 'TNF Letter', 'Meeting Minutes', 'LAToT Dispatch').
    """
    LINK_TYPE_CHOICES = [
        ('MEETING_MINUTES',   'Meeting Minutes'),
        ('TNF_LETTER',        'TNF Letter'),
        ('EOI_LETTER',        'EOI Letter'),
        ('CEC_REPORT',        'CEC Report'),
        ('TAC_REPORT',        'TAC Report'),
        ('LATOT_DISPATCH',    'LAToT Dispatch'),
        ('TTD_LETTER',        'TTD Letter'),
        ('TA_CERT_LETTER',    'TA Certificate Letter'),
        ('FEE_RECEIPT',       'Fee Receipt'),
        ('OTHER',             'Other'),
    ]

    etot = models.ForeignKey(
        eTOT,
        on_delete=models.CASCADE,
        related_name='dak_links',
        verbose_name="eTOT Record"
    )

    dak = models.ForeignKey(
        'DakMaster',
        on_delete=models.CASCADE,
        related_name='etot_links',
        verbose_name="Linked Dak"
    )

    link_type = models.CharField(
        max_length=30,
        choices=LINK_TYPE_CHOICES,
        default='OTHER',
        verbose_name="Link Type"
    )

    notes = models.CharField(
        max_length=300,
        blank=True, null=True,
        verbose_name="Notes"
    )

    linked_on = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'etot_dak_links'
        verbose_name = 'eTOT Dak Link'
        unique_together = [('etot', 'dak')]

    def __str__(self):
        return f"{self.etot.tot_file_no} ↔ {self.dak.dak_index_no} ({self.link_type})"


# ═══════════════════════════════════════════════════════════════════════════════
# eIIG — Visitor Management Module
# ═══════════════════════════════════════════════════════════════════════════════

class eIIGVisit(models.Model):
    """
    eIIG — One record = one visit (delegation/individual).
    Multiple visitors per visit via eIIGVisitor (related model).
    Visit ID auto-generated as DCMM/I2G/YYYY-YY/XXXX per financial year.
    """

    # Non-guessable ID used in URLs instead of the sequential pk
    public_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True, db_index=True)

    CATEGORY_CHOICES = [
        ('INDUSTRY',   'Industry'),
        ('GOVERNMENT', 'Government'),
        ('RESEARCH',   'Research / Academic'),
        ('INDIVIDUAL', 'Individual'),
        ('OTHER',      'Other'),
    ]

    SUBCATEGORY_CHOICES = [
        # Industry
        ('PRIVATE',   'Private'),
        ('DPSU',      'DPSU'),
        ('PSU',       'PSU'),
        ('MSME',      'MSME'),
        ('STARTUP',   'Startup'),
        # Government
        ('CENTRAL',   'Central Govt.'),
        ('STATE',     'State Govt.'),
        ('DEFENCE',   'Defence'),
        ('CAPF',      'CAPF'),
        # Research / Academic
        ('UNIVERSITY','University'),
        ('RESEARCH_INST', 'Research Institute'),
        ('IIT_NIT',   'IIT / NIT'),
        ('LAB',       'Laboratory'),
        # Individual
        ('ENTREPRENEUR', 'Entrepreneur'),
        ('STUDENT',   'Student'),
        ('RESEARCHER','Researcher'),
        # Other
        ('OTHER',     'Other'),
    ]

    INDIAN_STATES = [
        ('', '— Select State —'),
        ('AN', 'Andaman & Nicobar Islands'),
        ('AP', 'Andhra Pradesh'),
        ('AR', 'Arunachal Pradesh'),
        ('AS', 'Assam'),
        ('BR', 'Bihar'),
        ('CH', 'Chandigarh'),
        ('CG', 'Chhattisgarh'),
        ('DN', 'Dadra & Nagar Haveli and Daman & Diu'),
        ('DL', 'Delhi'),
        ('GA', 'Goa'),
        ('GJ', 'Gujarat'),
        ('HR', 'Haryana'),
        ('HP', 'Himachal Pradesh'),
        ('JK', 'Jammu & Kashmir'),
        ('JH', 'Jharkhand'),
        ('KA', 'Karnataka'),
        ('KL', 'Kerala'),
        ('LA', 'Ladakh'),
        ('LD', 'Lakshadweep'),
        ('MP', 'Madhya Pradesh'),
        ('MH', 'Maharashtra'),
        ('MN', 'Manipur'),
        ('ML', 'Meghalaya'),
        ('MZ', 'Mizoram'),
        ('NL', 'Nagaland'),
        ('OD', 'Odisha'),
        ('PY', 'Puducherry'),
        ('PB', 'Punjab'),
        ('RJ', 'Rajasthan'),
        ('SK', 'Sikkim'),
        ('TN', 'Tamil Nadu'),
        ('TG', 'Telangana'),
        ('TR', 'Tripura'),
        ('UP', 'Uttar Pradesh'),
        ('UK', 'Uttarakhand'),
        ('WB', 'West Bengal'),
    ]

    # ── VISIT ID ──────────────────────────────────────────────────────────────
    visit_id = models.CharField(
        max_length=30,
        unique=True,
        verbose_name="Visit ID",
        help_text="Auto-generated: DCMM/I2G/YYYY-YY/XXXX"
    )

    # ── VISIT DATE ────────────────────────────────────────────────────────────
    date_of_visit = models.DateField(
        verbose_name="Date of Visit"
    )

    # ── FIRM / INDUSTRY ───────────────────────────────────────────────────────
    firm_name = models.CharField(
        max_length=500,
        verbose_name="Name of Firm / Industry"
    )

    firm_address = models.TextField(
        blank=True, null=True,
        verbose_name="Complete Address"
    )

    firm_state = models.CharField(
        max_length=5,
        choices=INDIAN_STATES,
        blank=True, null=True,
        verbose_name="State"
    )

    # ── CATEGORY ─────────────────────────────────────────────────────────────
    company_category = models.CharField(
        max_length=20,
        choices=CATEGORY_CHOICES,
        blank=True, null=True,
        verbose_name="Company Category"
    )

    company_sub_category = models.CharField(
        max_length=20,
        choices=SUBCATEGORY_CHOICES,
        blank=True, null=True,
        verbose_name="Sub Category"
    )

    # ── PURPOSE & FEEDBACK ────────────────────────────────────────────────────
    purpose_of_visit = models.TextField(
        blank=True, null=True,
        verbose_name="Purpose of Visit"
    )

    feedback = models.TextField(
        blank=True, null=True,
        verbose_name="Feedback"
    )

    remarks = models.TextField(
        blank=True, null=True,
        verbose_name="Remarks"
    )

    # ── AUDIT ─────────────────────────────────────────────────────────────────
    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='iig_visits_created',
        verbose_name="Created By"
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'eiig_visit'
        verbose_name = 'eIIG Visit'
        verbose_name_plural = 'eIIG Visits'
        ordering = ['-date_of_visit', '-created_at']

    def __str__(self):
        return f"{self.visit_id} — {self.firm_name}"

    @property
    def visitor_names(self):
        return ", ".join(v.name for v in self.visitors.all())

    @staticmethod
    def get_financial_year(date=None):
        """Returns financial year string like 2026-27 for a given date."""
        from datetime import date as dt
        d = date or dt.today()
        if d.month >= 4:
            return f"{d.year}-{str(d.year + 1)[2:]}"
        else:
            return f"{d.year - 1}-{str(d.year)[2:]}"

    @classmethod
    def generate_visit_id(cls, visit_date=None):
        """
        Auto-generate next Visit ID for the financial year of visit_date.
        Format: DCMM/I2G/2026-27/0001
        """
        from datetime import date as dt
        d = visit_date or dt.today()
        fy = cls.get_financial_year(d)
        prefix = f"DCMM/I2G/{fy}/"
        last = (
            cls.objects
            .filter(visit_id__startswith=prefix)
            .order_by('visit_id')
            .values_list('visit_id', flat=True)
            .last()
        )
        if last:
            try:
                last_num = int(last.split('/')[-1])
            except ValueError:
                last_num = 0
        else:
            last_num = 0
        return f"{prefix}{str(last_num + 1).zfill(4)}"

    def save(self, *args, **kwargs):
        if not self.visit_id:
            self.visit_id = self.generate_visit_id(self.date_of_visit)
        super().save(*args, **kwargs)


class eIIGVisitor(models.Model):
    """
    One visitor in a visit delegation.
    Each visit can have multiple visitors.
    """
    visit = models.ForeignKey(
        eIIGVisit,
        on_delete=models.CASCADE,
        related_name='visitors',
        verbose_name="Visit"
    )

    name = models.CharField(
        max_length=200,
        verbose_name="Name of Visitor"
    )

    designation = models.CharField(
        max_length=200,
        blank=True, null=True,
        verbose_name="Designation"
    )

    mobile_1 = models.CharField(
        max_length=15,
        blank=True, null=True,
        verbose_name="Mobile No. 1"
    )

    mobile_2 = models.CharField(
        max_length=15,
        blank=True, null=True,
        verbose_name="Mobile No. 2"
    )

    email_1 = models.EmailField(
        blank=True, null=True,
        verbose_name="Email ID 1"
    )

    email_2 = models.EmailField(
        blank=True, null=True,
        verbose_name="Email ID 2"
    )

    class Meta:
        db_table = 'eiig_visitor'
        verbose_name = 'Visitor'
        verbose_name_plural = 'Visitors'

    def __str__(self):
        return f"{self.name} ({self.visit.visit_id})"


# ═══════════════════════════════════════════════════════════════════
# USER PROFILE — Module Permissions & Photo Capture Control
# ═══════════════════════════════════════════════════════════════════

class UserProfile(models.Model):
    """
    Extends Django's built-in User with per-module access flags
    and a photo capture permission. Created automatically via signal
    whenever a new User is saved.
    """
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name='profile',
        verbose_name="User"
    )

    # ── Module Access ──────────────────────────────────────────
    can_access_incoming_dak = models.BooleanField(
        default=True,
        verbose_name="Incoming Dak"
    )
    can_access_edw = models.BooleanField(
        default=False,
        verbose_name="eDW Module"
    )
    can_access_etot = models.BooleanField(
        default=False,
        verbose_name="eTOT Module"
    )
    can_access_eiig = models.BooleanField(
        default=False,
        verbose_name="eIIG Module"
    )
    can_access_reports = models.BooleanField(
        default=False,
        verbose_name="Reports"
    )
    can_access_task = models.BooleanField(
        default=False,
        verbose_name="Task Management"
    )

    # ── Special Permissions ────────────────────────────────────
    can_capture_photo = models.BooleanField(
        default=False,
        verbose_name="Allow Photo / Camera Capture"
    )
    can_take_screenshot = models.BooleanField(
        default=True,
        verbose_name="Allow Screenshots"
    )

    # ── Extra Info ─────────────────────────────────────────────
    department = models.CharField(
        max_length=120,
        blank=True,
        default='',
        verbose_name="Department"
    )
    notes = models.TextField(
        blank=True,
        default='',
        verbose_name="Admin Notes"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'user_profile'
        verbose_name = 'User Profile'
        verbose_name_plural = 'User Profiles'

    def __str__(self):
        return f"Profile({self.user.username})"

    def get_accessible_modules(self):
        """Returns a list of module names this user can access."""
        modules = []
        if self.can_access_incoming_dak:
            modules.append('Incoming Dak')
        if self.can_access_edw:
            modules.append('eDW')
        if self.can_access_etot:
            modules.append('eTOT')
        if self.can_access_eiig:
            modules.append('eIIG')
        if self.can_access_reports:
            modules.append('Reports')
        if self.can_access_task:
            modules.append('Tasks')
        return modules


# ════════════════════════════════════════════════════════════════════
# FIX 6 — ADMIN-DEFINED EXTRA COLUMNS
# Allows admins to add custom text/date/number columns to eDW,
# eToT, and eIIG records without touching the DB schema.
# Values are stored in ModuleExtraColumnValue (key-value table).
# ════════════════════════════════════════════════════════════════════

class ModuleExtraColumn(models.Model):
    """Admin-defined extra column for a module."""

    MODULE_CHOICES = [
        ('dak',  'Dak'),
        ('edw',  'eDW'),
        ('etot', 'eToT'),
        ('eiig', 'eIIG'),
    ]
    FIELD_TYPE_CHOICES = [
        ('text',   'Text'),
        ('number', 'Number'),
        ('date',   'Date'),
        ('bool',   'Yes / No'),
    ]

    module      = models.CharField(max_length=10, choices=MODULE_CHOICES, db_index=True)
    column_label = models.CharField(max_length=200, verbose_name='Column Label')
    field_type  = models.CharField(max_length=10, choices=FIELD_TYPE_CHOICES, default='text')
    workflow_header = models.CharField(max_length=100, blank=True, null=True, verbose_name='Workflow Header')
    sort_order  = models.PositiveSmallIntegerField(default=0,
                    help_text='Lower number = appears first')
    is_active   = models.BooleanField(default=True)
    created_by  = models.ForeignKey(User, on_delete=models.SET_NULL,
                    null=True, blank=True, related_name='extra_columns_created')
    created_at  = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'module_extra_column'
        ordering = ['module', 'sort_order', 'column_label']
        verbose_name = 'Module Extra Column'
        verbose_name_plural = 'Module Extra Columns'

    def __str__(self):
        return f'[{self.module.upper()}] {self.column_label}'

    @property
    def column_key(self):
        """URL-safe key derived from label, used in forms and storage."""
        import re
        return re.sub(r'[^a-z0-9_]', '_',
                      self.column_label.lower().replace(' ', '_'))[:60]


class ModuleExtraColumnValue(models.Model):
    """Stores the value of an extra column for a specific record."""

    column      = models.ForeignKey(ModuleExtraColumn, on_delete=models.CASCADE,
                    related_name='values')
    # Generic record reference — store the record's pk as a string
    record_pk   = models.CharField(max_length=50, db_index=True)
    value       = models.TextField(blank=True, null=True)
    updated_at  = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'module_extra_column_value'
        unique_together = ('column', 'record_pk')
        verbose_name = 'Extra Column Value'

    def __str__(self):
        return f'{self.column.column_label} → record {self.record_pk}: {self.value}'
