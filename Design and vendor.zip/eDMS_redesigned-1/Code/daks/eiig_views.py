"""
eIIG Module — Visitor Management Views
"""
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.http import HttpResponse, JsonResponse
from django.db.models import Q, Count, Prefetch
from django.db import transaction
from .models import eIIGVisit, eIIGVisitor
from .forms import eIIGVisitForm, VisitorFormSet
import pandas as pd
from io import BytesIO


# ─────────────────────────────────────────────────────────────────────────────
# DASHBOARD
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def eiig_dashboard(request):

    # ── Module access guard ──────────────────────────────────────
    if not request.user.is_staff:
        from .models import UserProfile
        try:
            profile = request.user.profile
        except UserProfile.DoesNotExist:
            profile = UserProfile.objects.create(user=request.user)
        if not getattr(profile, 'can_access_eiig', False):
            from django.contrib import messages as _msg
            _msg.error(request, 'You do not have permission to access this module.')
            return redirect('daks:home')
    # ─────────────────────────────────────────────────────────────
    qs = (
        eIIGVisit.objects.all()
        .annotate(visitor_count=Count('visitors'))
        .prefetch_related('visitors')
        .order_by('-date_of_visit', '-created_at')
    )

    # Search
    search = request.GET.get('search', '').strip()
    if search:
        qs = qs.filter(
            Q(visit_id__icontains=search) |
            Q(firm_name__icontains=search) |
            Q(visitors__name__icontains=search) |
            Q(purpose_of_visit__icontains=search)
        ).distinct()

    # Filters
    category_filter = request.GET.get('category', '').strip()
    if category_filter:
        qs = qs.filter(company_category=category_filter)

    state_filter = request.GET.get('state', '').strip()
    if state_filter:
        qs = qs.filter(firm_state=state_filter)

    year_filter = request.GET.get('fy', '').strip()
    if year_filter:
        qs = qs.filter(visit_id__contains=f'/{year_filter}/')

    date_from = request.GET.get('date_from', '').strip()
    if date_from:
        qs = qs.filter(date_of_visit__gte=date_from)

    date_to = request.GET.get('date_to', '').strip()
    if date_to:
        qs = qs.filter(date_of_visit__lte=date_to)

    # Stats
    total_visits   = qs.count()
    total_visitors = eIIGVisitor.objects.filter(visit__in=qs).count()

    # Pagination
    paginator = Paginator(qs, 50)
    try:
        page_obj = paginator.page(request.GET.get('page', 1))
    except (PageNotAnInteger, EmptyPage):
        page_obj = paginator.page(1)

    # Current financial year for display
    from datetime import date
    current_fy = eIIGVisit.get_financial_year(date.today())

    from .dynamic_columns import prefetch_extra_col_values
    extra_cols = prefetch_extra_col_values('eiig', page_obj.object_list)

    context = {
        'page_obj': page_obj,
        'total_count': total_visits,
        'total_visitors': total_visitors,
        'search': search,
        'category_filter': category_filter,
        'state_filter': state_filter,
        'year_filter': year_filter,
        'date_from': date_from,
        'date_to': date_to,
        'category_choices': eIIGVisit.CATEGORY_CHOICES,
        'state_choices': eIIGVisit.INDIAN_STATES,
        'current_fy': current_fy,
        'extra_cols': extra_cols,
    }
    return render(request, 'daks/eiig_dashboard.html', context)


# ─────────────────────────────────────────────────────────────────────────────
# DETAIL
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def eiig_detail(request, public_id):
    visit = get_object_or_404(
        eIIGVisit.objects.prefetch_related('visitors').select_related('created_by'),
        public_id=public_id
    )
    from .dynamic_columns import get_extra_col_context
    return render(request, 'daks/eiig_detail.html', {
        'visit': visit,
        'extra_cols': get_extra_col_context('eiig', visit.pk),
    })


# ─────────────────────────────────────────────────────────────────────────────
# HELPER: Build graph context data for eIIG form
# ─────────────────────────────────────────────────────────────────────────────

def _eiig_graph_context():
    """Aggregated stats for eIIG tab graphs. All values default to 0."""
    from django.db.models import Count, Avg
    qs = eIIGVisit.objects.all()

    eiig_cat = {
        'industry':   qs.filter(company_category='INDUSTRY').count(),
        'govt':       qs.filter(company_category='GOVT').count(),
        'research':   qs.filter(company_category='RESEARCH').count(),
        'individual': qs.filter(company_category='INDIVIDUAL').count(),
    }

    total_visits   = qs.count()
    total_visitors = sum(v.visitors.count() for v in qs) if total_visits else 0
    avg_per_visit  = round(total_visitors / total_visits, 1) if total_visits else 0

    eiig_visitors = {
        'total_visits':   total_visits,
        'total_visitors': total_visitors,
        'avg_per_visit':  avg_per_visit,
    }

    return {
        'eiig_cat':      eiig_cat,
        'eiig_visitors': eiig_visitors,
    }


# ─────────────────────────────────────────────────────────────────────────────
# CREATE
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def eiig_create(request):
    if request.method == 'POST':
        form = eIIGVisitForm(request.POST)
        formset = VisitorFormSet(request.POST, prefix='visitors')
        if form.is_valid() and formset.is_valid():
            with transaction.atomic():
                visit = form.save(commit=False)
                visit.created_by = request.user
                visit.save()
                form.save_extra_fields(visit)
                formset.instance = visit
                formset.save()
            messages.success(request, f'Visit {visit.visit_id} recorded successfully!')
            return redirect('daks:eiig_detail', public_id=visit.public_id)
        else:
            # Surface formset errors in the messages so the user knows what failed
            for i, vform in enumerate(formset.forms):
                for field, errs in vform.errors.items():
                    for err in errs:
                        messages.error(request, f'Visitor {i+1} — {field}: {err}')
            for err in formset.non_form_errors():
                messages.error(request, f'Visitor list: {err}')
    else:
        form = eIIGVisitForm()
        formset = VisitorFormSet(prefix='visitors')

    from .dynamic_columns import get_extra_col_context
    ctx = {
        'form': form,
        'formset': formset,
        'title': 'Record New Visit',
        'extra_cols': get_extra_col_context('eiig', None),
    }
    ctx.update(_eiig_graph_context())
    return render(request, 'daks/eiig_form.html', ctx)


# ─────────────────────────────────────────────────────────────────────────────
# EDIT
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def eiig_edit(request, public_id):
    visit = get_object_or_404(eIIGVisit, public_id=public_id)
    if request.method == 'POST':
        form = eIIGVisitForm(request.POST, instance=visit)
        formset = VisitorFormSet(request.POST, instance=visit, prefix='visitors')
        if form.is_valid() and formset.is_valid():
            with transaction.atomic():
                visit = form.save()
                form.save_extra_fields(visit)
                formset.save()
            messages.success(request, f'Visit {visit.visit_id} updated successfully!')
            return redirect('daks:eiig_detail', public_id=visit.public_id)
        else:
            for i, vform in enumerate(formset.forms):
                for field, errs in vform.errors.items():
                    for err in errs:
                        messages.error(request, f'Visitor {i+1} — {field}: {err}')
            for err in formset.non_form_errors():
                messages.error(request, f'Visitor list: {err}')
    else:
        form = eIIGVisitForm(instance=visit)
        formset = VisitorFormSet(instance=visit, prefix='visitors')

    from .dynamic_columns import get_extra_col_context
    ctx = {
        'form': form,
        'formset': formset,
        'title': f'Edit Visit — {visit.visit_id}',
        'visit': visit,
        'extra_cols': get_extra_col_context('eiig', visit.pk),
    }
    ctx.update(_eiig_graph_context())
    return render(request, 'daks/eiig_form.html', ctx)


# ─────────────────────────────────────────────────────────────────────────────
# API: Sub-categories for a given category (AJAX)
# ─────────────────────────────────────────────────────────────────────────────

SUBCATEGORY_MAP = {
    'INDUSTRY':   ['PRIVATE', 'DPSU', 'PSU', 'MSME', 'STARTUP'],
    'GOVERNMENT': ['CENTRAL', 'STATE', 'DEFENCE', 'CAPF'],
    'RESEARCH':   ['UNIVERSITY', 'RESEARCH_INST', 'IIT_NIT', 'LAB'],
    'INDIVIDUAL': ['ENTREPRENEUR', 'STUDENT', 'RESEARCHER'],
    'OTHER':      ['OTHER'],
}

SUBCATEGORY_LABELS = dict(eIIGVisit.SUBCATEGORY_CHOICES)

@login_required
def eiig_api_subcategories(request):
    category = request.GET.get('category', '')
    subs = SUBCATEGORY_MAP.get(category, [])
    data = [{'value': v, 'label': SUBCATEGORY_LABELS.get(v, v)} for v in subs]
    return JsonResponse({'subcategories': data})


# ─────────────────────────────────────────────────────────────────────────────
# EXPORT
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def eiig_export_excel(request):
    qs = (
        eIIGVisit.objects.all()
        .prefetch_related('visitors')
        .order_by('-date_of_visit')
    )
    if request.GET.get('search'):
        q = request.GET['search'].strip()
        qs = qs.filter(
            Q(visit_id__icontains=q) |
            Q(firm_name__icontains=q) |
            Q(visitors__name__icontains=q)
        ).distinct()
    if request.GET.get('category'):
        qs = qs.filter(company_category=request.GET['category'])
    if request.GET.get('state'):
        qs = qs.filter(firm_state=request.GET['state'])

    from .report_columns import get_default_columns
    from .reports import generate_module_excel_report
    columns = get_default_columns('eiig')
    return generate_module_excel_report(qs, columns, 'iig_visits')


@login_required
def eiig_slideshow(request):
    """IIG photo slideshow page — photos stored client-side via localStorage."""
    return render(request, 'daks/eiig_slideshow.html', {'title': 'IIG Visit Gallery'})


# ─────────────────────────────────────────────────────────────────────────────
# ADMIN-ONLY HARD DELETE
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def eiig_delete(request, public_id):
    """Superuser-only: permanently delete an eIIG visit record."""
    if not request.user.is_superuser:
        messages.error(request, 'Only superusers can delete eIIG records.')
        return redirect('daks:eiig_detail', public_id=public_id)

    visit = get_object_or_404(eIIGVisit, public_id=public_id)

    if request.method == 'POST':
        identifier = visit.visit_id
        visit.delete()
        messages.success(request, f'eIIG visit "{identifier}" permanently deleted.')
        return redirect('daks:eiig_dashboard')

    return render(request, 'daks/eiig_confirm_delete.html', {'visit': visit})



