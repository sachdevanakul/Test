from django.apps import AppConfig

class DaksConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'daks'
    
    def ready(self):
        import daks.signals  # Register signals
        
        # Seed default lookup master tables if empty
        try:
            from django.db import connection
            tables = connection.introspection.table_names()
            
            if 'party_role_master' in tables:
                from daks.models import PartyRoleMaster
                for code, name in [('SENDER', 'Sender'), ('MARKED_TO', 'Marked To'), ('RECEIVER', 'Receiver')]:
                    PartyRoleMaster.objects.get_or_create(role_code=code, defaults={'role_name': name})
                    
            if 'dispatch_mode_master' in tables:
                from daks.models import DispatchModeMaster
                for code, name in [
                    ('POST', 'Post'), ('HAND', 'By Hand'), ('EMAIL', 'Email'), 
                    ('FAX', 'Fax'), ('SPEED_POST', 'Speed Post')
                ]:
                    DispatchModeMaster.objects.get_or_create(mode_code=code, defaults={'mode_name': name})
                    
            if 'organization_type_master' in tables:
                from daks.models import OrganizationTypeMaster
                for name, desc in [
                    ('COMPANY', 'External Company/Organisation'),
                    ('GOVT', 'Government Body/Department'),
                    ('UNSPECIFIED', 'Unspecified')
                ]:
                    OrganizationTypeMaster.objects.get_or_create(type_name=name, defaults={'description': desc})
        except Exception:
            pass