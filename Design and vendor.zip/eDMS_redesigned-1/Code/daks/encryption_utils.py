"""
File Encryption Utilities
Encrypts and decrypts file attachments
"""

import os
import hashlib
from cryptography.fernet import Fernet
from django.conf import settings

# Key file location
KEY_FILE = os.path.join(settings.BASE_DIR, 'security', 'encryption.key')

def get_or_create_key():
    """Get existing encryption key or create a new one"""
    os.makedirs(os.path.dirname(KEY_FILE), exist_ok=True)
    
    if os.path.exists(KEY_FILE):
        with open(KEY_FILE, 'rb') as key_file:
            return key_file.read()
    else:
        key = Fernet.generate_key()
        with open(KEY_FILE, 'wb') as key_file:
            key_file.write(key)
        # Set file to read-only for security
        os.chmod(KEY_FILE, 0o400)
        return key

def encrypt_file(file_path):
    """Encrypt a file at the given path"""
    try:
        key = get_or_create_key()
        cipher = Fernet(key)
        
        with open(file_path, 'rb') as f:
            original_data = f.read()
        
        encrypted_data = cipher.encrypt(original_data)
        
        with open(file_path, 'wb') as f:
            f.write(encrypted_data)
        
        return True
    except Exception as e:
        print(f"Encryption error: {e}")
        return False

def decrypt_file(file_path):
    """Decrypt a file at the given path"""
    try:
        key = get_or_create_key()
        cipher = Fernet(key)
        
        with open(file_path, 'rb') as f:
            encrypted_data = f.read()
        
        decrypted_data = cipher.decrypt(encrypted_data)
        
        return decrypted_data
    except Exception as e:
        print(f"Decryption error: {e}")
        return None

def get_file_checksum(file_path):
    """Generate SHA-256 checksum of a file"""
    sha256 = hashlib.sha256()
    with open(file_path, 'rb') as f:
        for chunk in iter(lambda: f.read(4096), b''):
            sha256.update(chunk)
    return sha256.hexdigest()