from django import template

register = template.Library()

@register.filter
def split(value, arg):
    return value.split(arg)


@register.filter
def index(indexable, i):
    try:
        return indexable[i]
    except (IndexError, TypeError, KeyError):
        return ''