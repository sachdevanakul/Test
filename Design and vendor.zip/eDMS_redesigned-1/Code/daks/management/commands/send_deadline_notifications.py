"""
python manage.py send_deadline_notifications
Schedule daily via Windows Task Scheduler or cron.
Covers: WorkTask deadlines + Dak reply_due_date reminders
Logic: <5 days → daily | >=5 days → alternate days
"""
from django.core.management.base import BaseCommand
from django.utils import timezone
from django.core.mail import send_mail
from django.conf import settings
import logging
logger = logging.getLogger(__name__)

class Command(BaseCommand):
    help = 'Send deadline notifications for tasks and dak reply due dates'
    def add_arguments(self, parser):
        parser.add_argument('--dry-run', action='store_true')
        parser.add_argument('--tasks-only', action='store_true')
        parser.add_argument('--daks-only', action='store_true')
    def handle(self, *args, **options):
        dry = options['dry_run']
        today = timezone.now().date()
        ts = tk = 0
        if not options['daks_only']:
            s,k = self._tasks(today, dry); ts+=s; tk+=k
        if not options['tasks_only']:
            s,k = self._daks(today, dry); ts+=s; tk+=k
        self.stdout.write(self.style.SUCCESS(f'\nDone. Sent:{ts} Skipped:{tk}'))
    def _should(self, days, pk, today):
        if days < 5: return True
        return (pk % 2 == today.day % 2)
    def _label(self, days, title):
        if days < 0: return f'OVERDUE {abs(days)}d', f'[OVERDUE] {title[:60]}'
        if days == 0: return 'DUE TODAY', f'[DUE TODAY] {title[:60]}'
        return f'Due in {days}d', f'[REMINDER] {title[:60]}'
    def _send(self, email, subj, body, dry, desc):
        if dry: self.stdout.write(self.style.SUCCESS(f'  DRY→{email}|{desc}')); return True
        try:
            send_mail(subj, body, getattr(settings,'DEFAULT_FROM_EMAIL','noreply@edms.local'), [email], fail_silently=False)
            self.stdout.write(self.style.SUCCESS(f'  SENT→{email}|{desc}')); return True
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'  FAIL→{email}|{e}')); return False
    def _tasks(self, today, dry):
        from daks.models import WorkTask
        s=k=0
        for t in WorkTask.objects.filter(status__in=['PENDING','IN_PROGRESS'],deadline__isnull=False).select_related('assigned_to','assigned_by'):
            dl=(t.deadline-today).days
            if dl<-30: k+=1; continue
            if not self._should(dl, t.pk, today): k+=1; continue
            u=t.assigned_to
            if not u.email: k+=1; continue
            lbl,subj=self._label(dl,t.title)
            body=f'Task: {t.title}\nPriority: {t.get_priority_display()}\nDeadline: {t.deadline} ({lbl})\n\nPlease update status in eDMS.\n\n-- eDMS'
            ok=self._send(u.email,subj,f'Dear {u.username},\n\n'+body,dry,f'Task:{t.title[:40]}')
            if ok: s+=1
            else: k+=1
        return s,k
    def _daks(self, today, dry):
        from daks.models import DakMaster
        from django.contrib.auth.models import User as AuthUser
        s=k=0
        staff=[x for x in AuthUser.objects.filter(is_staff=True,is_active=True).exclude(email='').values_list('email','username')]
        for d in DakMaster.objects.filter(dak_direction='INCOMING',is_active=True,reply_due_date__isnull=False):
            dl=(d.reply_due_date-today).days
            if dl<-30: k+=1; continue
            if not self._should(dl, d.pk, today): k+=1; continue
            lbl,subj=self._label(dl,f'[DAK] {d.dak_index_no}')
            body=f'Dak: {d.dak_index_no}\nSubject: {d.subject[:100]}\nDue: {d.reply_due_date} ({lbl})\n\nPlease process in eDMS.\n\n-- eDMS'
            for email,uname in staff:
                ok=self._send(email,subj,f'Dear {uname},\n\n'+body,dry,f'Dak:{d.dak_index_no}')
                if ok: s+=1
                else: k+=1
        return s,k
