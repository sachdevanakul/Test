"""
Warm up cache
Usage: python manage.py warm_cache
"""

from django.core.management.base import BaseCommand
from django.core.cache import cache
from daks.views import get_cached_dropdowns

class Command(BaseCommand):
    help = 'Warm up cache with initial data'

    def handle(self, *args, **options):
        self.stdout.write("Warming up cache...")
        
        # Load dropdown data
        get_cached_dropdowns()
        
        self.stdout.write(self.style.SUCCESS('✅ Cache warmed successfully'))