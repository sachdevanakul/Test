"""
Clear all caches
Usage: python manage.py clear_cache
"""

from django.core.management.base import BaseCommand
from django.core.cache import cache

class Command(BaseCommand):
    help = 'Clear all caches'

    def handle(self, *args, **options):
        cache.clear()
        self.stdout.write(self.style.SUCCESS('✅ All caches cleared'))