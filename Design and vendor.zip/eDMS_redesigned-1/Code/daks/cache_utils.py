"""
Cache Utility Functions
Handles all caching operations for eDMS
"""

from django.core.cache import cache
from django.core.cache import caches
from .models import *

# Cache keys
DASHBOARD_CACHE_KEY = 'dashboard_stats'
DROPDOWN_CACHE_KEY = 'dropdown_data'
RECENT_DAKS_CACHE_KEY = 'recent_daks'
MAX_ATTACHMENT_SIZE_CACHE_KEY = 'max_attachment_size_mb'
DEFAULT_MAX_ATTACHMENT_SIZE_MB = 25

def get_max_attachment_size_mb():
    """Admin-configurable max attachment size (MB), backed by the
    SystemConfig row with config_key='MAX_ATTACHMENT_SIZE_MB'.

    Cached for 15 minutes (#13) rather than re-querying the DB on every
    upload. Two things keep that 15-minute window from ever showing a
    stale value where it'd actually matter:
      - Saving a new value in the admin UI clears this cache immediately
        (see signals.py), so a change takes effect right away.
      - Every login also clears it (#13's "update when a user logs in"),
        so a freshly started session always re-reads the current value
        rather than possibly inheriting a number cached up to 15 minutes
        ago by someone else's session.
    """
    size = cache.get(MAX_ATTACHMENT_SIZE_CACHE_KEY)
    if size is None:
        try:
            config = SystemConfig.objects.get(config_key='MAX_ATTACHMENT_SIZE_MB', is_active=True)
            size = int(config.config_value)
        except (SystemConfig.DoesNotExist, ValueError, TypeError):
            size = DEFAULT_MAX_ATTACHMENT_SIZE_MB
        cache.set(MAX_ATTACHMENT_SIZE_CACHE_KEY, size, 900)  # 15 minutes
    return size

def clear_max_attachment_size_cache():
    """Clear the cached max-attachment-size value (called on save and on login)."""
    cache.delete(MAX_ATTACHMENT_SIZE_CACHE_KEY)
    print("[CACHE] Max attachment size cache cleared")

def get_dashboard_stats():
    """Get dashboard statistics from cache or database"""
    data = cache.get(DASHBOARD_CACHE_KEY)
    
    if data is None:
        print("[CACHE] Dashboard stats - CACHE MISS, loading from database")
        data = {
            'total_daks': DakMaster.objects.filter(is_active=True).count(),
            'incoming_count': DakMaster.objects.filter(dak_direction='INCOMING', is_active=True).count(),
            'outgoing_count': DakMaster.objects.filter(dak_direction='OUTGOING', is_active=True).count(),
            'open_threads': DakThread.objects.filter(status='OPEN').count(),
        }
        cache.set(DASHBOARD_CACHE_KEY, data, 900)   # 15 minutes
        print("[CACHE] Dashboard stats - STORED in cache")
    else:
        print("[CACHE] Dashboard stats - CACHE HIT")
    
    return data

def get_cached_dropdowns():
    """Get dropdown data from cache or database"""
    data = cache.get(DROPDOWN_CACHE_KEY)
    
    if data is None:
        print("[CACHE] Dropdowns - CACHE MISS, loading from database")
        try:
            data = {
                'categories': list(DakCategoryMaster.objects.filter(is_active=True).values('id', 'category_code', 'category_name')),
                'natures': list(DakNatureMaster.objects.filter(is_active=True).values('id', 'nature_name')),
                'groups': list(GroupMaster.objects.filter(is_active=True).values('id', 'group_code', 'group_name')),
                'organizations': list(OrganizationMaster.objects.filter(is_active=True).values('id', 'org_name')),
                'persons': list(PersonMaster.objects.filter(is_active=True).values('id', 'person_name')),
            }
            cache.set(DROPDOWN_CACHE_KEY, data, 10800)  # 3 hours
            print("[CACHE] Dropdowns - STORED in cache")
        except Exception as e:
            print(f"[CACHE] Dropdowns error: {e}")
            data = {}
    else:
        print("[CACHE] Dropdowns - CACHE HIT")
    
    return data

def get_recent_daks(limit=5):
    """Get recent daks from cache or database"""
    cache_key = f'{RECENT_DAKS_CACHE_KEY}_{limit}'
    data = cache.get(cache_key)
    
    if data is None:
        print("[CACHE] Recent daks - CACHE MISS, loading from database")
        data = list(DakMaster.objects.filter(is_active=True).order_by('-created_on')[:limit])
        cache.set(cache_key, data, 300)   # 5 minutes
        print("[CACHE] Recent daks - STORED in cache")
    else:
        print("[CACHE] Recent daks - CACHE HIT")
    
    return data

def clear_dashboard_cache():
    """Clear dashboard cache"""
    cache.delete(DASHBOARD_CACHE_KEY)
    print("[CACHE] Dashboard stats cache cleared")

def clear_dropdown_cache():
    """Clear dropdown cache"""
    cache.delete(DROPDOWN_CACHE_KEY)
    print("[CACHE] Dropdowns cache cleared")

def clear_recent_daks_cache():
    """Clear recent daks cache"""
    cache.delete(RECENT_DAKS_CACHE_KEY)
    print("[CACHE] Recent daks cache cleared")

def clear_all_caches():
    """Clear all application caches"""
    cache.clear()
    print("[CACHE] ALL caches cleared")