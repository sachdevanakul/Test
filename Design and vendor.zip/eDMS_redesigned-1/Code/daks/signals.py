"""
Django Signals - Automatic cache clearing when data changes
              - Auto-create UserProfile on new User creation
"""

from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver
from django.contrib.auth.models import User
from django.contrib.auth.signals import user_logged_in
from .models import *
from .cache_utils import clear_dashboard_cache, clear_dropdown_cache, clear_recent_daks_cache, clear_max_attachment_size_cache
from django.core.cache import cache


# ── Auto-create / update UserProfile whenever a User is saved ──
@receiver(post_save, sender=User)
def create_or_update_user_profile(sender, instance, created, **kwargs):
    """
    Automatically creates a UserProfile for every new User.
    For existing users, saves the profile if it already exists
    (keeps auto_now fields updated).
    """
    if created:
        UserProfile.objects.get_or_create(user=instance)
    else:
        # Save existing profile so updated_at stays current
        try:
            instance.profile.save()
        except UserProfile.DoesNotExist:
            UserProfile.objects.create(user=instance)
# Clear cache when DakMaster changes (create, update, delete)
@receiver(post_save, sender=DakMaster)
@receiver(post_delete, sender=DakMaster)
def clear_cache_on_dak_change(sender, **kwargs):
    """Clear all caches when any dak is created, updated, or deleted"""
    print("[SIGNAL] DakMaster changed - Clearing all caches")
    clear_dashboard_cache()
    clear_recent_daks_cache()

# Clear dropdown cache when master data changes
@receiver(post_save, sender=DakCategoryMaster)
@receiver(post_delete, sender=DakCategoryMaster)
@receiver(post_save, sender=DakNatureMaster)
@receiver(post_delete, sender=DakNatureMaster)
@receiver(post_save, sender=GroupMaster)
@receiver(post_delete, sender=GroupMaster)
@receiver(post_save, sender=OrganizationMaster)
@receiver(post_delete, sender=OrganizationMaster)
@receiver(post_save, sender=PersonMaster)
@receiver(post_delete, sender=PersonMaster)
def clear_dropdown_cache_on_master_change(sender, **kwargs):
    """Clear dropdown cache when master data changes"""
    print(f"[SIGNAL] {sender.__name__} changed - Clearing dropdown cache")
    clear_dropdown_cache()


@receiver(post_save, sender=SystemConfig)
def clear_max_attachment_cache_on_config_change(sender, instance, **kwargs):
    """Admin just changed a system setting from the frontend — if it was
    the max attachment size, make it take effect immediately instead of
    waiting up to 15 minutes for the cache to expire on its own."""
    if instance.config_key == 'MAX_ATTACHMENT_SIZE_MB':
        print("[SIGNAL] MAX_ATTACHMENT_SIZE_MB changed - clearing cache")
        clear_max_attachment_size_cache()


@receiver(user_logged_in)
def refresh_max_attachment_cache_on_login(sender, request, user, **kwargs):
    """Every login gets a fresh read of the current limit rather than
    possibly inheriting a value cached by someone else's session up to
    15 minutes ago."""
    clear_max_attachment_size_cache()