from .models import UserProfile


def user_profile(request):
    """
    Injects `user_profile` into every template context so base.html
    can gate sidebar items and enforce screenshot restrictions without
    each view having to pass it manually.
    """
    profile = None
    if request.user.is_authenticated:
        try:
            profile = request.user.profile
        except UserProfile.DoesNotExist:
            # Auto-create missing profile (e.g. superuser created via createsuperuser)
            profile = UserProfile.objects.create(user=request.user)
    return {'user_profile': profile}
