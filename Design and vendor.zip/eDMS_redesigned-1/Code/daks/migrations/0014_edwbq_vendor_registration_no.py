from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('daks', '0013_edw_ifa_no_alter_edw_acn_no'),
    ]

    operations = [
        migrations.AddField(
            model_name='edwbq',
            name='vendor_registration_no',
            field=models.CharField(
                blank=True,
                max_length=100,
                null=True,
                verbose_name='Vendor Registration No.',
            ),
        ),
    ]
