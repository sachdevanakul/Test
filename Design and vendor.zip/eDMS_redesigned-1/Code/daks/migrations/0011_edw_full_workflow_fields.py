from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('daks', '0010_dakmaster_testing_group'),
    ]

    operations = [
        # IFA
        migrations.AddField('eDW', 'ifa_mail_date', models.DateField(blank=True, null=True, verbose_name='IFA Mail Date')),
        # NTR
        migrations.AddField('eDW', 'ntr_mail_received_on', models.DateField(blank=True, null=True, verbose_name='NTR Mail Received On')),
        migrations.AddField('eDW', 'funding_agency', models.CharField(max_length=200, blank=True, null=True, verbose_name='Funding Agency')),
        migrations.AddField('eDW', 'dw_activity', models.CharField(max_length=20, blank=True, null=True, choices=[('TEST','Test'),('TRIAL','Trial'),('FABRICATION','Fabrication')], verbose_name='DW Activity')),
        migrations.AddField('eDW', 'category_head', models.CharField(max_length=100, blank=True, null=True, verbose_name='Category Head')),
        # NFA
        migrations.AddField('eDW', 'nfa_number', models.CharField(max_length=50, blank=True, null=True, verbose_name='NFA Number')),
        migrations.AddField('eDW', 'nfa_date', models.DateField(blank=True, null=True, verbose_name='NFA Date')),
        migrations.AddField('eDW', 'nfa_reason', models.TextField(blank=True, null=True, verbose_name='NFA Reason')),
        # BQ
        migrations.AddField('eDW', 'bq_received_from_group_on', models.DateField(blank=True, null=True, verbose_name='BQ Received from Testing Group On')),
        migrations.AddField('eDW', 'trial_type', models.CharField(max_length=100, blank=True, null=True, verbose_name='Type of Trial')),
        migrations.AddField('eDW', 'no_of_samples', models.IntegerField(blank=True, null=True, verbose_name='No. of Samples')),
        migrations.AddField('eDW', 'bq_amount_per_trial', models.DecimalField(max_digits=15, decimal_places=2, blank=True, null=True, verbose_name='Amount per Trial / Total')),
        # eMRO
        migrations.AddField('eDW', 'emro_payment_mode', models.CharField(max_length=20, blank=True, null=True, choices=[('EMRO','eMRO'),('DIRECTOR_ACCOUNT','Director Account')], verbose_name='Payment Done By')),
        migrations.AddField('eDW', 'emro_received_on', models.DateField(blank=True, null=True, verbose_name='eMRO Received On')),
        migrations.AddField('eDW', 'gst_commitment', models.BooleanField(default=False, verbose_name='GST Commitment')),
        migrations.AddField('eDW', 'gst_cin_no', models.CharField(max_length=100, blank=True, null=True, verbose_name='GST CIN No.')),
        migrations.AddField('eDW', 'gst_cin_date', models.DateField(blank=True, null=True, verbose_name='GST CIN Date')),
        migrations.AddField('eDW', 'gst_cin_amount', models.DecimalField(max_digits=15, decimal_places=2, blank=True, null=True, verbose_name='GST CIN Amount')),
        migrations.AddField('eDW', 'acn_request_send_to_group_on', models.DateField(blank=True, null=True, verbose_name='ACN Request Send to Group On')),
        # ACN
        migrations.AddField('eDW', 'job_no_date', models.DateField(blank=True, null=True, verbose_name='Job No. Date')),
        migrations.AddField('eDW', 'rdr_no', models.CharField(max_length=100, blank=True, null=True, verbose_name='RDR No.')),
        migrations.AddField('eDW', 'acn_amount', models.DecimalField(max_digits=15, decimal_places=2, blank=True, null=True, verbose_name='ACN Amount')),
        migrations.AddField('eDW', 'trial_tentative_date_acn', models.DateField(blank=True, null=True, verbose_name='Trial Tentative Date (ACN Stage)')),
        migrations.AddField('eDW', 'sanction_no', models.CharField(max_length=100, blank=True, null=True, verbose_name='Sanction No.')),
        migrations.AddField('eDW', 'sanction_date', models.DateField(blank=True, null=True, verbose_name='Sanction Date')),
        migrations.AddField('eDW', 'acn_letter_no', models.CharField(max_length=100, blank=True, null=True, verbose_name='ACN Letter No.')),
        migrations.AddField('eDW', 'acn_letter_date', models.DateField(blank=True, null=True, verbose_name='ACN Letter Date')),
        migrations.AddField('eDW', 'acn_allotted_on', models.DateField(blank=True, null=True, verbose_name='ACN Allotted On')),
        migrations.AddField('eDW', 'acn_forwarded_to_group_on', models.DateField(blank=True, null=True, verbose_name='ACN Forwarded to Testing Group On')),
        # TE
        migrations.AddField('eDW', 'te_amount', models.DecimalField(max_digits=15, decimal_places=2, blank=True, null=True, verbose_name='TE Amount')),
        migrations.AddField('eDW', 'rdr_code_head', models.CharField(max_length=100, blank=True, null=True, verbose_name='RDR Code Head')),
        migrations.AddField('eDW', 'te_letter_no', models.CharField(max_length=100, blank=True, null=True, verbose_name='TE Letter No.')),
        migrations.AddField('eDW', 'te_letter_date', models.DateField(blank=True, null=True, verbose_name='TE Letter Date')),
        migrations.AddField('eDW', 'te_sent_to_ao_on', models.DateField(blank=True, null=True, verbose_name='Sent to AO (R&D) On')),
        migrations.AddField('eDW', 'te_no', models.CharField(max_length=100, blank=True, null=True, verbose_name='TE No.')),
        migrations.AddField('eDW', 'te_received_on', models.DateField(blank=True, null=True, verbose_name='TE No. Received On')),
        migrations.AddField('eDW', 'te_initiated_to_group_on', models.DateField(blank=True, null=True, verbose_name='Initiated to Group via Mail On')),
        # Trial Details
        migrations.AddField('eDW', 'trial_conducted', models.CharField(max_length=15, blank=True, null=True, choices=[('YES','Yes'),('NO','No'),('PROCESSING','Processing')], verbose_name='Trial Conducted')),
        migrations.AddField('eDW', 'actual_trial_date', models.DateField(blank=True, null=True, verbose_name='Trial Conducted On (Actual)')),
        migrations.AddField('eDW', 'trial_report_received_on', models.DateField(blank=True, null=True, verbose_name='Trial Report Received On')),
        migrations.AddField('eDW', 'jcc_submitted_on', models.DateField(blank=True, null=True, verbose_name='JCC Submitted On')),
        migrations.AddField('eDW', 'fa_gst_submitted_on', models.DateField(blank=True, null=True, verbose_name='FA Submitted GST On')),
        migrations.AddField('eDW', 'report_no_request_sent_on', models.DateField(blank=True, null=True, verbose_name='Report No. Request Sent On')),
        # Report Dispatch
        migrations.AddField('eDW', 'report_letter_no', models.CharField(max_length=100, blank=True, null=True, verbose_name='Report Letter No.')),
        migrations.AddField('eDW', 'report_dispatched_on', models.DateField(blank=True, null=True, verbose_name='Report Dispatched On')),
        migrations.AddField('eDW', 'ion_issued_on', models.DateField(blank=True, null=True, verbose_name='ION Issued On')),
        migrations.AddField('eDW', 'report_mail_to_company_on', models.DateField(blank=True, null=True, verbose_name='Mail Sent to Company On')),
        migrations.AddField('eDW', 'report_to_tirc_on', models.DateField(blank=True, null=True, verbose_name='Report to TIRC On')),
        migrations.AddField('eDW', 'report_to_group_on', models.DateField(blank=True, null=True, verbose_name='Report to Group On')),
    ]
