# Official Report Template + 7 Test Cases

8 files: `daks/reports.py`, `daks/report_views.py`, `daks/report_columns.py`,
`daks/migrations/0004_create_readonly_views.py`, `static/img/drdo_tbrl_logo.png`,
`static/img/i2g_box.png`, `daks/test_system_checks.py`, `edms/test_settings.py`.

## Part 1 — Official DRDO/TBRL report template

Every PDF report in the system (Dak daily/monthly/range/category/pending
reports, and the eDW/eToT/eIIG module reports) now uses the exact
official format from your reference image: double blue border, RESTRICTED
markings top and bottom, the DRDO/TBRL crest, the I2G box, the centered
title block, a "Report / Period" line, and a footer with copyright, page
count, and a generation timestamp.

**The two logos are real images, not redrawn** — I cropped them directly
out of the reference image you sent and saved them as `static/img/
drdo_tbrl_logo.png` and `static/img/i2g_box.png`. They need to land at
those exact paths for the reports to find them.

Two real problems turned up while building this, both fixed before
sending:
- With a module that has many columns (eDW has 12), the table text was
  overflowing between columns — headers and values weren't wrapping.
  Switched every cell to a proper wrapping paragraph instead of a plain
  string; long labels now wrap onto a second line within their own cell.
- Date/time values were printing with raw microseconds and timezone
  offsets (`2026-06-24 06:36:54.280971+00:00`). Now formatted cleanly
  (`24-Jun-2026 06:36`).

I generated real PDFs with real data and visually compared them against
your reference image side by side before sending this — not just
checking that the code runs.

## Part 2 — 7 test cases

Covers nav permissions, attachment security, non-guessable URLs, the eDW
import fix, report date-basis correctness, the new eDW/eToT/eIIG quick
reports, and thread separation. Run with:

```
DJANGO_SETTINGS_MODULE=edms.test_settings python manage.py test daks.test_system_checks -v 2
```

Runs against a throwaway in-memory database — never touches your real
data, no special database permissions needed.

**Why migration `0004` is included again here**: it had to be made
backend-aware (skips its Postgres-only SQL when running under SQLite) for
`manage.py test` to work at all — otherwise building the test database
fails on this migration before any test even runs. Re-verified this still
creates all 7 views correctly on real Postgres, unchanged from before.

All 7 tests pass against the current code, including the new report
template changes from Part 1.
