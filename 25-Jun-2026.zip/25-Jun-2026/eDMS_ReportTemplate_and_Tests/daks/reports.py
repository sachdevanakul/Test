"""
Reporting Module for eDMS
Generates PDF, Excel, and CSV reports
"""

import pandas as pd
from io import BytesIO
from datetime import datetime, timedelta
from django.http import HttpResponse
from django.db.models import Count, Q
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, landscape
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.pdfgen import canvas as _canvas
import os
from django.conf import settings as _dj_settings
from .models import *

# ── Official DRDO / TBRL report template ────────────────────────────
# Matches the approved I2G-DCMM report format exactly: double border
# frame, RESTRICTED markings, DRDO/TBRL crest, I2G box, centered title
# block, a "Report / Period" line, and a footer with copyright, page
# count, and a generation timestamp. Used by every PDF report in the
# system (Dak reports and the eDW/eToT/eIIG module reports) via the two
# functions below, so every report in eDMS looks the same.

REPORT_BORDER_BLUE = colors.Color(0x0B / 255, 0x1F / 255, 0x73 / 255)
REPORT_RED = colors.Color(0xE1 / 255, 0x12 / 255, 0x12 / 255)
REPORT_HEADER_GRAY = colors.Color(0xEC / 255, 0xEC / 255, 0xEC / 255)

_DRDO_LOGO_PATH = os.path.join(_dj_settings.BASE_DIR, 'static', 'img', 'drdo_tbrl_logo.png')
_I2G_BOX_PATH = os.path.join(_dj_settings.BASE_DIR, 'static', 'img', 'i2g_box.png')


class NumberedCanvas(_canvas.Canvas):
    """Standard ReportLab two-pass pattern for 'Page X of Y' — the total
    page count isn't known until the whole document has been laid out,
    so each page's content is buffered and only actually drawn once
    save() is called and the final count is known."""

    def __init__(self, *args, **kwargs):
        _canvas.Canvas.__init__(self, *args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        total_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self._draw_page_count(total_pages)
            _canvas.Canvas.showPage(self)
        _canvas.Canvas.save(self)

    def _draw_page_count(self, total_pages):
        page_w, page_h = self._pagesize
        self.setFont('Helvetica', 9)
        self.setFillColor(colors.black)
        self.drawCentredString(page_w / 2, 0.27 * inch, f"Page {self._pageNumber} of {total_pages}")


def draw_official_report_frame(canvas_obj, doc, report_name, start_date=None, end_date=None):
    """Draws the official report frame on the current page: border,
    RESTRICTED markings, crest, title block, Report/Period line, and
    footer. Called for every page via onFirstPage/onLaterPages."""
    canvas_obj.saveState()
    page_w, page_h = doc.pagesize

    # ── Double border frame ──────────────────────────────────────────
    canvas_obj.setStrokeColor(REPORT_BORDER_BLUE)
    canvas_obj.setLineWidth(2.2)
    canvas_obj.rect(0.10 * inch, 0.10 * inch, page_w - 0.20 * inch, page_h - 0.20 * inch)
    canvas_obj.setLineWidth(0.75)
    canvas_obj.rect(0.22 * inch, 0.22 * inch, page_w - 0.44 * inch, page_h - 0.44 * inch)

    # ── RESTRICTED (top) ─────────────────────────────────────────────
    canvas_obj.setFont('Helvetica-Bold', 13)
    canvas_obj.setFillColor(REPORT_RED)
    canvas_obj.drawCentredString(page_w / 2, page_h - 0.42 * inch, 'RESTRICTED')

    # ── Crest (left) and I2G box (right) ─────────────────────────────
    logo_size = 0.78 * inch
    try:
        canvas_obj.drawImage(_DRDO_LOGO_PATH, 0.35 * inch, page_h - 1.30 * inch,
                              width=logo_size, height=logo_size, mask='auto')
    except Exception:
        pass
    try:
        canvas_obj.drawImage(_I2G_BOX_PATH, page_w - 1.55 * inch, page_h - 1.05 * inch,
                              width=1.15 * inch, height=0.58 * inch, mask='auto')
    except Exception:
        pass

    # ── Title block (center) ──────────────────────────────────────────
    canvas_obj.setFillColor(colors.black)
    canvas_obj.setFont('Times-Bold', 15)
    canvas_obj.drawCentredString(page_w / 2, page_h - 0.62 * inch, 'TERMINAL BALLISTICS RESEARCH LABORATORY')
    canvas_obj.setFont('Times-Roman', 10.5)
    canvas_obj.drawCentredString(page_w / 2, page_h - 0.80 * inch, 'Sector-30, Chandigarh - 160030')
    canvas_obj.setFont('Times-Bold', 10.5)
    canvas_obj.drawCentredString(page_w / 2, page_h - 0.98 * inch, 'Dte of Control Materials & Management (DCMM)')
    canvas_obj.drawCentredString(page_w / 2, page_h - 1.15 * inch, 'Industry Interface Group (I2G)')

    # ── Divider under header ──────────────────────────────────────────
    canvas_obj.setStrokeColor(REPORT_BORDER_BLUE)
    canvas_obj.setLineWidth(1.2)
    canvas_obj.line(0.35 * inch, page_h - 1.42 * inch, page_w - 0.35 * inch, page_h - 1.42 * inch)

    # ── Report / Period line ──────────────────────────────────────────
    canvas_obj.setFillColor(colors.black)
    canvas_obj.setFont('Times-Bold', 10)
    canvas_obj.drawString(0.40 * inch, page_h - 1.62 * inch, 'Report :')
    canvas_obj.setFont('Times-Bold', 10)
    canvas_obj.setFillColor(REPORT_BORDER_BLUE)
    canvas_obj.drawString(0.95 * inch, page_h - 1.62 * inch, report_name)

    if start_date and end_date:
        canvas_obj.setFillColor(colors.black)
        canvas_obj.setFont('Times-Bold', 10)
        period_label_x = page_w - 3.55 * inch
        canvas_obj.drawString(period_label_x, page_h - 1.62 * inch, 'Period :')
        canvas_obj.setFillColor(REPORT_BORDER_BLUE)
        canvas_obj.drawString(period_label_x + 0.58 * inch, page_h - 1.62 * inch,
                               start_date.strftime('%d-%b-%Y'))
        canvas_obj.setFillColor(colors.black)
        canvas_obj.drawString(period_label_x + 1.55 * inch, page_h - 1.62 * inch, 'to')
        canvas_obj.setFillColor(REPORT_BORDER_BLUE)
        canvas_obj.drawString(period_label_x + 1.80 * inch, page_h - 1.62 * inch,
                               end_date.strftime('%d-%b-%Y'))

    # ── Footer ─────────────────────────────────────────────────────────
    canvas_obj.setStrokeColor(REPORT_BORDER_BLUE)
    canvas_obj.setLineWidth(1)
    canvas_obj.line(0.35 * inch, 0.55 * inch, page_w - 0.35 * inch, 0.55 * inch)

    canvas_obj.setFont('Times-Roman', 9)
    canvas_obj.setFillColor(colors.black)
    canvas_obj.drawString(0.40 * inch, 0.35 * inch, 'Copyright :  I2G-DCMM')
    canvas_obj.drawRightString(page_w - 0.40 * inch, 0.35 * inch,
                                f"Generated on :  {datetime.now().strftime('%d-%b-%Y %H:%M')}")

    canvas_obj.setFont('Helvetica-Bold', 10)
    canvas_obj.setFillColor(REPORT_RED)
    canvas_obj.drawCentredString(page_w / 2, 0.43 * inch, 'RESTRICTED')
    # Page X of Y is drawn separately by NumberedCanvas, just under this line.

    canvas_obj.restoreState()

def get_date_range(report_type):
    """Get date range based on report type"""
    today = datetime.now().date()
    
    if report_type == 'daily':
        return today, today
    elif report_type == 'weekly':
        start = today - timedelta(days=7)
        return start, today
    elif report_type == 'monthly':
        start = today.replace(day=1)
        return start, today
    elif report_type == 'yearly':
        start = today.replace(month=1, day=1)
        return start, today
    else:
        return None, None

def get_report_data(start_date, end_date, category=None, nature=None):
    """Fetch data for reports.

    Date basis (this is the fix for the reporting date-basis issue):
    - INCOMING daks are filtered by receipt_date — the day TBRL actually
      received the dak, not the day someone happened to type it into the
      system (which could be days later for a backlog entry).
    - OUTGOING daks are filtered by dispatch_date (from DakDispatchDetails)
      — the day it was actually sent, not the day the record was created.
      An outgoing dak with no dispatch recorded yet hasn't been "sent" in
      any meaningful sense, so it correctly won't appear in a date-ranged
      report until dispatch is logged.
    """
    daks = DakMaster.objects.filter(
        is_active=True
    ).filter(
        Q(dak_direction='INCOMING', receipt_date__gte=start_date, receipt_date__lte=end_date) |
        Q(dak_direction='OUTGOING', dispatch_details__dispatch_date__gte=start_date,
          dispatch_details__dispatch_date__lte=end_date)
    ).select_related('dak_category', 'nature', 'thread', 'created_by', 'dispatch_details')

    if category:
        daks = daks.filter(dak_category__category_code=category)

    if nature:
        daks = daks.filter(nature__nature_name=nature)

    return daks


def report_basis_date(dak):
    """The one date a report should show/sort by for this dak — receipt
    date if incoming, dispatch date if outgoing. Used by the export
    functions so the displayed date matches what was actually filtered on."""
    if dak.dak_direction == 'INCOMING':
        return dak.receipt_date
    try:
        return dak.dispatch_details.dispatch_date
    except DakDispatchDetails.DoesNotExist:
        return None

def generate_excel_report(data, title):
    """Generate Excel report"""
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment
    
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = title[:31]  # Excel sheet name max 31 chars
    
    # Headers
    headers = ['S.No', 'Dak Index', 'Direction', 'Category', 'Nature', 
               'Subject', 'Report Date', 'Issue Date', 'Reply Status', 'Created By', 'Created On']
    
    # Style headers
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
    
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center')
    
    # Add data
    for row_idx, dak in enumerate(data, 2):
        basis_date = report_basis_date(dak)
        ws.cell(row=row_idx, column=1, value=row_idx-1)
        ws.cell(row=row_idx, column=2, value=dak.dak_index_no)
        ws.cell(row=row_idx, column=3, value=dak.dak_direction)
        ws.cell(row=row_idx, column=4, value=dak.dak_category.category_code)
        ws.cell(row=row_idx, column=5, value=dak.nature.nature_name if dak.nature else '-')
        ws.cell(row=row_idx, column=6, value=dak.subject[:100])
        ws.cell(row=row_idx, column=7, value=basis_date.strftime('%d-%b-%Y') if basis_date else '-')
        ws.cell(row=row_idx, column=8, value=dak.issue_date.strftime('%d-%b-%Y'))
        ws.cell(row=row_idx, column=9, value='Pending' if dak.reply_mode == 'NOT_YET' else 'Replied')
        ws.cell(row=row_idx, column=10, value=dak.created_by.username if dak.created_by else 'System')
        ws.cell(row=row_idx, column=11, value=dak.created_on.strftime('%d-%b-%Y %H:%M'))
    
    # Auto-adjust column widths
    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = len(str(cell.value))
            except:
                pass
        adjusted_width = min(max_length + 2, 50)
        ws.column_dimensions[column_letter].width = adjusted_width
    
    # Save to response
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = f'attachment; filename="{title}_{datetime.now().strftime("%Y%m%d")}.xlsx"'
    wb.save(response)
    return response

def generate_csv_report(data, title):
    """Generate CSV report"""
    import csv
    
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="{title}_{datetime.now().strftime("%Y%m%d")}.csv"'
    
    writer = csv.writer(response)
    
    # Write headers
    writer.writerow(['S.No', 'Dak Index', 'Direction', 'Category', 'Nature', 
                     'Subject', 'Report Date', 'Issue Date', 'Reply Status', 'Created By', 'Created On'])
    
    # Write data
    for idx, dak in enumerate(data, 1):
        basis_date = report_basis_date(dak)
        writer.writerow([
            idx, dak.dak_index_no, dak.dak_direction, dak.dak_category.category_code,
            dak.nature.nature_name if dak.nature else '-', dak.subject[:100],
            basis_date.strftime('%d-%b-%Y') if basis_date else '-',
            dak.issue_date.strftime('%d-%b-%Y'), 
            'Pending' if dak.reply_mode == 'NOT_YET' else 'Replied',
            dak.created_by.username if dak.created_by else 'System',
            dak.created_on.strftime('%d-%b-%Y %H:%M')
        ])
    
    return response

def generate_module_pdf_report(queryset, columns, title, watermark_text=None, start_date=None, end_date=None):
    """Generic PDF export for the report builder and the eDW/eToT/eIIG
    quick reports — any module, any subset of columns. Uses the official
    DRDO/TBRL report frame (see draw_official_report_frame) so every PDF
    report in the system looks the same.

    Cell content is wrapped in Paragraph flowables (not plain strings) so
    a long column label or value wraps onto a second line within its own
    cell instead of overflowing into the neighboring column — this
    actually happened with wider modules (eDW has 10+ default columns)
    until this was added.
    """
    from .report_columns import resolve_value

    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="{title}_{datetime.now().strftime("%Y%m%d")}.pdf"'

    doc = SimpleDocTemplate(
        response, pagesize=landscape(letter),
        topMargin=1.75 * inch, bottomMargin=0.85 * inch,
        leftMargin=0.40 * inch, rightMargin=0.40 * inch,
    )
    elements = []

    n_cols = len(columns) + 1
    # More columns -> smaller font, so a wide module report still fits
    # rather than each column being squeezed to near-zero width.
    font_size = 7.5 if n_cols <= 8 else (6.5 if n_cols <= 13 else 5.8)

    header_style = ParagraphStyle('hdr', fontName='Times-Bold', fontSize=font_size,
                                   leading=font_size + 1.5, alignment=1, textColor=colors.black)
    cell_style = ParagraphStyle('cell', fontName='Times-Roman', fontSize=font_size,
                                 leading=font_size + 1.5, alignment=1, textColor=colors.black)

    header_row = [Paragraph('S.No', header_style)] + [Paragraph(c['label'], header_style) for c in columns]
    table_data = [header_row]
    for idx, obj in enumerate(queryset, 1):
        row = [Paragraph(str(idx), cell_style)]
        for c in columns:
            val = resolve_value(obj, c['accessor'])
            text = str(val) if val is not None else ''
            row.append(Paragraph(text, cell_style))
        table_data.append(row)

    avail_width = 10.2 * inch
    sno_width = 0.4 * inch
    col_widths = [sno_width] + [(avail_width - sno_width) / max(n_cols - 1, 1)] * (n_cols - 1)

    data_table = Table(table_data, colWidths=col_widths, repeatRows=1)
    data_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), REPORT_HEADER_GRAY),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('GRID', (0, 0), (-1, -1), 0.6, REPORT_BORDER_BLUE),
        ('TOPPADDING', (0, 0), (-1, -1), 3),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
        ('LEFTPADDING', (0, 0), (-1, -1), 3),
        ('RIGHTPADDING', (0, 0), (-1, -1), 3),
    ]))
    elements.append(data_table)

    if watermark_text:
        def _on_page(canvas_obj, doc_):
            draw_official_report_frame(canvas_obj, doc_, title, start_date, end_date)
            canvas_obj.saveState()
            page_w, page_h = doc_.pagesize
            canvas_obj.setFont('Helvetica-Bold', 55)
            canvas_obj.setFillColor(colors.Color(0.6, 0.6, 0.6, alpha=0.14))
            canvas_obj.translate(page_w / 2, page_h / 2)
            canvas_obj.rotate(45)
            canvas_obj.drawCentredString(0, 0, watermark_text)
            canvas_obj.restoreState()
    else:
        def _on_page(canvas_obj, doc_):
            draw_official_report_frame(canvas_obj, doc_, title, start_date, end_date)

    doc.build(elements, onFirstPage=_on_page, onLaterPages=_on_page, canvasmaker=NumberedCanvas)
    return response


def generate_module_docx_report(queryset, columns, title, watermark_text='IIG-DCMM'):
    """Generic DOCX export for the report builder. The watermark and
    title go in the page header, which Word repeats on every page by
    default (same intent as the PDF header fix, native to the format)."""
    from docx import Document
    from docx.shared import Pt, RGBColor, Inches
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from .report_columns import resolve_value

    document = Document()
    section = document.sections[0]
    section.orientation = 1  # landscape
    section.page_width, section.page_height = section.page_height, section.page_width

    # Header — repeats on every page natively in Word
    header = section.header
    wm_para = header.paragraphs[0]
    wm_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    wm_run = wm_para.add_run(watermark_text or '')
    wm_run.font.size = Pt(36)
    wm_run.font.bold = True
    wm_run.font.color.rgb = RGBColor(0xD9, 0xD9, 0xD9)  # light grey, watermark-style

    title_para = header.add_paragraph()
    title_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title_run = title_para.add_run(title)
    title_run.font.size = Pt(14)
    title_run.font.bold = True

    date_para = header.add_paragraph()
    date_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    date_run = date_para.add_run(f"Generated {datetime.now().strftime('%d-%b-%Y %H:%M')}")
    date_run.font.size = Pt(8)

    document.add_paragraph()  # spacing after header content on page 1

    table = document.add_table(rows=1, cols=len(columns) + 1)
    table.style = 'Light Grid Accent 1'
    hdr_cells = table.rows[0].cells
    hdr_cells[0].text = 'S.No'
    for i, c in enumerate(columns, 1):
        hdr_cells[i].text = c['label']

    for idx, obj in enumerate(queryset, 1):
        row_cells = table.add_row().cells
        row_cells[0].text = str(idx)
        for i, c in enumerate(columns, 1):
            val = resolve_value(obj, c['accessor'])
            row_cells[i].text = str(val) if val is not None else ''

    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document')
    response['Content-Disposition'] = f'attachment; filename="{title}_{datetime.now().strftime("%Y%m%d")}.docx"'
    document.save(response)
    return response


def get_module_report_data(module_key, start_date=None, end_date=None):
    """Queryset for a module's quick report, optionally filtered by
    created_at date range. Each module gets its own select_related list
    matching the FK columns its default report columns actually use."""
    from .models import eDW, eTOT, eIIGVisit

    if module_key == 'edw':
        qs = eDW.objects.select_related('company_name', 'group', 'dak', 'created_by')
    elif module_key == 'etot':
        qs = eTOT.objects.select_related('technical_group', 'point_of_contact', 'licensee_company', 'created_by')
    elif module_key == 'eiig':
        qs = eIIGVisit.objects.select_related('created_by')
    else:
        return None

    if start_date:
        qs = qs.filter(created_at__date__gte=start_date)
    if end_date:
        qs = qs.filter(created_at__date__lte=end_date)
    return qs.order_by('-created_at')


def generate_module_excel_report(queryset, columns, title):
    """Generic Excel export for any module (eDW/eToT/eIIG) and any column
    subset — same idea as generate_excel_report, but not hard-coded to
    Dak fields. Fills the Excel-shaped gap in the report builder, which
    previously only offered PDF and Word."""
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment
    from .report_columns import resolve_value

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = title[:31]

    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="0F766E", end_color="0F766E", fill_type="solid")

    ws.cell(row=1, column=1, value='S.No').font = header_font
    ws.cell(row=1, column=1).fill = header_fill
    for col, c in enumerate(columns, 2):
        cell = ws.cell(row=1, column=col, value=c['label'])
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center')

    for row_idx, obj in enumerate(queryset, 2):
        ws.cell(row=row_idx, column=1, value=row_idx - 1)
        for col, c in enumerate(columns, 2):
            val = resolve_value(obj, c['accessor'])
            ws.cell(row=row_idx, column=col, value=str(val) if val is not None else '')

    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = len(str(cell.value))
            except Exception:
                pass
        ws.column_dimensions[column_letter].width = min(max_length + 2, 50)

    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = f'attachment; filename="{title}_{datetime.now().strftime("%Y%m%d")}.xlsx"'
    wb.save(response)
    return response


def generate_module_csv_report(queryset, columns, title):
    """Generic CSV export for any module and any column subset."""
    import csv
    from .report_columns import resolve_value

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="{title}_{datetime.now().strftime("%Y%m%d")}.csv"'
    writer = csv.writer(response)
    writer.writerow(['S.No'] + [c['label'] for c in columns])
    for idx, obj in enumerate(queryset, 1):
        row = [idx]
        for c in columns:
            val = resolve_value(obj, c['accessor'])
            row.append(val if val is not None else '')
        writer.writerow(row)
    return response



def generate_pdf_report(data, title, start_date, end_date, watermark_text=None):
    """Generate PDF report using the official DRDO/TBRL report frame
    (see draw_official_report_frame) — matches the approved I2G-DCMM
    format: border, RESTRICTED markings, crest, title block, Report/
    Period line, data table, and footer with page count.

    The column-header row repeats on every page the table spans
    (repeatRows=1), and every row is included — no row cap.
    """
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="{title}_{datetime.now().strftime("%Y%m%d")}.pdf"'

    doc = SimpleDocTemplate(
        response, pagesize=landscape(letter),
        topMargin=1.75 * inch, bottomMargin=0.85 * inch,
        leftMargin=0.40 * inch, rightMargin=0.40 * inch,
    )
    elements = []

    data = list(data)
    table_data = [['S.No', 'Dak Index', 'Direction', 'Category', 'Report Date', 'Reply Status']]
    for idx, dak in enumerate(data, 1):
        basis_date = report_basis_date(dak)
        table_data.append([
            str(idx), dak.dak_index_no, dak.dak_direction,
            dak.dak_category.category_code,
            basis_date.strftime('%d-%b-%Y') if basis_date else '-',
            'Pending' if dak.reply_mode == 'NOT_YET' else 'Replied'
        ])

    data_table = Table(
        table_data,
        colWidths=[0.5 * inch, 1.5 * inch, 1.1 * inch, 1.1 * inch, 1.2 * inch, 1.1 * inch],
        repeatRows=1,
    )
    data_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), REPORT_HEADER_GRAY),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Times-Bold'),
        ('FONTNAME', (0, 1), (-1, -1), 'Times-Roman'),
        ('FONTSIZE', (0, 0), (-1, 0), 10),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
        ('GRID', (0, 0), (-1, -1), 0.6, REPORT_BORDER_BLUE),
        ('FONTSIZE', (0, 1), (-1, -1), 9),
    ]))
    elements.append(data_table)

    if watermark_text:
        def _on_page(canvas_obj, doc_):
            draw_official_report_frame(canvas_obj, doc_, title, start_date, end_date)
            canvas_obj.saveState()
            page_w, page_h = doc_.pagesize
            canvas_obj.setFont('Helvetica-Bold', 55)
            canvas_obj.setFillColor(colors.Color(0.6, 0.6, 0.6, alpha=0.14))
            canvas_obj.translate(page_w / 2, page_h / 2)
            canvas_obj.rotate(45)
            canvas_obj.drawCentredString(0, 0, watermark_text)
            canvas_obj.restoreState()
    else:
        def _on_page(canvas_obj, doc_):
            draw_official_report_frame(canvas_obj, doc_, title, start_date, end_date)

    doc.build(elements, onFirstPage=_on_page, onLaterPages=_on_page, canvasmaker=NumberedCanvas)
    return response