from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('daks', '0005_dakfileattachment_public_id_dakmaster_public_id_and_more'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='ModuleExtraColumn',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True,
                                           serialize=False, verbose_name='ID')),
                ('module', models.CharField(
                    choices=[('edw', 'eDW'), ('etot', 'eToT'), ('eiig', 'eIIG')],
                    db_index=True, max_length=10)),
                ('column_label', models.CharField(max_length=200,
                                                  verbose_name='Column Label')),
                ('field_type', models.CharField(
                    choices=[('text', 'Text'), ('number', 'Number'),
                             ('date', 'Date'), ('bool', 'Yes / No')],
                    default='text', max_length=10)),
                ('sort_order', models.PositiveSmallIntegerField(
                    default=0,
                    help_text='Lower number = appears first')),
                ('is_active', models.BooleanField(default=True)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('created_by', models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name='extra_columns_created',
                    to=settings.AUTH_USER_MODEL)),
            ],
            options={
                'verbose_name': 'Module Extra Column',
                'verbose_name_plural': 'Module Extra Columns',
                'db_table': 'module_extra_column',
                'ordering': ['module', 'sort_order', 'column_label'],
            },
        ),
        migrations.CreateModel(
            name='ModuleExtraColumnValue',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True,
                                           serialize=False, verbose_name='ID')),
                ('record_pk', models.CharField(db_index=True, max_length=50)),
                ('value', models.TextField(blank=True, null=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('column', models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='values',
                    to='daks.moduleextracolumn')),
            ],
            options={
                'verbose_name': 'Extra Column Value',
                'db_table': 'module_extra_column_value',
                'unique_together': {('column', 'record_pk')},
            },
        ),
    ]
