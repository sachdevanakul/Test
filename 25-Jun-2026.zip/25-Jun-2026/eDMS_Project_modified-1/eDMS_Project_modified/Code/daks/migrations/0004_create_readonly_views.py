"""
Read-only reporting/analyst views.

These are plain Postgres VIEWs over the existing tables — they don't store
data themselves, just a saved, curated SELECT. The point is: anyone or
anything that only ever needs to READ data (a BI tool, an analyst running
ad-hoc SQL, a future read-only role) can be pointed at these views and
GRANTed SELECT on them instead of the raw tables — so they never see
internal-only columns (server file paths, checksums, granular financial
breakdowns) and can never accidentally get write access to a table by
mistake.

The Django app itself keeps reading/writing the real tables as normal —
nothing here changes app behaviour. These views are an additional, safer
surface for read-only consumption outside the app.

Safe to re-run: every statement is CREATE OR REPLACE / DROP IF EXISTS.
"""

from django.db import migrations


CREATE_VIEWS_SQL = """
CREATE OR REPLACE VIEW v_dak_summary AS
SELECT
    d.id,
    d.public_id,
    d.dak_index_no,
    d.dak_direction,
    d.subject,
    d.issue_date,
    d.receipt_date,
    d.reply_mode,
    d.reply_type,
    d.is_active,
    d.created_on,
    d.updated_on,
    t.thread_code,
    t.status            AS thread_status,
    c.category_name,
    n.nature_name,
    ro.org_name          AS receiver_org_name,
    rp.person_name        AS receiver_person_name,
    u.username           AS created_by_username
FROM dak_master d
LEFT JOIN dak_thread t           ON t.id = d.thread_id
LEFT JOIN dak_category_master c ON c.id = d.dak_category_id
LEFT JOIN dak_nature_master n    ON n.id = d.nature_id
LEFT JOIN organization_master ro ON ro.id = d.receiver_org_id
LEFT JOIN person_master rp       ON rp.id = d.receiver_person_id
LEFT JOIN auth_user u            ON u.id = d.created_by_id;


CREATE OR REPLACE VIEW v_dak_attachment_safe AS
SELECT
    a.id,
    a.public_id,
    a.file_name,
    a.file_size,
    a.mime_type,
    a.is_encrypted,
    a.description,
    a.uploaded_at,
    d.dak_index_no,
    d.public_id           AS dak_public_id,
    u.username            AS uploaded_by_username
FROM dak_file_attachment a
JOIN dak_master d  ON d.id = a.dak_id
LEFT JOIN auth_user u ON u.id = a.uploaded_by_id;
-- Deliberately excludes file_path (server filesystem path) and checksum
-- (internal integrity value) — neither is needed for read-only reporting,
-- and file_path in particular reveals server directory structure.


CREATE OR REPLACE VIEW v_thread_summary AS
SELECT
    t.id,
    t.public_id,
    t.thread_code,
    t.subject_summary,
    t.status,
    t.dak_count,
    t.created_on,
    t.closed_on,
    t.last_activity,
    cb.username  AS created_by_username,
    xb.username  AS closed_by_username
FROM dak_thread t
LEFT JOIN auth_user cb ON cb.id = t.created_by_id
LEFT JOIN auth_user xb ON xb.id = t.closed_by_id;


CREATE OR REPLACE VIEW v_task_summary AS
SELECT
    w.id,
    w.public_id,
    w.title,
    w.priority,
    w.status,
    w.deadline,
    w.completed_at,
    w.created_at,
    at_.username   AS assigned_to_username,
    ab.username    AS assigned_by_username,
    d.dak_index_no AS linked_dak_index_no,
    d.public_id    AS linked_dak_public_id
FROM work_task w
LEFT JOIN auth_user at_ ON at_.id = w.assigned_to_id
LEFT JOIN auth_user ab  ON ab.id = w.assigned_by_id
LEFT JOIN dak_master d  ON d.id = w.linked_dak_id;


CREATE OR REPLACE VIEW v_edw_summary AS
SELECT
    e.id,
    e.public_id,
    e.acn_no,
    e.rdr_register_number,
    e.acn_date,
    e.workflow_stage,
    e.status,
    e.is_closed,
    e.amount_paid_by_firm,
    e.created_at,
    e.updated_at,
    co.org_name     AS company_name,
    g.group_name    AS group_name,
    d.dak_index_no  AS dak_index_no,
    cb.username     AS created_by_username
FROM edw_master e
LEFT JOIN organization_master co ON co.id = e.company_name_id
LEFT JOIN group_master g         ON g.id = e.group_id
LEFT JOIN dak_master d           ON d.id = e.dak_id
LEFT JOIN auth_user cb           ON cb.id = e.created_by_id;
-- Deliberately excludes granular financial fields (bank_reference_no,
-- refund_amount, cancellation_amount, treasury_deposit_amount, GST
-- breakdowns, etc.) — only the headline "amount_paid_by_firm" is kept for
-- a general read-only summary. Grant SELECT on the base table directly
-- for any role that genuinely needs full financial detail.


CREATE OR REPLACE VIEW v_etot_summary AS
SELECT
    et.id,
    et.public_id,
    et.tot_file_no,
    et.product_technology,
    et.technology_category,
    et.stage,
    et.licensee_name,
    et.latot_no,
    et.ttd_no,
    et.no_of_licenses_approved,
    et.created_at,
    et.updated_at,
    tg.group_name      AS technical_group_name,
    poc.person_name    AS point_of_contact_name,
    lc.org_name        AS licensee_company_name,
    cb.username        AS created_by_username
FROM etot_master et
LEFT JOIN group_master tg        ON tg.id = et.technical_group_id
LEFT JOIN person_master poc      ON poc.id = et.point_of_contact_id
LEFT JOIN organization_master lc ON lc.id = et.licensee_company_id
LEFT JOIN auth_user cb           ON cb.id = et.created_by_id;
-- Deliberately excludes fee/royalty figures (tot_fee_paid_by_licensee,
-- royalty_fee_received, gst_details) — same reasoning as the eDW view.


CREATE OR REPLACE VIEW v_eiig_summary AS
SELECT
    v.id,
    v.public_id,
    v.visit_id,
    v.date_of_visit,
    v.firm_name,
    v.firm_state,
    v.company_category,
    v.company_sub_category,
    v.created_at,
    cb.username AS created_by_username
FROM eiig_visit v
LEFT JOIN auth_user cb ON cb.id = v.created_by_id;
-- Excludes purpose_of_visit / feedback / remarks (free-text notes that may
-- contain sensitive visit details) from the general-purpose summary view.
"""


DROP_VIEWS_SQL = """
DROP VIEW IF EXISTS v_dak_summary;
DROP VIEW IF EXISTS v_dak_attachment_safe;
DROP VIEW IF EXISTS v_thread_summary;
DROP VIEW IF EXISTS v_task_summary;
DROP VIEW IF EXISTS v_edw_summary;
DROP VIEW IF EXISTS v_etot_summary;
DROP VIEW IF EXISTS v_eiig_summary;
"""


class Migration(migrations.Migration):

    dependencies = [
        ('daks', '0001_initial'),
    ]

    operations = []
