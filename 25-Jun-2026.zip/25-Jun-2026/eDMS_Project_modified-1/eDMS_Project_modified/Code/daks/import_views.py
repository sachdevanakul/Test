"""
eDMS Bulk Import Views
─────────────────────
Three separate import pipelines:
  • bulk_import_edw   → eDW records (acn_no is the natural key)
  • bulk_import_etot  → eTOT records (latot_no / ttd_no are unique; tot_file_no is not)
  • bulk_import_eiig  → eIIG visits + their visitors (visit_id auto-generated)

Each pipeline:
  1. Validates columns
  2. Resolves FK text values → DB ids (org, group, person)
  3. Parses / coerces every field
  4. Upserts (update_or_create) to support repeated imports of corrected data
  5. Returns per-row success / error details

Template download endpoints serve blank Excel files with all supported columns.
"""

from io import BytesIO
import re, datetime
import pandas as pd
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.db import transaction


# ─── helpers ──────────────────────────────────────────────────────────────────

def _resolve_dak(val):
    """Resolve a Dak Index No. string to a DakMaster instance, or None."""
    if not val:
        return None
    from .models import DakMaster
    try:
        return DakMaster.objects.get(dak_index_no=val.strip())
    except DakMaster.DoesNotExist:
        return None
    except Exception:
        return None

def _df_from_upload(upload_file):
    """Read Excel or CSV upload into a normalised DataFrame."""
    name = upload_file.name.lower()
    raw  = upload_file.read()
    if name.endswith('.csv'):
        df = pd.read_csv(BytesIO(raw), dtype=str)
    else:
        df = pd.read_excel(BytesIO(raw), dtype=str)
    df.columns = [c.strip().lower().replace(' ', '_') for c in df.columns]
    df = df.where(pd.notnull(df), None)   # NaN → None
    return df

def _parse_date(val):
    """Return a date object or None.  Accepts dd/mm/yyyy, dd-mm-yyyy, yyyy-mm-dd, Excel serial."""
    if val is None:
        return None
    s = str(val).strip()
    if not s or s.lower() in ('nan', 'none', 'n/a', '-', ''):
        return None
    # Excel serial (number)
    if re.fullmatch(r'\d{4,6}', s):
        try:
            from datetime import date as _d
            delta = datetime.timedelta(int(s) - 2)
            return (_d(1900, 1, 1) + delta)
        except Exception:
            pass
    for fmt in ('%d/%m/%Y', '%d-%m-%Y', '%Y-%m-%d', '%d/%m/%y', '%d-%m-%y',
                '%Y/%m/%d', '%m/%d/%Y', '%d %b %Y', '%d %B %Y'):
        try:
            return datetime.datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    # Last resort: pandas
    try:
        return pd.to_datetime(s, dayfirst=True).date()
    except Exception:
        return None

def _parse_decimal(val):
    if val is None:
        return None
    s = str(val).strip().replace(',', '')
    try:
        return float(s)
    except ValueError:
        return None

def _parse_int(val):
    if val is None:
        return None
    try:
        return int(float(str(val).strip()))
    except (ValueError, TypeError):
        return None

def _parse_bool(val):
    if val is None:
        return False
    return str(val).strip().lower() in ('yes', 'true', '1', 'y')

def _get(row, *keys, default=None):
    """Get first matching key from row dict, strip whitespace."""
    for k in keys:
        v = row.get(k)
        if v is not None:
            s = str(v).strip()
            return s if s else default
    return default

def _resolve_org(name_text, cache):
    """Return OrganizationMaster instance or None, create if missing."""
    if not name_text:
        return None
    key = name_text.strip().lower()
    if key in cache:
        return cache[key]
    from .models import OrganizationMaster
    try:
        obj = OrganizationMaster.objects.get(org_name__iexact=name_text.strip())
    except OrganizationMaster.DoesNotExist:
        # Create a placeholder — staff can enrich later
        obj = OrganizationMaster.objects.create(org_name=name_text.strip())
    except OrganizationMaster.MultipleObjectsReturned:
        obj = OrganizationMaster.objects.filter(org_name__iexact=name_text.strip()).first()
    cache[key] = obj
    return obj

def _resolve_group(name_text, cache):
    """Return GroupMaster instance or None."""
    if not name_text:
        return None
    key = name_text.strip().lower()
    if key in cache:
        return cache[key]
    from .models import GroupMaster
    try:
        obj = GroupMaster.objects.get(group_name__iexact=name_text.strip())
    except GroupMaster.DoesNotExist:
        try:
            obj = GroupMaster.objects.get(group_code__iexact=name_text.strip())
        except GroupMaster.DoesNotExist:
            obj = GroupMaster.objects.create(group_name=name_text.strip(), group_code=name_text.strip()[:10].upper())
    except GroupMaster.MultipleObjectsReturned:
        obj = GroupMaster.objects.filter(group_name__iexact=name_text.strip()).first()
    cache[key] = obj
    return obj

def _resolve_person(name_text, cache):
    """Return PersonMaster instance or None."""
    if not name_text:
        return None
    key = name_text.strip().lower()
    if key in cache:
        return cache[key]
    from .models import PersonMaster
    qs = PersonMaster.objects.filter(person_name__iexact=name_text.strip())
    obj = qs.first()
    cache[key] = obj
    return obj


# ══════════════════════════════════════════════════════════════════════════════
# EDW IMPORT
# ══════════════════════════════════════════════════════════════════════════════

EDW_REQUIRED = {'acn_no'}

EDW_COLUMNS = [
    ('acn_no',                           'ACN No. *',                             'TEXT'),
    ('rdr_register_number',              'RDR Register Number',                   'TEXT'),
    ('acn_date',                         'ACN Date',                              'DATE'),
    ('company_name',                     'Company Name (org master)',             'TEXT'),
    ('group',                            'Group (group master)',                  'TEXT'),
    ('acn_request_received_date',        'ACN Request Received Date',             'DATE'),
    ('intimation_acn_to_group',          'Intimation ACN to Group (MAIL/HARD_COPY)', 'TEXT'),
    ('bq_shared_to_firm_date',           'BQ Shared to Firm Date',                'DATE'),
    ('amount_paid_by_firm',              'Amount Paid by Firm',                   'NUMBER'),
    ('bank_reference_no',                'Bank Reference No.',                    'TEXT'),
    ('firm_payment_date',                'Firm Payment Date',                     'DATE'),
    ('amount_reflected_in_acn',          'Amount Reflected in ACN',               'NUMBER'),
    ('testing_changes_receipt_no',       'Testing Changes Receipt No.',           'TEXT'),
    ('testing_changes_receipt_date',     'Testing Changes Receipt Date',          'DATE'),
    ('emro_payment_date',                'eMRO Payment Date',                     'DATE'),
    ('mro_outgoing_date',                'MRO Outgoing Date',                     'DATE'),
    ('mro_number',                       'MRO No.',                               'TEXT'),
    ('mro_date',                         'MRO Date',                              'DATE'),
    ('trial_title',                      'Trial Title',                           'TEXT'),
    ('no_of_test_samples_planned',       'No. of Test Samples Planned',           'NUMBER'),
    ('no_of_test_conducted',             'No. of Test Conducted',                 'NUMBER'),
    ('trial_tentative_date',             'Trial Tentative Date',                  'DATE'),
    ('account_date',                     'Account Date',                          'DATE'),
    ('job_number_alloted_by_i2g',        'Job Number Allotted by I2G',            'TEXT'),
    ('te_number_outgoing_date',          'TE Number Outgoing Date',               'DATE'),
    ('te_number_incoming_date',          'TE Number Incoming Date',               'DATE'),
    ('report_received_from_group',       'Report Received from Group',            'DATE'),
    ('trial_report_no',                  'Trial Report No.',                      'TEXT'),
    ('trial_report_issued_on',           'Trial Report Issued On',                'DATE'),
    ('report_to_whom_dispatched',        'Report To Whom Dispatched',             'TEXT'),
    ('dispatch_date',                    'Dispatch Date',                         'DATE'),
    ('speed_post_no',                    'Speed Post No.',                        'TEXT'),
    ('speed_post_date',                  'Speed Post Date',                       'DATE'),
    ('amount_utilized',                  'Amount Utilized',                       'NUMBER'),
    ('balance_unspent_amount',           'Balance / Unspent Amount',              'NUMBER'),
    ('cancellation_amount',              'Cancellation Amount',                   'NUMBER'),
    ('refund_amount',                    'Refund Amount',                         'NUMBER'),
    ('gst_paid_on_rcm_basis_transaction_no', 'GST RCM Transaction No.',          'TEXT'),
    ('gst_paid_on_rcm_basis_date',       'GST RCM Date',                          'DATE'),
    ('gst_challan_no',                   'GST Challan No.',                       'TEXT'),
    ('gst_challan_amount',               'GST Challan Amount',                    'NUMBER'),
    ('gst_challan_date',                 'GST Challan Date',                      'DATE'),
    ('jcc_number',                       'JCC Number',                            'TEXT'),
    ('jcc_received_date',                'JCC Received Date',                     'DATE'),
    ('code_head',                        'Code Head',                             'TEXT'),
    ('dpsu_psu_private_capf',            'DPSU/PSU/Private/CAPF',                'TEXT'),
    ('status',                           'Status (COMPLETED/ONGOING)',            'TEXT'),
    ('workflow_stage',                   'Workflow Stage',                        'TEXT'),
    ('for_closure',                      'For Closure (Yes/No)',                  'BOOL'),
    # Closure fields
    ('closure_request_sent_on',          'Closure Request Sent On',               'DATE'),
    ('te_closure_on',                    'TE Closure On',                         'DATE'),
    ('te_closure_no',                    'TE Closure Number',                     'TEXT'),
    ('treasury_deposit_amount',          'Treasury/Bank Deposit Amount',          'NUMBER'),
    ('dw_closed_on',                     'DW Closed On',                          'DATE'),
    ('is_closed',                        'DW Closed (Yes/No)',                    'BOOL'),
    # Dak section link (resolved by Dak Index No.)
    ('dak_index_no',                     'Initial Inquiry Dak Index No.',         'TEXT'),
    ('remarks',                          'Remarks',                               'TEXT'),
]

@login_required
def bulk_import_edw(request):
    if not request.user.is_staff:
        messages.error(request, 'Staff access required.')
        return redirect('daks:home')

    ctx = {'module': 'eDW', 'columns': EDW_COLUMNS,
           'template_url': 'daks:download_template_edw'}

    if request.method != 'POST':
        return render(request, 'daks/bulk_import_module.html', ctx)

    upload = request.FILES.get('import_file')
    if not upload:
        messages.error(request, 'Please select a file.')
        return render(request, 'daks/bulk_import_module.html', ctx)

    dry_run = request.POST.get('dry_run') == 'on'

    try:
        df = _df_from_upload(upload)
    except Exception as e:
        messages.error(request, f'Could not read file: {e}')
        return render(request, 'daks/bulk_import_module.html', ctx)

    if len(df) > MAX_ROWS:
        messages.error(request, f'File has {len(df)} rows. Maximum allowed is {MAX_ROWS}.')
        return render(request, 'daks/bulk_import_module.html', ctx)

    missing_req = EDW_REQUIRED - set(df.columns)
    if missing_req:
        messages.error(request, f'Missing required columns: {", ".join(missing_req)}')
        return render(request, 'daks/bulk_import_module.html', ctx)

    from .models import eDW
    org_cache, grp_cache = {}, {}
    success = skipped = created = updated = 0
    errors = []

    for idx, row in df.iterrows():
        row_num = idx + 2
        acn_no = _get(row, 'acn_no')
        if not acn_no:
            errors.append({'row': row_num, 'acn': '—', 'msg': 'acn_no is blank — row skipped'})
            skipped += 1
            continue

        try:
            defaults = {
                'rdr_register_number':               _get(row, 'rdr_register_number'),
                'acn_date':                          _parse_date(_get(row, 'acn_date')),
                'company_name':                      _resolve_org(_get(row, 'company_name'), org_cache),
                'group':                             _resolve_group(_get(row, 'group'), grp_cache),
                'acn_request_received_date':         _parse_date(_get(row, 'acn_request_received_date')),
                'intimation_acn_to_group':           _get(row, 'intimation_acn_to_group'),
                'bq_shared_to_firm_date':            _parse_date(_get(row, 'bq_shared_to_firm_date')),
                'amount_paid_by_firm':               _parse_decimal(_get(row, 'amount_paid_by_firm')),
                'bank_reference_no':                 _get(row, 'bank_reference_no'),
                'firm_payment_date':                 _parse_date(_get(row, 'firm_payment_date')),
                'amount_reflected_in_acn':           _parse_decimal(_get(row, 'amount_reflected_in_acn')),
                'testing_changes_receipt_no':        _get(row, 'testing_changes_receipt_no'),
                'testing_changes_receipt_date':      _parse_date(_get(row, 'testing_changes_receipt_date')),
                'emro_payment_date':                 _parse_date(_get(row, 'emro_payment_date')),
                'mro_outgoing_date':                 _parse_date(_get(row, 'mro_outgoing_date')),
                'mro_number':                        _get(row, 'mro_number'),
                'mro_date':                          _parse_date(_get(row, 'mro_date')),
                'trial_title':                       _get(row, 'trial_title'),
                'no_of_test_samples_planned':        _parse_int(_get(row, 'no_of_test_samples_planned')),
                'no_of_test_conducted':              _parse_int(_get(row, 'no_of_test_conducted')),
                'trial_tentative_date':              _parse_date(_get(row, 'trial_tentative_date')),
                'account_date':                      _parse_date(_get(row, 'account_date')),
                'job_number_alloted_by_i2g':         _get(row, 'job_number_alloted_by_i2g'),
                'te_number_outgoing_date':           _parse_date(_get(row, 'te_number_outgoing_date')),
                'te_number_incoming_date':           _parse_date(_get(row, 'te_number_incoming_date')),
                'report_received_from_group':        _parse_date(_get(row, 'report_received_from_group')),
                'trial_report_no':                   _get(row, 'trial_report_no'),
                'trial_report_issued_on':            _parse_date(_get(row, 'trial_report_issued_on')),
                'report_to_whom_dispatched':         _get(row, 'report_to_whom_dispatched'),
                'dispatch_date':                     _parse_date(_get(row, 'dispatch_date')),
                'speed_post_no':                     _get(row, 'speed_post_no'),
                'speed_post_date':                   _parse_date(_get(row, 'speed_post_date')),
                'amount_utilized':                   _parse_decimal(_get(row, 'amount_utilized')),
                'balance_unspent_amount':            _parse_decimal(_get(row, 'balance_unspent_amount')),
                'cancellation_amount':               _parse_decimal(_get(row, 'cancellation_amount')),
                'refund_amount':                     _parse_decimal(_get(row, 'refund_amount')),
                'gst_paid_on_rcm_basis_transaction_no': _get(row, 'gst_paid_on_rcm_basis_transaction_no'),
                'gst_paid_on_rcm_basis_date':        _parse_date(_get(row, 'gst_paid_on_rcm_basis_date')),
                'gst_challan_no':                    _get(row, 'gst_challan_no'),
                'gst_challan_amount':                _parse_decimal(_get(row, 'gst_challan_amount')),
                'gst_challan_date':                  _parse_date(_get(row, 'gst_challan_date')),
                'jcc_number':                        _get(row, 'jcc_number'),
                'jcc_received_date':                 _parse_date(_get(row, 'jcc_received_date')),
                'code_head':                         _get(row, 'code_head'),
                'dpsu_psu_private_capf':             _get(row, 'dpsu_psu_private_capf'),
                'status':                            (_get(row, 'status') or 'ONGOING').upper(),
                'workflow_stage':                    (_get(row, 'workflow_stage') or 'INQUIRY').upper(),
                'for_closure':                       _parse_bool(_get(row, 'for_closure')),
                # Closure fields
                'closure_request_sent_on':           _parse_date(_get(row, 'closure_request_sent_on')),
                'te_closure_on':                     _parse_date(_get(row, 'te_closure_on')),
                'te_closure_no':                     _get(row, 'te_closure_no'),
                'treasury_deposit_amount':           _parse_decimal(_get(row, 'treasury_deposit_amount')),
                'dw_closed_on':                      _parse_date(_get(row, 'dw_closed_on')),
                'is_closed':                         _parse_bool(_get(row, 'is_closed')),
                # Dak section link — resolve by dak_index_no text value
                'dak':                               _resolve_dak(_get(row, 'dak_index_no')),
                'remarks':                           _get(row, 'remarks'),
                'created_by':                        request.user,
            }
            # strip None-valued keys that must not overwrite existing data on update
            defaults = {k: v for k, v in defaults.items() if v is not None or k in ('for_closure', 'is_closed')}

            if not dry_run:
                with transaction.atomic():
                    obj, was_created = eDW.objects.update_or_create(
                        acn_no=acn_no,
                        defaults=defaults
                    )
                if was_created:
                    created += 1
                else:
                    updated += 1
            else:
                created += 1   # in dry-run count as "would create/update"

            success += 1

        except Exception as e:
            errors.append({'row': row_num, 'acn': acn_no, 'msg': str(e)})
            skipped += 1

    ctx.update({
        'done': True, 'dry_run': dry_run,
        'success': success, 'skipped': skipped,
        'created': created, 'updated': updated,
        'errors': errors[:100],
        'total': len(df),
    })
    return render(request, 'daks/bulk_import_module.html', ctx)


# ══════════════════════════════════════════════════════════════════════════════
# ETOT IMPORT
# ══════════════════════════════════════════════════════════════════════════════

ETOT_REQUIRED = {'tot_file_no', 'product_technology'}

ETOT_COLUMNS = [
    ('tot_file_no',                              'ToT File No. *',                     'TEXT'),
    ('product_technology',                       'Product / Technology *',             'TEXT'),
    ('technology_category',                      'Technology Category (A/B)',          'TEXT'),
    ('stage',                                    'Stage',                              'TEXT'),
    ('technical_group',                          'Technical Group',                    'TEXT'),
    ('point_of_contact',                         'Point of Contact (person master)',   'TEXT'),
    ('licensee_name',                            'Licensee Name',                      'TEXT'),
    ('licensee_company',                         'Licensee Company (org master)',       'TEXT'),
    ('licensee_address',                         'Licensee Address',                   'TEXT'),
    ('meeting_held_on',                          'Meeting Held On',                    'DATE'),
    ('minute_signed_by_chairman_on',             'Minute Signed by Chairman',          'DATE'),
    ('minute_approved_by_director_on',           'Minute Approved by Director',        'DATE'),
    ('tnf_initiated_by_group_on',                'TNF Initiated by Group',             'DATE'),
    ('tnf_certificate_issued_by_director_on',    'TNF Certificate Issued by Director', 'DATE'),
    ('tnf_nom_no',                               'TNF NOM No.',                        'TEXT'),
    ('tnf_no_allotted_by_diitm_on',              'TNF No. Allotted by DIITM',          'DATE'),
    ('no_of_licenses_approved',                  'No. of Licenses Approved',           'NUMBER'),
    ('additional_no_of_licenses',                'Additional No. of Licenses',         'NUMBER'),
    ('licenses_awarded_to_industry',             'Licenses Awarded to Industry',       'NUMBER'),
    ('eoi_hosting_on_portal',                    'EOI Hosting on Portal',              'DATE'),
    ('cec_constitution_on',                      'CEC Constitution',                   'DATE'),
    ('cec_meeting_held_on',                      'CEC Meeting Held On',                'DATE'),
    ('cec_report_signed_by_chairman_on',         'CEC Report Signed by Chairman',      'DATE'),
    ('cec_min_forwarded_by_director_on',         'CEC Min Forwarded by Director',      'DATE'),
    ('cec_recommended_by_dg_mss_on',             'CEC Recommended by DG(MSS)',         'DATE'),
    ('recommended_cec_report_to_diitm_on',       'Recommended CEC Report to DIITM',   'DATE'),
    ('cec_approved_by_dg_pc_s7_on',              'CEC Approved by DG(PC&S7)',           'DATE'),
    ('tac_constitution_by_dir_dg_mss_on',        'TAC Constitution by Dir/DG(MSS)',    'DATE'),
    ('tac1_no_of_eoi_received',                  'TAC-1 No. of EOI Received',          'NUMBER'),
    ('defence_industrial_license_no',            'Defence Industrial License No.',     'TEXT'),
    ('defence_industrial_license_date',          'Defence Industrial License Date',    'DATE'),
    ('peso_license_no',                          'PESO License No.',                   'TEXT'),
    ('peso_license_date',                        'PESO License Date',                  'DATE'),
    ('tac1_meeting_held_on',                     'TAC-1 Meeting Held On',              'DATE'),
    ('tac1_report_signed_by_chairman_on',        'TAC-1 Report Signed by Chairman',    'DATE'),
    ('tac1_report_recommended_by_director_on',   'TAC-1 Recommended by Director, TBRL','DATE'),
    ('tac1_report_approved_by_dg_mss_on',        'TAC-1 Approved by DG(MSS)',          'DATE'),
    ('tac1_recommended_firms',                   'TAC-1 Recommended Firms',            'TEXT'),
    ('tac1_report_forwarded_to_diitm_on',        'TAC-1 Report Forwarded to DIITM',    'DATE'),
    ('vetted_latot_shared_with_industry_on',     'Vetted LAToT Shared with Industry',  'DATE'),
    ('signed_stamped_latot_received_on',         'Signed LAToT Received On',           'DATE'),
    ('emro_no',                                  'eMRO No.',                           'TEXT'),
    ('tot_fee_paid_by_licensee',                 'ToT Fee Paid (₹)',                   'NUMBER'),
    ('tot_fee_paid_on',                          'ToT Fee Paid On',                    'DATE'),
    ('gst_details',                              'GST Details',                        'TEXT'),
    ('latot_no',                                 'LAToT No. (unique)',                 'TEXT'),
    ('latot_signed_on',                          'LAToT Signed On',                    'DATE'),
    ('latot_signed_year',                        'LAToT Signed Year',                  'TEXT'),
    ('ttd_no',                                   'TTD No. (unique)',                   'TEXT'),
    ('ttd_issued_on',                            'TTD Issued On',                      'DATE'),
    ('hand_holding_support_weeks',               'Hand Holding Support (Weeks)',        'NUMBER'),
    ('tot_absorption_request_received_on',       'ToT Absorption Request Received',    'DATE'),
    ('tot_absorption_recommendation_from_group_on', 'ToT Absorption Recommendation from Group', 'DATE'),
    ('director_tbrl_recommendation_for_ta_on',   'Director TBRL Recommendation for TA','DATE'),
    ('ta_certificate_no',                        'TA Certificate No.',                 'TEXT'),
    ('ta_certificate_issued_on',                 'TA Certificate Issued On',           'DATE'),
    ('ta_certificate_validity',                  'TA Certificate Validity',            'TEXT'),
    ('royalty_fee_received',                     'Royalty Fee Received (₹)',           'NUMBER'),
    # Dak section link
    ('dak_index_no',                             'Initial Dak Index No. (dak section)','TEXT'),
    ('remarks',                                  'Remarks',                            'TEXT'),
]

@login_required
def bulk_import_etot(request):
    if not request.user.is_staff:
        messages.error(request, 'Staff access required.')
        return redirect('daks:home')

    ctx = {'module': 'eTOT', 'columns': ETOT_COLUMNS,
           'template_url': 'daks:download_template_etot'}

    if request.method != 'POST':
        return render(request, 'daks/bulk_import_module.html', ctx)

    upload = request.FILES.get('import_file')
    if not upload:
        messages.error(request, 'Please select a file.')
        return render(request, 'daks/bulk_import_module.html', ctx)

    dry_run = request.POST.get('dry_run') == 'on'

    try:
        df = _df_from_upload(upload)
    except Exception as e:
        messages.error(request, f'Could not read file: {e}')
        return render(request, 'daks/bulk_import_module.html', ctx)

    if len(df) > MAX_ROWS:
        messages.error(request, f'File has {len(df)} rows. Maximum is {MAX_ROWS}.')
        return render(request, 'daks/bulk_import_module.html', ctx)

    missing_req = ETOT_REQUIRED - set(df.columns)
    if missing_req:
        messages.error(request, f'Missing required columns: {", ".join(missing_req)}')
        return render(request, 'daks/bulk_import_module.html', ctx)

    from .models import eTOT
    org_cache, grp_cache, prs_cache = {}, {}, {}
    success = skipped = created = updated = 0
    errors = []

    for idx, row in df.iterrows():
        row_num = idx + 2
        tot_file_no       = _get(row, 'tot_file_no')
        product_technology = _get(row, 'product_technology')
        if not tot_file_no or not product_technology:
            errors.append({'row': row_num, 'acn': tot_file_no or '—',
                           'msg': 'tot_file_no and product_technology are required'})
            skipped += 1
            continue

        latot_no = _get(row, 'latot_no') or None
        ttd_no   = _get(row, 'ttd_no')   or None

        try:
            defaults = {
                'product_technology':                         product_technology,
                'technology_category':                        _get(row, 'technology_category'),
                'stage':                                      (_get(row, 'stage') or 'INITIATED').upper(),
                'technical_group':                            _resolve_group(_get(row, 'technical_group'), grp_cache),
                'point_of_contact':                           _resolve_person(_get(row, 'point_of_contact'), prs_cache),
                'licensee_name':                              _get(row, 'licensee_name'),
                'licensee_company':                           _resolve_org(_get(row, 'licensee_company'), org_cache),
                'licensee_address':                           _get(row, 'licensee_address'),
                'meeting_held_on':                            _parse_date(_get(row, 'meeting_held_on')),
                'minute_signed_by_chairman_on':               _parse_date(_get(row, 'minute_signed_by_chairman_on')),
                'minute_approved_by_director_on':             _parse_date(_get(row, 'minute_approved_by_director_on')),
                'tnf_initiated_by_group_on':                  _parse_date(_get(row, 'tnf_initiated_by_group_on')),
                'tnf_certificate_issued_by_director_on':      _parse_date(_get(row, 'tnf_certificate_issued_by_director_on')),
                'tnf_nom_no':                                 _get(row, 'tnf_nom_no'),
                'tnf_no_allotted_by_diitm_on':                _parse_date(_get(row, 'tnf_no_allotted_by_diitm_on')),
                'no_of_licenses_approved':                    _parse_int(_get(row, 'no_of_licenses_approved')),
                'additional_no_of_licenses':                  _parse_int(_get(row, 'additional_no_of_licenses')),
                'licenses_awarded_to_industry':               _parse_int(_get(row, 'licenses_awarded_to_industry')),
                'eoi_hosting_on_portal':                      _parse_date(_get(row, 'eoi_hosting_on_portal')),
                'cec_constitution_on':                        _parse_date(_get(row, 'cec_constitution_on')),
                'cec_meeting_held_on':                        _parse_date(_get(row, 'cec_meeting_held_on')),
                'cec_report_signed_by_chairman_on':           _parse_date(_get(row, 'cec_report_signed_by_chairman_on')),
                'cec_min_forwarded_by_director_on':           _parse_date(_get(row, 'cec_min_forwarded_by_director_on')),
                'cec_recommended_by_dg_mss_on':               _parse_date(_get(row, 'cec_recommended_by_dg_mss_on')),
                'recommended_cec_report_to_diitm_on':         _parse_date(_get(row, 'recommended_cec_report_to_diitm_on')),
                'cec_approved_by_dg_pc_s7_on':                _parse_date(_get(row, 'cec_approved_by_dg_pc_s7_on')),
                'tac_constitution_by_dir_dg_mss_on':          _parse_date(_get(row, 'tac_constitution_by_dir_dg_mss_on')),
                'tac1_no_of_eoi_received':                    _parse_int(_get(row, 'tac1_no_of_eoi_received')),
                'defence_industrial_license_no':              _get(row, 'defence_industrial_license_no'),
                'defence_industrial_license_date':            _parse_date(_get(row, 'defence_industrial_license_date')),
                'peso_license_no':                            _get(row, 'peso_license_no'),
                'peso_license_date':                          _parse_date(_get(row, 'peso_license_date')),
                'tac1_meeting_held_on':                       _parse_date(_get(row, 'tac1_meeting_held_on')),
                'tac1_report_signed_by_chairman_on':          _parse_date(_get(row, 'tac1_report_signed_by_chairman_on')),
                'tac1_report_recommended_by_director_on':     _parse_date(_get(row, 'tac1_report_recommended_by_director_on')),
                'tac1_report_approved_by_dg_mss_on':          _parse_date(_get(row, 'tac1_report_approved_by_dg_mss_on')),
                'tac1_recommended_firms':                     _get(row, 'tac1_recommended_firms'),
                'tac1_report_forwarded_to_diitm_on':          _parse_date(_get(row, 'tac1_report_forwarded_to_diitm_on')),
                'vetted_latot_shared_with_industry_on':       _parse_date(_get(row, 'vetted_latot_shared_with_industry_on')),
                'signed_stamped_latot_received_on':           _parse_date(_get(row, 'signed_stamped_latot_received_on')),
                'emro_no':                                    _get(row, 'emro_no'),
                'tot_fee_paid_by_licensee':                   _parse_decimal(_get(row, 'tot_fee_paid_by_licensee')),
                'tot_fee_paid_on':                            _parse_date(_get(row, 'tot_fee_paid_on')),
                'gst_details':                                _get(row, 'gst_details'),
                'latot_no':                                   latot_no,
                'latot_signed_on':                            _parse_date(_get(row, 'latot_signed_on')),
                'latot_signed_year':                          _get(row, 'latot_signed_year'),
                'ttd_no':                                     ttd_no,
                'ttd_issued_on':                              _parse_date(_get(row, 'ttd_issued_on')),
                'hand_holding_support_weeks':                 _parse_int(_get(row, 'hand_holding_support_weeks')),
                'tot_absorption_request_received_on':         _parse_date(_get(row, 'tot_absorption_request_received_on')),
                'tot_absorption_recommendation_from_group_on': _parse_date(_get(row, 'tot_absorption_recommendation_from_group_on')),
                'director_tbrl_recommendation_for_ta_on':    _parse_date(_get(row, 'director_tbrl_recommendation_for_ta_on')),
                'ta_certificate_no':                          _get(row, 'ta_certificate_no'),
                'ta_certificate_issued_on':                   _parse_date(_get(row, 'ta_certificate_issued_on')),
                'ta_certificate_validity':                    _get(row, 'ta_certificate_validity'),
                'royalty_fee_received':                       _parse_decimal(_get(row, 'royalty_fee_received')),
                'remarks':                                    _get(row, 'remarks'),
                'created_by':                                 request.user,
            }

            if not dry_run:
                # Natural key: tot_file_no + product_technology + latot_no (if present)
                # latot_no is unique — use it as lookup key when available
                with transaction.atomic():
                    if latot_no:
                        obj, was_created = eTOT.objects.update_or_create(
                            latot_no=latot_no,
                            defaults={**defaults, 'tot_file_no': tot_file_no}
                        )
                    else:
                        obj, was_created = eTOT.objects.update_or_create(
                            tot_file_no=tot_file_no,
                            product_technology=product_technology,
                            defaults=defaults
                        )
                if was_created:
                    created += 1
                else:
                    updated += 1
            else:
                created += 1

            success += 1

        except Exception as e:
            errors.append({'row': row_num, 'acn': tot_file_no, 'msg': str(e)})
            skipped += 1

    ctx.update({
        'done': True, 'dry_run': dry_run,
        'success': success, 'skipped': skipped,
        'created': created, 'updated': updated,
        'errors': errors[:100], 'total': len(df),
    })
    return render(request, 'daks/bulk_import_module.html', ctx)


# ══════════════════════════════════════════════════════════════════════════════
# EIIG IMPORT
# ══════════════════════════════════════════════════════════════════════════════

EIIG_REQUIRED = {'date_of_visit', 'firm_name'}

EIIG_COLUMNS = [
    ('visit_id',             'Visit ID (leave blank to auto-generate)',  'TEXT'),
    ('date_of_visit',        'Date of Visit *',                          'DATE'),
    ('firm_name',            'Firm / Industry Name *',                   'TEXT'),
    ('firm_address',         'Complete Address',                         'TEXT'),
    ('firm_state',           'State (2-letter code e.g. PB, DL)',        'TEXT'),
    ('company_category',     'Category (INDUSTRY/GOVERNMENT/RESEARCH/INDIVIDUAL/OTHER)', 'TEXT'),
    ('company_sub_category', 'Sub Category (PRIVATE/DPSU/PSU/MSME etc.)','TEXT'),
    ('purpose_of_visit',     'Purpose of Visit',                         'TEXT'),
    ('feedback',             'Feedback',                                  'TEXT'),
    ('remarks',              'Remarks',                                   'TEXT'),
    ('visitor_1_name',       'Visitor 1 — Name',                         'TEXT'),
    ('visitor_1_designation','Visitor 1 — Designation',                  'TEXT'),
    ('visitor_1_mobile',     'Visitor 1 — Mobile',                       'TEXT'),
    ('visitor_1_email',      'Visitor 1 — Email',                        'TEXT'),
    ('visitor_2_name',       'Visitor 2 — Name',                         'TEXT'),
    ('visitor_2_designation','Visitor 2 — Designation',                  'TEXT'),
    ('visitor_2_mobile',     'Visitor 2 — Mobile',                       'TEXT'),
    ('visitor_2_email',      'Visitor 2 — Email',                        'TEXT'),
    ('visitor_3_name',       'Visitor 3 — Name',                         'TEXT'),
    ('visitor_3_designation','Visitor 3 — Designation',                  'TEXT'),
    ('visitor_3_mobile',     'Visitor 3 — Mobile',                       'TEXT'),
    ('visitor_3_email',      'Visitor 3 — Email',                        'TEXT'),
    ('visitor_4_name',       'Visitor 4 — Name',                         'TEXT'),
    ('visitor_4_designation','Visitor 4 — Designation',                  'TEXT'),
    ('visitor_4_mobile',     'Visitor 4 — Mobile',                       'TEXT'),
    ('visitor_4_email',      'Visitor 4 — Email',                        'TEXT'),
    ('visitor_5_name',       'Visitor 5 — Name',                         'TEXT'),
    ('visitor_5_designation','Visitor 5 — Designation',                  'TEXT'),
    ('visitor_5_mobile',     'Visitor 5 — Mobile',                       'TEXT'),
    ('visitor_5_email',      'Visitor 5 — Email',                        'TEXT'),
]

@login_required
def bulk_import_eiig(request):
    if not request.user.is_staff:
        messages.error(request, 'Staff access required.')
        return redirect('daks:home')

    ctx = {'module': 'eIIG', 'columns': EIIG_COLUMNS,
           'template_url': 'daks:download_template_eiig'}

    if request.method != 'POST':
        return render(request, 'daks/bulk_import_module.html', ctx)

    upload = request.FILES.get('import_file')
    if not upload:
        messages.error(request, 'Please select a file.')
        return render(request, 'daks/bulk_import_module.html', ctx)

    dry_run = request.POST.get('dry_run') == 'on'

    try:
        df = _df_from_upload(upload)
    except Exception as e:
        messages.error(request, f'Could not read file: {e}')
        return render(request, 'daks/bulk_import_module.html', ctx)

    if len(df) > MAX_ROWS:
        messages.error(request, f'File has {len(df)} rows. Maximum is {MAX_ROWS}.')
        return render(request, 'daks/bulk_import_module.html', ctx)

    missing_req = EIIG_REQUIRED - set(df.columns)
    if missing_req:
        messages.error(request, f'Missing required columns: {", ".join(missing_req)}')
        return render(request, 'daks/bulk_import_module.html', ctx)

    from .models import eIIGVisit, eIIGVisitor
    success = skipped = created = updated = 0
    errors = []

    for idx, row in df.iterrows():
        row_num   = idx + 2
        visit_date = _parse_date(_get(row, 'date_of_visit'))
        firm_name  = _get(row, 'firm_name')

        if not visit_date or not firm_name:
            errors.append({'row': row_num, 'acn': firm_name or '—',
                           'msg': 'date_of_visit and firm_name are required'})
            skipped += 1
            continue

        try:
            visit_id_given = _get(row, 'visit_id') or None

            defaults = {
                'firm_address':         _get(row, 'firm_address'),
                'firm_state':           (_get(row, 'firm_state') or '').upper() or None,
                'company_category':     (_get(row, 'company_category') or '').upper() or None,
                'company_sub_category': (_get(row, 'company_sub_category') or '').upper() or None,
                'purpose_of_visit':     _get(row, 'purpose_of_visit'),
                'feedback':             _get(row, 'feedback'),
                'remarks':              _get(row, 'remarks'),
                'created_by':           request.user,
            }

            if not dry_run:
                with transaction.atomic():
                    if visit_id_given:
                        visit, was_created = eIIGVisit.objects.update_or_create(
                            visit_id=visit_id_given,
                            defaults={**defaults, 'date_of_visit': visit_date, 'firm_name': firm_name}
                        )
                    else:
                        # Natural key for dedup: same firm + same date
                        visit, was_created = eIIGVisit.objects.get_or_create(
                            date_of_visit=visit_date,
                            firm_name__iexact=firm_name,
                            defaults={**defaults, 'firm_name': firm_name}
                        )
                        if not was_created:
                            # Update fields on existing
                            for k, v in defaults.items():
                                if v is not None:
                                    setattr(visit, k, v)
                            visit.save()

                    if was_created:
                        created += 1
                    else:
                        updated += 1

                    # Visitors (up to 5 per row)
                    for i in range(1, 6):
                        vname = _get(row, f'visitor_{i}_name')
                        if not vname:
                            continue
                        eIIGVisitor.objects.get_or_create(
                            visit=visit,
                            name=vname,
                            defaults={
                                'designation': _get(row, f'visitor_{i}_designation'),
                                'mobile_1':    _get(row, f'visitor_{i}_mobile'),
                                'email_1':     _get(row, f'visitor_{i}_email'),
                            }
                        )
            else:
                created += 1

            success += 1

        except Exception as e:
            errors.append({'row': row_num, 'acn': firm_name, 'msg': str(e)})
            skipped += 1

    ctx.update({
        'done': True, 'dry_run': dry_run,
        'success': success, 'skipped': skipped,
        'created': created, 'updated': updated,
        'errors': errors[:100], 'total': len(df),
    })
    return render(request, 'daks/bulk_import_module.html', ctx)


# ══════════════════════════════════════════════════════════════════════════════
# TEMPLATE DOWNLOADS — blank Excel with all columns + validation dropdowns
# ══════════════════════════════════════════════════════════════════════════════

def _make_excel_template(ws, columns, title, notes=None):
    """Write a styled Excel sheet with headers and a Notes sheet."""
    import openpyxl
    from openpyxl.styles import (PatternFill, Font, Alignment, Border, Side)
    from openpyxl.utils import get_column_letter

    HDR_FILL  = PatternFill('solid', fgColor='1F3864')
    OPT_FILL  = PatternFill('solid', fgColor='EFF6FF')
    REQ_FILL  = PatternFill('solid', fgColor='FEF9C3')
    DATE_FILL = PatternFill('solid', fgColor='F0FDF4')
    NUM_FILL  = PatternFill('solid', fgColor='FFF7ED')
    HDR_FONT  = Font(color='FFFFFF', bold=True, size=9)
    thin      = Side(style='thin', color='CBD5E1')
    border    = Border(left=thin, right=thin, top=thin, bottom=thin)

    ws.title = title

    for col_idx, (field, label, dtype) in enumerate(columns, 1):
        cell = ws.cell(row=1, column=col_idx, value=label)
        cell.fill   = HDR_FILL
        cell.font   = HDR_FONT
        cell.border = border
        cell.alignment = Alignment(wrap_text=True, horizontal='center', vertical='center')

        # Colour data cells by type
        fill = {'DATE': DATE_FILL, 'NUMBER': NUM_FILL}.get(dtype, OPT_FILL)
        if '*' in label:
            fill = REQ_FILL
        for r in range(2, 302):
            dc = ws.cell(row=r, column=col_idx)
            dc.fill  = fill
            dc.border = border
            dc.alignment = Alignment(horizontal='left')

        # Column width
        ws.column_dimensions[get_column_letter(col_idx)].width = max(18, len(label) * 0.85)

    ws.row_dimensions[1].height = 36
    ws.freeze_panes = 'A2'

    if notes:
        # Add a legend row just below headers in column 1
        pass

    return ws


@login_required
def download_template_edw(request):
    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    _make_excel_template(ws, EDW_COLUMNS, 'eDW Import')
    # Notes sheet
    ns = wb.create_sheet('Instructions')
    ns['A1'] = 'eDW Bulk Import — Instructions'
    ns['A2'] = '• Columns marked * are required. All others are optional.'
    ns['A3'] = '• Dates: use DD/MM/YYYY format (e.g. 15/06/2024)'
    ns['A4'] = '• company_name / group must match exactly with Organisation Master / Group Master. If not found, a placeholder is created.'
    ns['A5'] = '• status: COMPLETED or ONGOING'
    ns['A6'] = '• for_closure: Yes or No'
    ns['A7'] = '• dpsu_psu_private_capf: DPSU / PSU / PRIVATE / SERVICES / CAPF'
    ns['A8'] = '• workflow_stage: INQUIRY / NTR_CREATED / BQ_ISSUED / PAYMENT_RCVD / TRIAL_DONE / CLOSED (etc.)'
    ns['A9'] = '• If acn_no already exists in the DB, that record will be UPDATED with the new values.'
    ns['A10']= '• Max 3000 rows per import.'
    for r in range(1, 11):
        ns[f'A{r}'].font = __import__('openpyxl').styles.Font(size=10)
    ns.column_dimensions['A'].width = 90

    buf = BytesIO()
    wb.save(buf); buf.seek(0)
    resp = HttpResponse(buf, content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    resp['Content-Disposition'] = 'attachment; filename="eDW_import_template.xlsx"'
    return resp


@login_required
def download_template_etot(request):
    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    _make_excel_template(ws, ETOT_COLUMNS, 'eTOT Import')
    ns = wb.create_sheet('Instructions')
    ns['A1'] = 'eTOT Bulk Import — Instructions'
    ns['A2'] = '• tot_file_no and product_technology are required.'
    ns['A3'] = '• Dates: DD/MM/YYYY'
    ns['A4'] = '• latot_no must be unique across all records. If given, it is used as the lookup key for upsert.'
    ns['A5'] = '• ttd_no must also be unique. Leave blank if not yet assigned.'
    ns['A6'] = '• stage: INITIATED / TNF / EOI / CEC / TAC / LAToT / TTD / COMPLETED / TERMINATED'
    ns['A7'] = '• technology_category: A or B'
    ns['A8'] = '• Max 3000 rows per import.'
    ns.column_dimensions['A'].width = 90

    buf = BytesIO()
    wb.save(buf); buf.seek(0)
    resp = HttpResponse(buf, content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    resp['Content-Disposition'] = 'attachment; filename="eTOT_import_template.xlsx"'
    return resp


@login_required
def download_template_eiig(request):
    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    _make_excel_template(ws, EIIG_COLUMNS, 'eIIG Import')
    ns = wb.create_sheet('Instructions')
    ns['A1'] = 'eIIG Bulk Import — Instructions'
    ns['A2'] = '• date_of_visit and firm_name are required.'
    ns['A3'] = '• Dates: DD/MM/YYYY'
    ns['A4'] = '• visit_id: leave blank to auto-generate (DCMM/I2G/YYYY-YY/XXXX format).'
    ns['A5'] = '• If visit_id is given and already exists, that visit is UPDATED.'
    ns['A6'] = '• firm_state: 2-letter Indian state code (e.g. PB, DL, MH, HR)'
    ns['A7'] = '• company_category: INDUSTRY / GOVERNMENT / RESEARCH / INDIVIDUAL / OTHER'
    ns['A8'] = '• Up to 5 visitors per row. Use visitor_1_name, visitor_2_name … visitor_5_name.'
    ns['A9'] = '• Max 3000 rows per import.'
    ns.column_dimensions['A'].width = 90

    buf = BytesIO()
    wb.save(buf); buf.seek(0)
    resp = HttpResponse(buf, content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    resp['Content-Disposition'] = 'attachment; filename="eIIG_import_template.xlsx"'
    return resp
