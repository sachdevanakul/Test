"""
eDW Module — Deposit Work Views
Complete workflow: Inquiry → NTR → Feasibility → BQ → Payment → 
ACN Request → ACN Received → Trial → Report → JCC → Final Report → Closure
Every stage is linked to one or more Daks.
"""

from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.http import HttpResponse, JsonResponse
from django.db.models import Q, Sum, Count, Avg
from django.db import transaction
from django.utils import timezone
from .models import (
    eDW, eDWDakLink, eDWNTR, eDWBQ,
    OrganizationMaster, OrganizationTypeMaster, GroupMaster,
    DakMaster, DakPartyMapping, DakGroupMapping
)
from .forms import eDWForm
import pandas as pd
from io import BytesIO
from decimal import Decimal


# ─────────────────────────────────────────────────────────────────────────────
# HELPER: Auto-populate eDW from linked Dak
# When a dak is linked as the initial inquiry, pull sender org/group from it
# ─────────────────────────────────────────────────────────────────────────────

def _sync_edw_from_dak(edw_obj, dak_obj):
    """Pull sender org, group, and date from inquiry dak into eDW record."""
    changed = False
    try:
        if not edw_obj.company_name_id:
            sender = (DakPartyMapping.objects
                      .filter(dak=dak_obj, party_role__role_code='SENDER')
                      .select_related('organization', 'person__organization')
                      .first())
            if sender:
                org = sender.organization or (
                    sender.person.organization if sender.person else None
                )
                if org:
                    edw_obj.company_name_id = org.id
                    changed = True

        if not edw_obj.group_id:
            grp = (DakGroupMapping.objects.filter(dak=dak_obj)
                   .values_list('group_id', flat=True).first())
            if grp:
                edw_obj.group_id = grp
                changed = True

        if not edw_obj.acn_date and dak_obj.issue_date:
            edw_obj.acn_date = dak_obj.issue_date
            changed = True
    except Exception:
        pass
    return changed


# ─────────────────────────────────────────────────────────────────────────────
# HELPER: Graph context for eDW form tabs
# ─────────────────────────────────────────────────────────────────────────────

def _edw_graph_context():
    qs = eDW.objects.all()
    fin = qs.aggregate(
        avg_paid=Avg('amount_paid_by_firm'),
        avg_acn=Avg('amount_reflected_in_acn'),
        avg_utilized=Avg('amount_utilized'),
        avg_balance=Avg('balance_unspent_amount'),
        total_utilized=Sum('amount_utilized'),
        total_balance=Sum('balance_unspent_amount'),
    )
    return {
        'edw_status_counts': {
            'active':  qs.filter(status='ONGOING').count(),
            'closed':  qs.filter(status='COMPLETED').count(),
            'pending': qs.filter(status='PENDING').count(),
        },
        'edw_closure_counts': {
            'closure': qs.filter(for_closure=True).count(),
            'active':  qs.filter(for_closure=False).count(),
        },
        'edw_category_counts': {
            'dpsu':    qs.filter(dpsu_psu_private_capf='DPSU').count(),
            'psu':     qs.filter(dpsu_psu_private_capf='PSU').count(),
            'private': qs.filter(dpsu_psu_private_capf='PRIVATE').count(),
            'capf':    qs.filter(dpsu_psu_private_capf='CAPF').count(),
            'msme':    qs.filter(dpsu_psu_private_capf='MSME').count(),
        },
        'edw_fin': {k: float(v or 0) for k, v in fin.items()},
        'edw_bq':  {
            'shared':  qs.exclude(bq_shared_to_firm_date__isnull=True).count(),
            'pending': qs.filter(bq_shared_to_firm_date__isnull=True).count(),
        },
        'edw_mro': {
            'issued':  qs.exclude(mro_number='').exclude(mro_number__isnull=True).count(),
            'pending': qs.filter(Q(mro_number='') | Q(mro_number__isnull=True)).count(),
        },
        'edw_trial': {
            'planned':   int(qs.aggregate(s=Sum('no_of_test_samples_planned'))['s'] or 0),
            'conducted': int(qs.aggregate(s=Sum('no_of_test_conducted'))['s'] or 0),
        },
        'edw_report': {
            'dispatched': qs.exclude(dispatch_date__isnull=True).count(),
            'pending':    qs.filter(dispatch_date__isnull=True).count(),
        },
        # Workflow stage counts
        'edw_workflow': {
            stage: qs.filter(workflow_stage=stage).count()
            for stage, _ in eDW.WORKFLOW_STAGE_CHOICES
        } if hasattr(eDW, 'WORKFLOW_STAGE_CHOICES') else {},
    }


# ─────────────────────────────────────────────────────────────────────────────
# HELPER: Build dak auto-link from a stage dak
# ─────────────────────────────────────────────────────────────────────────────

def _link_dak_to_edw(edw_obj, dak, stage, user, notes=''):
    """Link a dak to an eDW record at a specific workflow stage."""
    try:
        obj, created = eDWDakLink.objects.get_or_create(
            edw=edw_obj, dak=dak, stage=stage,
            defaults={'linked_by': user, 'notes': notes}
        )
        return obj, created
    except Exception:
        return None, False


# ─────────────────────────────────────────────────────────────────────────────
# DASHBOARD
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def edw_dashboard(request):

    # ── Module access guard ──────────────────────────────────────
    if not request.user.is_staff:
        from .models import UserProfile
        try:
            profile = request.user.profile
        except UserProfile.DoesNotExist:
            profile = UserProfile.objects.create(user=request.user)
        if not getattr(profile, 'can_access_edw', False):
            from django.contrib import messages as _msg
            _msg.error(request, 'You do not have permission to access this module.')
            return redirect('daks:home')
    # ─────────────────────────────────────────────────────────────
    qs = (eDW.objects.all()
          .select_related('company_name', 'group', 'created_by', 'dak')
          .prefetch_related('dak_links', 'bqs')
          .order_by('-created_at'))

    search = request.GET.get('search', '').strip()
    if search:
        qs = qs.filter(
            Q(acn_no__icontains=search) |
            Q(company_name__org_name__icontains=search) |
            Q(rdr_register_number__icontains=search) |
            Q(trial_title__icontains=search)
        )
    if request.GET.get('status'):
        qs = qs.filter(status=request.GET['status'])
    if request.GET.get('group'):
        qs = qs.filter(group_id=request.GET['group'])
    if request.GET.get('stage'):
        qs = qs.filter(workflow_stage=request.GET['stage'])

    stats = qs.aggregate(
        total_paid=Sum('amount_paid_by_firm'),
        total_utilized=Sum('amount_utilized'),
        total_balance=Sum('balance_unspent_amount'),
        total_records=Count('id'),
    )

    paginator = Paginator(qs, 50)
    try:
        page_obj = paginator.page(request.GET.get('page', 1))
    except (PageNotAnInteger, EmptyPage):
        page_obj = paginator.page(1)

    # Use the full unfiltered queryset for global status counts so the stat
    # cards always reflect reality regardless of the current filter.
    _all_edw = eDW.objects.all()
    ongoing_count   = _all_edw.filter(status='ONGOING').count()
    completed_count = _all_edw.filter(status='COMPLETED').count()

    return render(request, 'daks/edw_dashboard.html', {
        'page_obj':       page_obj,
        'total_count':    stats['total_records'] or 0,
        'ongoing_count':  ongoing_count,
        'completed_count': completed_count,
        'search_query':   search,
        'status_filter':  request.GET.get('status', ''),
        'group_filter':   request.GET.get('group', ''),
        'stage_filter':   request.GET.get('stage', ''),
        'groups':         list(GroupMaster.objects.filter(is_active=True).values('id', 'group_name')),
        'total_paid':     stats['total_paid'] or Decimal('0'),
        'total_utilized': stats['total_utilized'] or Decimal('0'),
        'total_balance':  stats['total_balance'] or Decimal('0'),
        'workflow_stages': getattr(eDW, 'WORKFLOW_STAGE_CHOICES', []),
    })


# ─────────────────────────────────────────────────────────────────────────────
# DETAIL
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def edw_detail(request, public_id):
    record = get_object_or_404(
        eDW.objects.select_related(
            'company_name', 'group', 'created_by', 'dak'
        ).prefetch_related(
            'dak_links__dak', 'dak_links__linked_by',
            'bqs', 'ntr'
        ),
        public_id=public_id
    )
    # All daks linked at any stage — for the workflow timeline
    dak_links = record.dak_links.all().select_related('dak', 'linked_by').order_by('linked_at')

    # NTR if exists
    ntr = getattr(record, 'ntr', None)

    # BQs
    bqs = record.bqs.all().order_by('-created_at')

    # Pending daks from dak_list that mention this firm — for easy linking
    firm_daks = []
    if record.company_name:
        firm_daks = (DakMaster.objects.filter(
            is_active=True,
            dak_direction='INCOMING',
        ).filter(
            Q(dak_parties__organization=record.company_name) |
            Q(dak_parties__person__organization=record.company_name)
        ).exclude(
            edw_links__edw=record
        ).distinct().order_by('-created_on')[:20])

    return render(request, 'daks/edw_detail.html', {
        'record':    record,
        'dak_links': dak_links,
        'ntr':       ntr,
        'bqs':       bqs,
        'firm_daks': firm_daks,
        'stage_choices': eDWDakLink.STAGE_CHOICES,
    })


# ─────────────────────────────────────────────────────────────────────────────
# CREATE — when creating from a Dak, auto-fill everything
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def edw_create(request):
    prefill_dak = None
    dak_id = request.GET.get('dak') or request.POST.get('dak_id')
    if dak_id:
        try:
            prefill_dak = DakMaster.objects.select_related(
                'dak_category', 'thread'
            ).get(pk=dak_id)
        except DakMaster.DoesNotExist:
            pass

    if request.method == 'POST':
        form = eDWForm(request.POST)
        if form.is_valid():
            with transaction.atomic():
                edw = form.save(commit=False)
                edw.created_by = request.user
                edw.workflow_stage = 'INQUIRY'

                # Link the inquiry dak
                if prefill_dak:
                    edw.dak = prefill_dak
                    _sync_edw_from_dak(edw, prefill_dak)

                edw.save()

                # Auto-create eDWDakLink for the inquiry stage
                if prefill_dak:
                    _link_dak_to_edw(edw, prefill_dak, 'INQUIRY', request.user,
                                     'Initial inquiry dak — auto-linked on eDW creation')

                # Auto-create NTR
                if prefill_dak and edw.group:
                    year = timezone.now().year
                    ntr_num, seq = eDWNTR.generate_number(edw.group, year)
                    eDWNTR.objects.create(
                        edw=edw,
                        ntr_number=ntr_num,
                        sequence_no=seq,
                        year=year,
                        inquiry_dak=prefill_dak,
                        ntr_date=timezone.now().date(),
                        created_by=request.user,
                        status='DRAFT',
                    )
                    edw.workflow_stage = 'NTR_CREATED'
                    edw.save(update_fields=['workflow_stage'])

            messages.success(request,
                f'eDW record {edw.acn_no} created. NTR auto-generated.')
            return redirect('daks:edw_detail', public_id=edw.public_id)
    else:
        initial = {}
        if prefill_dak:
            initial['dak'] = prefill_dak.pk
            # Auto-fill org from dak sender
            sender = (DakPartyMapping.objects
                      .filter(dak=prefill_dak, party_role__role_code='SENDER')
                      .select_related('organization', 'person__organization')
                      .first())
            if sender:
                org = sender.organization or (
                    sender.person.organization if sender.person else None)
                if org:
                    initial['company_name'] = org.pk
            # Auto-fill group
            grp = (DakGroupMapping.objects.filter(dak=prefill_dak)
                   .values_list('group_id', flat=True).first())
            if grp:
                initial['group'] = grp
            # Auto-fill date from dak issue date
            initial['acn_date'] = prefill_dak.issue_date

        form = eDWForm(initial=initial)

    ctx = {
        'form':        form,
        'title':       'Create eDW Record',
        'prefill_dak': prefill_dak,
    }
    ctx.update(_edw_graph_context())
    return render(request, 'daks/edw_form.html', ctx)


# ─────────────────────────────────────────────────────────────────────────────
# EDIT
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def edw_edit(request, public_id):
    record = get_object_or_404(eDW, public_id=public_id)

    # Prevent editing closed records
    if record.is_closed and not request.user.is_superuser:
        messages.error(request, 'This eDW record is closed and cannot be edited.')
        return redirect('daks:edw_detail', public_id=public_id)

    if request.method == 'POST':
        form = eDWForm(request.POST, instance=record)
        if form.is_valid():
            with transaction.atomic():
                edw = form.save(commit=False)
                if edw.dak_id:
                    _sync_edw_from_dak(edw, edw.dak)
                edw.save()
            messages.success(request, f'eDW record {record.acn_no} updated.')
            return redirect('daks:edw_detail', public_id=record.public_id)
    else:
        form = eDWForm(instance=record)

    ctx = {
        'form':   form,
        'title':  f'Edit eDW — {record.acn_no}',
        'record': record,
    }
    ctx.update(_edw_graph_context())
    return render(request, 'daks/edw_form.html', ctx)


# ─────────────────────────────────────────────────────────────────────────────
# LINK DAK TO EDW WORKFLOW STAGE (AJAX)
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def edw_link_dak(request, public_id):
    """Link any existing dak to an eDW record at a specific workflow stage."""
    record = get_object_or_404(eDW, public_id=public_id)

    if request.method == 'POST':
        dak_id = request.POST.get('dak_id')
        stage  = request.POST.get('stage')
        notes  = request.POST.get('notes', '')

        if not dak_id or not stage:
            messages.error(request, 'Dak and stage are required.')
            return redirect('daks:edw_detail', public_id=public_id)

        try:
            dak = DakMaster.objects.get(pk=dak_id, is_active=True)
        except DakMaster.DoesNotExist:
            messages.error(request, 'Dak not found.')
            return redirect('daks:edw_detail', public_id=public_id)

        obj, created = _link_dak_to_edw(record, dak, stage, request.user, notes)

        if created:
            # Auto-advance workflow stage
            stage_order = {
                'INQUIRY':       'INQUIRY',
                'NTR_FORWARD':   'NTR_FORWARDED',
                'FEASIBILITY':   'FEASIBLE',
                'BQ_SENT':       'BQ_ISSUED',
                'PAYMENT':       'PAYMENT_RCVD',
                'ACN_REQUEST':   'ACN_REQUESTED',
                'ACN_RECEIVED':  'ACN_RECEIVED',
                'ACN_TO_GROUP':  'ACN_RECEIVED',
                'TRIAL_REPORT':  'REPORT_RCVD',
                'JCC_DEMAND':    'JCC_DEMANDED',
                'JCC_RECEIVED':  'JCC_RECEIVED',
                'REPORT_ISSUED': 'REPORT_ISSUED',
            }
            new_stage = stage_order.get(stage)
            if new_stage and record.workflow_stage != 'CLOSED':
                record.workflow_stage = new_stage
                record.save(update_fields=['workflow_stage'])

            # Special: if this is a feasibility reply and it's the NTR forward stage,
            # update NTR status too
            if stage == 'FEASIBILITY' and hasattr(record, 'ntr') and record.ntr:
                record.ntr.feasibility_dak = dak
                record.ntr.feasibility_date = dak.issue_date or timezone.now().date()
                record.ntr.is_feasible = True
                record.ntr.status = 'FEASIBLE'
                record.ntr.save()

            messages.success(request,
                f'Dak {dak.dak_index_no} linked at stage "{obj.get_stage_display()}".')
        else:
            messages.info(request, f'Dak already linked at this stage.')

    return redirect('daks:edw_detail', public_id=public_id)


# ─────────────────────────────────────────────────────────────────────────────
# UNLINK DAK FROM EDW
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def edw_unlink_dak(request, public_id, link_pk):
    record = get_object_or_404(eDW, public_id=public_id)
    link   = get_object_or_404(eDWDakLink, pk=link_pk, edw=record)
    if request.method == 'POST':
        dak_no = link.dak.dak_index_no
        link.delete()
        messages.success(request, f'Dak {dak_no} unlinked.')
    return redirect('daks:edw_detail', public_id=public_id)


# ─────────────────────────────────────────────────────────────────────────────
# NTR MANAGEMENT (within eDW context)
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def edw_ntr_create(request, public_id):
    """Create NTR for an eDW record (if not already created)."""
    record = get_object_or_404(eDW, public_id=public_id)
    if hasattr(record, 'ntr') and record.ntr:
        messages.info(request, f'NTR {record.ntr.ntr_number} already exists for this record.')
        return redirect('daks:edw_detail', public_id=public_id)

    if request.method == 'POST':
        year    = timezone.now().year
        grp     = record.group
        if not grp:
            messages.error(request, 'Assign a Group to this eDW record before creating NTR.')
            return redirect('daks:edw_detail', public_id=public_id)

        ntr_num, seq = eDWNTR.generate_number(grp, year)
        ntr = eDWNTR.objects.create(
            edw=record,
            ntr_number=ntr_num,
            sequence_no=seq,
            year=year,
            inquiry_dak=record.dak,
            ntr_date=timezone.now().date(),
            is_feasible=request.POST.get('is_feasible', 'true') == 'true',
            feasibility_remarks=request.POST.get('remarks', ''),
            status='DRAFT',
            created_by=request.user,
        )
        record.workflow_stage = 'NTR_CREATED'
        record.save(update_fields=['workflow_stage'])
        messages.success(request, f'NTR {ntr.ntr_number} created successfully.')
    return redirect('daks:edw_detail', public_id=public_id)


@login_required
def edw_ntr_forward(request, public_id):
    """Mark NTR as forwarded to group — link the forwarding dak."""
    record = get_object_or_404(eDW, public_id=public_id)
    ntr    = get_object_or_404(eDWNTR, edw=record)

    if request.method == 'POST':
        dak_id = request.POST.get('forward_dak_id')
        if dak_id:
            try:
                dak = DakMaster.objects.get(pk=dak_id, is_active=True)
                ntr.forwarded_dak  = dak
                ntr.forwarded_date = dak.issue_date or timezone.now().date()
                ntr.status = 'FORWARDED'
                ntr.save()
                _link_dak_to_edw(record, dak, 'NTR_FORWARD', request.user,
                                 f'NTR {ntr.ntr_number} forwarded to group')
                record.workflow_stage = 'NTR_FORWARDED'
                record.save(update_fields=['workflow_stage'])
                messages.success(request, f'NTR forwarded to group via {dak.dak_index_no}.')
            except DakMaster.DoesNotExist:
                messages.error(request, 'Dak not found.')
    return redirect('daks:edw_detail', public_id=public_id)


# ─────────────────────────────────────────────────────────────────────────────
# BQ MANAGEMENT (within eDW context)
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def edw_bq_create(request, public_id):
    """Create a new BQ for an eDW record."""
    record = get_object_or_404(eDW, public_id=public_id)

    if request.method == 'POST':
        from decimal import Decimal as D
        rev = record.bqs.count() + 1
        bq  = eDWBQ.objects.create(
            edw=record,
            bq_number=f'BQ-{record.acn_no}-R{rev:02d}',
            revision_no=rev,
            total_amount=D(request.POST.get('total_amount', '0') or '0'),
            gst_amount=D(request.POST.get('gst_amount', '0') or '0'),
            bq_date=request.POST.get('bq_date') or None,
            valid_until=request.POST.get('valid_until') or None,
            description=request.POST.get('description', ''),
            status='DRAFT',
            created_by=request.user,
        )
        # Link BQ sent dak if provided
        bq_dak_id = request.POST.get('bq_dak_id')
        if bq_dak_id:
            try:
                bq_dak = DakMaster.objects.get(pk=bq_dak_id, is_active=True)
                bq.bq_dak = bq_dak
                bq.status = 'SENT'
                bq.save()
                _link_dak_to_edw(record, bq_dak, 'BQ_SENT', request.user,
                                 f'BQ {bq.bq_number} sent to firm')
                record.workflow_stage = 'BQ_ISSUED'
                record.save(update_fields=['workflow_stage'])
            except DakMaster.DoesNotExist:
                pass

        # Update NTR status
        if hasattr(record, 'ntr') and record.ntr:
            record.ntr.status = 'BQ_ISSUED'
            record.ntr.save(update_fields=['status'])

        messages.success(request, f'BQ {bq.bq_number} created.')
    return redirect('daks:edw_detail', public_id=public_id)


# ─────────────────────────────────────────────────────────────────────────────
# CLOSE DW RECORD
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def edw_close(request, public_id):
    """Mark an eDW record as closed — prevents further editing."""
    if not request.user.is_staff:
        messages.error(request, 'Only admins can close eDW records.')
        return redirect('daks:edw_detail', public_id=public_id)

    record = get_object_or_404(eDW, public_id=public_id)
    if request.method == 'POST':
        record.is_closed              = True
        record.workflow_stage         = 'CLOSED'
        record.dw_closed_on           = timezone.now().date()
        record.closure_request_sent_on= request.POST.get('closure_request_sent_on') or None
        record.te_closure_on          = request.POST.get('te_closure_on') or None
        record.te_closure_no          = request.POST.get('te_closure_no', '')
        amt = request.POST.get('treasury_deposit_amount', '0') or '0'
        from decimal import Decimal as D
        record.treasury_deposit_amount = D(amt)
        record.save()
        messages.success(request, f'eDW record {record.acn_no} closed.')
    return redirect('daks:edw_detail', public_id=public_id)


# ─────────────────────────────────────────────────────────────────────────────
# WORKFLOW STAGE API — returns available daks for a given stage
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def edw_api_daks_for_stage(request, public_id):
    """AJAX: return daks that can be linked at a given workflow stage."""
    record    = get_object_or_404(eDW, public_id=public_id)
    stage     = request.GET.get('stage', '')
    search    = request.GET.get('q', '').strip()
    direction = 'OUTGOING' if stage in (
        'NTR_FORWARD', 'BQ_SENT', 'ACN_REQUEST', 'ACN_TO_GROUP', 'JCC_DEMAND', 'REPORT_ISSUED'
    ) else 'INCOMING'

    qs = DakMaster.objects.filter(is_active=True, dak_direction=direction)
    if record.company_name:
        # For incoming: filter to daks from this firm
        # For outgoing: show all outgoing daks (sent by IIG)
        if direction == 'INCOMING':
            qs = qs.filter(
                Q(dak_parties__organization=record.company_name) |
                Q(dak_parties__person__organization=record.company_name) |
                Q(subject__icontains=record.company_name.org_name[:20])
            ).distinct()

    if search:
        qs = qs.filter(
            Q(dak_index_no__icontains=search) |
            Q(subject__icontains=search)
        )

    daks = list(qs.values('id', 'dak_index_no', 'subject', 'issue_date')
                .order_by('-created_on')[:30])
    for d in daks:
        d['issue_date'] = d['issue_date'].strftime('%d %b %Y') if d['issue_date'] else ''
        d['label'] = f"{d['dak_index_no']} — {d['subject'][:50]}"
    return JsonResponse({'daks': daks, 'direction': direction})


# ─────────────────────────────────────────────────────────────────────────────
# EXPORT
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def edw_export_excel(request):
    qs = (eDW.objects.all()
          .select_related('company_name', 'group', 'dak', 'created_by')
          .order_by('-created_at'))

    search = request.GET.get('search', '').strip()
    if search:
        qs = qs.filter(
            Q(acn_no__icontains=search) |
            Q(company_name__org_name__icontains=search) |
            Q(rdr_register_number__icontains=search)
        )
    if request.GET.get('status'):
        qs = qs.filter(status=request.GET['status'])
    if request.GET.get('group'):
        qs = qs.filter(group_id=request.GET['group'])

    def fmt(d): return d.strftime('%d-%m-%Y') if d else ''
    def money(v): return float(v) if v else ''

    data = []
    for i, r in enumerate(qs, 1):
        # Get NTR number if exists
        ntr_num = ''
        try:
            ntr_num = r.ntr.ntr_number
        except Exception:
            pass
        # Get latest BQ
        bq = r.bqs.order_by('-created_at').first()
        bq_num = bq.bq_number if bq else ''

        data.append({
            'S.No': i,
            'ACN No.': r.acn_no,
            'NTR No.': ntr_num,
            'BQ No.': bq_num,
            'Workflow Stage': r.workflow_stage if hasattr(r, 'workflow_stage') else '',
            'Company Name': r.company_name.org_name if r.company_name else '',
            'Group': r.group.group_name if r.group else '',
            'Category': r.dpsu_psu_private_capf or '',
            'Amount Paid (₹)': money(r.amount_paid_by_firm),
            'Amount in ACN (₹)': money(r.amount_reflected_in_acn),
            'Amount Utilized (₹)': money(r.amount_utilized),
            'Balance (₹)': money(r.balance_unspent_amount),
            'Final GST (₹)': money(getattr(r, 'final_gst_amount', None)),
            'GST Challan No.': getattr(r, 'gst_challan_no', '') or '',
            'JCC Number': getattr(r, 'jcc_number', '') or '',
            'Trial Report No.': r.trial_report_no or '',
            'Dispatch Date': fmt(r.dispatch_date),
            'Status': r.status,
            'DW Closed': 'Yes' if getattr(r, 'is_closed', False) else 'No',
            'Linked Dak': r.dak.dak_index_no if r.dak else '',
            'Created By': r.created_by.username if r.created_by else '',
            'Created At': fmt(r.created_at.date()) if r.created_at else '',
        })

    df = pd.DataFrame(data)
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name='eDW Records', index=False)
    output.seek(0)

    response = HttpResponse(
        output.read(),
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )
    response['Content-Disposition'] = 'attachment; filename="edw_records.xlsx"'
    return response


# ─────────────────────────────────────────────────────────────────────────────
# ADMIN-ONLY HARD DELETE
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def edw_delete(request, public_id):
    """Superuser-only: permanently delete an eDW record and all related data."""
    if not request.user.is_superuser:
        messages.error(request, 'Only superusers can delete eDW records.')
        return redirect('daks:edw_detail', public_id=public_id)

    record = get_object_or_404(eDW, public_id=public_id)

    if request.method == 'POST':
        identifier = record.acn_no
        record.delete()
        messages.success(request, f'eDW record "{identifier}" permanently deleted.')
        return redirect('daks:edw_dashboard')

    return render(request, 'daks/edw_confirm_delete.html', {'record': record})


# ─────────────────────────────────────────────────────────────────────────────
# BULK IMPORT
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def edw_bulk_import(request):
    """Admin-only: import eDW records from Excel / CSV."""
    if not request.user.is_staff:
        messages.error(request, 'Only admins can perform bulk imports.')
        return redirect('daks:edw_dashboard')

    if request.method != 'POST':
        return render(request, 'daks/edw_bulk_import.html', {})

    import_file = request.FILES.get('import_file')
    if not import_file:
        messages.error(request, 'Please select a file.')
        return render(request, 'daks/edw_bulk_import.html', {})

    ext = import_file.name.lower().split('.')[-1]
    try:
        import pandas as pd
        from io import BytesIO
        from django.utils import timezone as tz
        from decimal import Decimal, InvalidOperation

        if ext == 'csv':
            df = pd.read_csv(import_file, dtype=str)
        elif ext in ('xlsx', 'xls'):
            df = pd.read_excel(BytesIO(import_file.read()), dtype=str)
        else:
            messages.error(request, 'Only CSV and Excel files are supported.')
            return render(request, 'daks/edw_bulk_import.html', {})

        df = df.where(pd.notnull(df), None)
        df.columns = df.columns.str.lower().str.strip().str.replace(' ', '_')

        required = {'acn_no', 'company_name'}
        missing = required - set(df.columns)
        if missing:
            messages.error(request, f'Missing required columns: {", ".join(missing)}')
            return render(request, 'daks/edw_bulk_import.html', {})

        def parse_date(val):
            if not val:
                return None
            try:
                return pd.to_datetime(val).date()
            except Exception:
                return None

        def parse_decimal(val):
            if not val:
                return None
            try:
                return Decimal(str(val).replace(',', '').strip())
            except InvalidOperation:
                return None

        success = skipped = 0
        errors = []

        for idx, row in df.iterrows():
            rn = idx + 2
            try:
                acn_no = str(row.get('acn_no') or '').strip()
                if not acn_no:
                    errors.append(f'Row {rn}: Empty ACN No. — skipped.')
                    skipped += 1
                    continue

                if eDW.objects.filter(acn_no=acn_no).exists():
                    errors.append(f'Row {rn}: ACN No. "{acn_no}" already exists — skipped.')
                    skipped += 1
                    continue

                # Resolve company_name (get or create OrganizationMaster)
                company = None
                company_val = str(row.get('company_name') or '').strip()
                if company_val:
                    existing = OrganizationMaster.objects.filter(org_name__iexact=company_val).first()
                    if existing:
                        company = existing
                    else:
                        # New organization — org_type is required (NOT NULL) on
                        # OrganizationMaster, but the import file has no type
                        # column. Fall back to a generic "Unspecified" type
                        # (created once, reused after) instead of crashing or
                        # picking some arbitrary existing type at random.
                        fallback_type, _ = OrganizationTypeMaster.objects.get_or_create(
                            type_name='Unspecified'
                        )
                        company = OrganizationMaster.objects.create(
                            org_name=company_val,
                            org_type=fallback_type,
                            created_by=request.user,
                            source='IMPORT',
                        )

                # Resolve group
                group = None
                group_val = str(row.get('group') or '').strip()
                if group_val:
                    group = GroupMaster.objects.filter(
                        group_name__iexact=group_val
                    ).first() or GroupMaster.objects.filter(
                        group_code__iexact=group_val
                    ).first()

                status_val = str(row.get('status') or 'ONGOING').strip().upper()
                if status_val not in ('ONGOING', 'COMPLETED'):
                    status_val = 'ONGOING'

                eDW.objects.create(
                    acn_no=acn_no,
                    company_name=company,
                    group=group,
                    status=status_val,
                    acn_date=parse_date(row.get('acn_date')),
                    rdr_register_number=str(row.get('rdr_register_number') or '').strip() or None,
                    trial_title=str(row.get('trial_title') or '').strip() or None,
                    amount_paid_by_firm=parse_decimal(row.get('amount_paid_by_firm')),
                    amount_utilized=parse_decimal(row.get('amount_utilized')),
                    balance_unspent_amount=parse_decimal(row.get('balance_unspent_amount')),
                    remarks=str(row.get('remarks') or '').strip() or None,
                    created_by=request.user,
                )
                success += 1

            except Exception as e:
                errors.append(f'Row {rn}: {str(e)} — skipped.')
                skipped += 1

        return render(request, 'daks/edw_bulk_import.html', {
            'done': True, 'success': success, 'skipped': skipped,
            'errors': errors[:50], 'total': success + skipped,
        })

    except Exception as e:
        messages.error(request, f'Import failed: {str(e)}')
        return render(request, 'daks/edw_bulk_import.html', {})
