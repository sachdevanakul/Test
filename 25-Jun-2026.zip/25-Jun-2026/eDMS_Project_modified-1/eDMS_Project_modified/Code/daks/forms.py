from django import forms
from django.core.exceptions import ValidationError
from django.utils import timezone
from .models import *
from .cache_utils import get_cached_dropdowns  # ← CHANGE THIS LINE

class QuickOrganizationForm(forms.ModelForm):
    """Quick form to create new organization during dak entry"""
    
    class Meta:
        model = OrganizationMaster
        fields = ['org_name', 'org_type', 'phone', 'email']
        widgets = {
            'org_name': forms.TextInput(attrs={'class': 'form-control'}),
            'org_type': forms.Select(attrs={'class': 'form-select'}),
            'phone': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
        }
    
    def __init__(self, *args, **kwargs):
        self.request = kwargs.pop('request', None)
        super().__init__(*args, **kwargs)
        self.fields['org_type'].queryset = OrganizationTypeMaster.objects.filter(is_active=True)
        self.fields['phone'].required = False
        self.fields['email'].required = False


class QuickPersonForm(forms.ModelForm):
    """Quick form to create new person during dak entry"""
    
    class Meta:
        model = PersonMaster
        fields = ['person_name', 'organization', 'group', 'designation', 'email', 'mobile_no']
        widgets = {
            'person_name': forms.TextInput(attrs={'class': 'form-control'}),
            'organization': forms.Select(attrs={'class': 'form-select'}),
            'group': forms.Select(attrs={'class': 'form-select'}),
            'designation': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'mobile_no': forms.TextInput(attrs={'class': 'form-control'}),
        }
    
    def __init__(self, *args, **kwargs):
        self.request = kwargs.pop('request', None)
        super().__init__(*args, **kwargs)
        self.fields['organization'].queryset = OrganizationMaster.objects.filter(is_active=True)
        self.fields['organization'].required = False
        self.fields['group'].queryset = GroupMaster.objects.filter(is_active=True)
        self.fields['group'].required = False
        self.fields['designation'].required = False
        self.fields['email'].required = False
        self.fields['mobile_no'].required = False


class IncomingDakForm(forms.ModelForm):
    """Incoming dak form — field order: category, nature, sender org/person, subject, issue_date, receipt_date"""

    # Sender organization — "Create New…" appended as last option via __init__
    sender_org = forms.ModelChoiceField(
        queryset=OrganizationMaster.objects.none(),
        required=False,
        empty_label='— Select Organization —',
        widget=forms.Select(attrs={'class': 'form-select', 'id': 'id_sender_org'})
    )

    # Sender person — filtered by org via JS; "Create New…" as last option
    sender_person = forms.ModelChoiceField(
        queryset=PersonMaster.objects.none(),
        required=False,
        empty_label='— Select Person —',
        widget=forms.Select(attrs={'class': 'form-select', 'id': 'id_sender_person'})
    )

    # Marked To person
    marked_to_person = forms.ModelChoiceField(
        queryset=PersonMaster.objects.filter(is_active=True),
        required=False,
        empty_label='— Select Person —',
        widget=forms.Select(attrs={'class': 'form-select', 'id': 'id_marked_to_person'})
    )

    # Continue an existing thread (same correspondence) instead of always
    # starting a new one. Left blank = start a new thread.
    thread = forms.ModelChoiceField(
        queryset=DakThread.objects.none(),
        required=False,
        empty_label='— Start a New Thread —',
        widget=forms.Select(attrs={'class': 'form-select', 'id': 'id_thread_incoming'})
    )

    # Which specific dak (if any) this one is a reply to. Scoped to the
    # selected thread via JS — see api_thread_daks.
    reply_dak = forms.ModelChoiceField(
        queryset=DakMaster.objects.none(),
        required=False,
        empty_label='— Not a reply to a specific dak —',
        widget=forms.Select(attrs={'class': 'form-select', 'id': 'id_reply_dak_incoming'})
    )

    class Meta:
        model = DakMaster
        fields = ['dak_category', 'nature', 'subject', 'issue_date', 'receipt_date', 'tbrl_diary_no', 'tbrl_date', 'file_location', 'reply_file_location', 'reply_due_date']
        widgets = {
            'dak_category': forms.Select(attrs={'class': 'form-select'}),
            'nature': forms.Select(attrs={'class': 'form-select'}),
            'subject': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'issue_date': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'receipt_date': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'tbrl_diary_no': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'TBRL Diary No. (optional)'}),
            'tbrl_date': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'file_location': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'File location (optional)'}),
            'reply_file_location': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Reply file location (optional)'}),
            'reply_due_date': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
        }

    def __init__(self, *args, **kwargs):
        self.request = kwargs.pop('request', None)
        super().__init__(*args, **kwargs)
        self.fields['dak_category'].queryset = DakCategoryMaster.objects.filter(is_active=True)
        self.fields['nature'].queryset = DakNatureMaster.objects.filter(is_active=True)
        self.fields['nature'].required = False

        orgs = list(OrganizationMaster.objects.filter(is_active=True).values_list('pk', 'org_name'))
        # Append sentinel value for "Create New Organization"
        CREATE_ORG_SENTINEL = 'new'
        self.fields['sender_org'].queryset = OrganizationMaster.objects.filter(is_active=True)
        self.fields['sender_org'].widget.choices = (
            [('', '— Select Organization —')] +
            [(str(pk), name) for pk, name in orgs] +
            [(CREATE_ORG_SENTINEL, '➕ Create New Organization…')]
        )

        persons = list(PersonMaster.objects.filter(is_active=True).values_list('pk', 'person_name'))
        CREATE_PERSON_SENTINEL = 'new'
        self.fields['sender_person'].queryset = PersonMaster.objects.filter(is_active=True)
        self.fields['sender_person'].widget.choices = (
            [('', '— Select Person —')] +
            [(str(pk), name) for pk, name in persons] +
            [(CREATE_PERSON_SENTINEL, '➕ Create New Person…')]
        )

        for f in ['tbrl_diary_no','tbrl_date','file_location','reply_file_location','reply_due_date']:
            if f in self.fields:
                self.fields[f].required = False
        if not self.instance.pk:
            self.initial['receipt_date'] = timezone.now().date()

        self.fields['thread'].queryset = DakThread.objects.filter(status='OPEN').order_by('-last_activity')
        # Reply_dak choices: any active dak, newest first. JS narrows the
        # visible options to the selected thread; this queryset is just the
        # safety net used for server-side validation of whatever gets posted.
        self.fields['reply_dak'].queryset = DakMaster.objects.filter(is_active=True).order_by('-issue_date')


class OutgoingDakForm(forms.ModelForm):
    """Outgoing dak form — order: category, nature, thread, letter_no, subject, issue_date, reply_type, receiver"""

    REPLY_TYPE_CHOICES = [
        ('NONE', 'New Outgoing (Not a Reply)'),
        ('COMPANY', 'Replying to a Company'),
        ('GOVT', 'Replying to a Govt Body'),
    ]

    reply_type = forms.ChoiceField(
        choices=REPLY_TYPE_CHOICES,
        initial='NONE',
        widget=forms.RadioSelect(attrs={'class': 'form-check-input'}),
        required=False,
    )

    receiver_org = forms.ModelChoiceField(
        queryset=OrganizationMaster.objects.none(),
        required=False,
        empty_label='— Select Organization —',
        widget=forms.Select(attrs={'class': 'form-select', 'id': 'id_receiver_org'})
    )

    receiver_person = forms.ModelChoiceField(
        queryset=PersonMaster.objects.none(),
        required=False,
        empty_label='— Select Person —',
        widget=forms.Select(attrs={'class': 'form-select', 'id': 'id_receiver_person'})
    )

    # Which specific dak (if any) this outgoing dak is a reply to. Scoped
    # to the selected thread via JS — see api_thread_daks.
    reply_dak = forms.ModelChoiceField(
        queryset=DakMaster.objects.none(),
        required=False,
        empty_label='— Not a reply to a specific dak —',
        widget=forms.Select(attrs={'class': 'form-select', 'id': 'id_reply_dak_outgoing'})
    )

    class Meta:
        model = DakMaster
        fields = ['dak_category', 'nature', 'thread', 'letter_no', 'subject', 'issue_date']
        widgets = {
            'dak_category': forms.Select(attrs={'class': 'form-select'}),
            'nature': forms.Select(attrs={'class': 'form-select'}),
            'thread': forms.Select(attrs={'class': 'form-select', 'id': 'id_thread'}),
            'letter_no': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'e.g. DCMM/IIG/2026/123  (optional)',
            }),
            'subject': forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'id': 'id_subject'}),
            'issue_date': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
        }

    def __init__(self, *args, **kwargs):
        self.request = kwargs.pop('request', None)
        super().__init__(*args, **kwargs)
        self.fields['dak_category'].queryset = DakCategoryMaster.objects.filter(is_active=True)
        self.fields['nature'].queryset = DakNatureMaster.objects.filter(is_active=True)
        self.fields['nature'].required = False
        self.fields['thread'].queryset = DakThread.objects.filter(status='OPEN')
        self.fields['thread'].required = False
        self.fields['letter_no'].required = False

        # Receiver org with "Create New…" at bottom
        orgs = list(OrganizationMaster.objects.filter(is_active=True).values_list('pk', 'org_name'))
        self.fields['receiver_org'].queryset = OrganizationMaster.objects.filter(is_active=True)
        self.fields['receiver_org'].widget.choices = (
            [('', '— Select Organization —')] +
            [(str(pk), name) for pk, name in orgs] +
            [('new', '➕ Create New Organization…')]
        )

        persons = list(PersonMaster.objects.filter(is_active=True).values_list('pk', 'person_name'))
        self.fields['receiver_person'].queryset = PersonMaster.objects.filter(is_active=True)
        self.fields['receiver_person'].widget.choices = (
            [('', '— Select Person —')] +
            [(str(pk), name) for pk, name in persons] +
            [('new', '➕ Create New Person…')]
        )

        if not self.instance.pk:
            self.initial['issue_date'] = timezone.now().date()
            self.initial['reply_type'] = 'NONE'

        self.fields['reply_dak'].queryset = DakMaster.objects.filter(is_active=True).order_by('-issue_date')


class DakSearchForm(forms.Form):
    """Form for searching daks"""
    
    query = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Search...'})
    )
    
    date_from = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={'class': 'form-control', 'type': 'date'})
    )
    
    date_to = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={'class': 'form-control', 'type': 'date'})
    )
    
    direction = forms.ChoiceField(
        required=False,
        choices=[('', 'All')] + DakMaster.DAK_DIRECTION_CHOICES,
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    
    category = forms.ModelChoiceField(
        required=False,
        queryset=DakCategoryMaster.objects.filter(is_active=True),
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    
    nature = forms.ModelChoiceField(
        required=False,
        queryset=DakNatureMaster.objects.filter(is_active=True),
        widget=forms.Select(attrs={'class': 'form-select'})
    )
# eDW Form
class eDWForm(forms.ModelForm):
    class Meta:
        model = eDW
        fields = '__all__'
        exclude = ['created_by', 'created_at', 'updated_at', 'balance_unspent_amount']
        widgets = {
            'acn_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'bq_shared_to_firm_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'firm_payment_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'testing_changes_receipt_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'emro_payment_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'mro_outgoing_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'mro_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'trial_tentative_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'account_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'te_number_outgoing_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'te_number_incoming_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'report_received_from_group': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'trial_report_issued_on': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'dispatch_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'speed_post_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'gst_paid_on_rcm_basis_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'remarks': forms.Textarea(attrs={'rows': 3, 'class': 'form-control'}),
            'company_name': forms.Select(attrs={'class': 'form-select'}),
            'group': forms.Select(attrs={'class': 'form-select'}),
            'intimation_acn_to_group': forms.Select(attrs={'class': 'form-select'}),
            'dpsu_psu_private_capf': forms.Select(attrs={'class': 'form-select'}),
            'status': forms.Select(attrs={'class': 'form-select'}),
            'for_closure': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Fix: Order by existing columns instead of default ordering
        self.fields['group'].queryset = GroupMaster.objects.filter(is_active=True).order_by('group_name')
        self.fields['company_name'].queryset = OrganizationMaster.objects.filter(is_active=True).order_by('org_name')

# ── eTOT Form ────────────────────────────────────────────────────────────────
class eTOTForm(forms.ModelForm):

    DATE_WIDGET = lambda: forms.DateInput(attrs={'type': 'date', 'class': 'form-control'})

    class Meta:
        model = eTOT
        exclude = [
            'created_by', 'created_at', 'updated_at',
            'total_no_of_awarded_licenses', 'no_of_available_licensee',
        ]
        widgets = {
            # Identification
            'product_technology':       forms.TextInput(attrs={'class': 'form-control'}),
            'tot_file_no':              forms.TextInput(attrs={'class': 'form-control'}),
            'technology_category':      forms.Select(attrs={'class': 'form-select'}),
            'stage':                    forms.Select(attrs={'class': 'form-select'}),
            'remarks':                  forms.Textarea(attrs={'rows': 3, 'class': 'form-control'}),
            # Stakeholders
            'technical_group':          forms.Select(attrs={'class': 'form-select'}),
            'point_of_contact':         forms.Select(attrs={'class': 'form-select'}),
            'licensee_company':         forms.Select(attrs={'class': 'form-select'}),
            'licensee_name':            forms.TextInput(attrs={'class': 'form-control'}),
            'licensee_address':         forms.Textarea(attrs={'rows': 2, 'class': 'form-control'}),
            # Counts
            'no_of_licenses_approved':      forms.NumberInput(attrs={'class': 'form-control', 'min': 0}),
            'additional_no_of_licenses':    forms.NumberInput(attrs={'class': 'form-control', 'min': 0}),
            'licenses_awarded_to_industry': forms.NumberInput(attrs={'class': 'form-control', 'min': 0}),
            'tac1_no_of_eoi_received':      forms.NumberInput(attrs={'class': 'form-control', 'min': 0}),
            'hand_holding_support_weeks':   forms.NumberInput(attrs={'class': 'form-control', 'min': 0}),
            # Text fields
            'tnf_nom_no':                   forms.TextInput(attrs={'class': 'form-control'}),
            'defence_industrial_license_no':forms.TextInput(attrs={'class': 'form-control'}),
            'peso_license_no':              forms.TextInput(attrs={'class': 'form-control'}),
            'tac1_recommended_firms':       forms.Textarea(attrs={'rows': 2, 'class': 'form-control'}),
            'emro_no':                      forms.TextInput(attrs={'class': 'form-control'}),
            'gst_details':                  forms.TextInput(attrs={'class': 'form-control'}),
            'latot_no':                     forms.TextInput(attrs={'class': 'form-control'}),
            'latot_signed_year':            forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. 2024'}),
            'ttd_no':                       forms.TextInput(attrs={'class': 'form-control'}),
            'ta_certificate_no':            forms.TextInput(attrs={'class': 'form-control'}),
            'ta_certificate_validity':      forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. 3 years'}),
            # Financial
            'tot_fee_paid_by_licensee':     forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01'}),
            'royalty_fee_received':         forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01'}),
            # All date fields
            'meeting_held_on':                              forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'minute_signed_by_chairman_on':                 forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'minute_approved_by_director_on':               forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'tnf_initiated_by_group_on':                    forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'tnf_certificate_issued_by_director_on':        forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'tnf_no_allotted_by_diitm_on':                  forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'eoi_hosting_on_portal':                        forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'cec_constitution_on':                          forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'cec_meeting_held_on':                          forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'cec_report_signed_by_chairman_on':             forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'cec_min_forwarded_by_director_on':             forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'cec_recommended_by_dg_mss_on':                 forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'recommended_cec_report_to_diitm_on':           forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'cec_approved_by_dg_pc_s7_on':                  forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'tac_constitution_by_dir_dg_mss_on':            forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'defence_industrial_license_date':              forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'peso_license_date':                            forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'tac1_meeting_held_on':                         forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'tac1_report_signed_by_chairman_on':            forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'tac1_report_recommended_by_director_on':       forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'tac1_report_approved_by_dg_mss_on':            forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'tac1_report_forwarded_to_diitm_on':            forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'vetted_latot_shared_with_industry_on':         forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'signed_stamped_latot_received_on':             forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'tot_fee_paid_on':                              forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'latot_signed_on':                              forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'ttd_issued_on':                                forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'tot_absorption_request_received_on':           forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'tot_absorption_recommendation_from_group_on':  forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'director_tbrl_recommendation_for_ta_on':       forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'ta_certificate_issued_on':                     forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['technical_group'].queryset = GroupMaster.objects.filter(is_active=True).order_by('group_name')
        self.fields['point_of_contact'].queryset = PersonMaster.objects.filter(is_active=True).order_by('person_name')
        self.fields['licensee_company'].queryset = OrganizationMaster.objects.filter(is_active=True).order_by('org_name')
        # All fields optional except core identifiers
        required_fields = ['tot_file_no', 'product_technology']
        for field in self.fields:
            if field not in required_fields:
                self.fields[field].required = False


class eTOTDakLinkForm(forms.ModelForm):
    """Form to link a Dak to an eTOT record"""
    class Meta:
        model = eTOTDakLink
        fields = ['dak', 'link_type', 'notes']
        widgets = {
            'dak':       forms.Select(attrs={'class': 'form-select'}),
            'link_type': forms.Select(attrs={'class': 'form-select'}),
            'notes':     forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Optional notes...'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['dak'].queryset = DakMaster.objects.filter(is_active=True).order_by('-created_on')
        self.fields['notes'].required = False


# ── eIIG Forms ───────────────────────────────────────────────────────────────

class eIIGVisitForm(forms.ModelForm):

    # Sub-category choices grouped by category — JS will filter dynamically
    SUBCATEGORY_CHOICES = [('', '— Select Sub Category —')] + eIIGVisit.SUBCATEGORY_CHOICES

    class Meta:
        model = eIIGVisit
        fields = [
            'date_of_visit', 'firm_name', 'firm_address', 'firm_state',
            'company_category', 'company_sub_category',
            'purpose_of_visit', 'feedback', 'remarks',
        ]
        widgets = {
            'date_of_visit':        forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'firm_name':            forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Full name of firm/industry'}),
            'firm_address':         forms.Textarea(attrs={'rows': 3, 'class': 'form-control', 'placeholder': 'Complete postal address'}),
            'firm_state':           forms.Select(attrs={'class': 'form-select', 'id': 'id_firm_state'}),
            'company_category':     forms.Select(attrs={'class': 'form-select', 'id': 'id_company_category'}),
            'company_sub_category': forms.Select(attrs={'class': 'form-select', 'id': 'id_company_sub_category'}),
            'purpose_of_visit':     forms.Textarea(attrs={'rows': 3, 'class': 'form-control', 'placeholder': 'Describe the purpose of this visit...'}),
            'feedback':             forms.Textarea(attrs={'rows': 3, 'class': 'form-control', 'placeholder': 'Visitor feedback...'}),
            'remarks':              forms.Textarea(attrs={'rows': 2, 'class': 'form-control'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from django.utils import timezone
        if not self.instance.pk:
            self.initial['date_of_visit'] = timezone.now().date()
        for field in self.fields:
            if field != 'date_of_visit' and field != 'firm_name':
                self.fields[field].required = False


class eIIGVisitorForm(forms.ModelForm):
    class Meta:
        model = eIIGVisitor
        fields = ['name', 'designation', 'mobile_1', 'mobile_2', 'email_1', 'email_2']
        widgets = {
            'name':        forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Full name'}),
            'designation': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. CEO, Manager'}),
            'mobile_1':    forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Primary mobile'}),
            'mobile_2':    forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Secondary mobile (optional)'}),
            'email_1':     forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Primary email'}),
            'email_2':     forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Secondary email (optional)'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['designation'].required = False
        self.fields['mobile_1'].required = False
        self.fields['mobile_2'].required = False
        self.fields['email_1'].required = False
        self.fields['email_2'].required = False


# Inline formset — up to 10 visitors per visit
from django.forms import inlineformset_factory

VisitorFormSet = inlineformset_factory(
    eIIGVisit,
    eIIGVisitor,
    form=eIIGVisitorForm,
    extra=1,
    min_num=1,
    validate_min=True,
    can_delete=True,
    max_num=20,
)

# ── WorkTask Form ─────────────────────────────────────────────────
class WorkTaskForm(forms.ModelForm):
    class Meta:
        model = WorkTask
        fields = ['title','description','priority','deadline','assigned_to','linked_dak']
        widgets = {
            'title': forms.TextInput(attrs={'class':'form-control'}),
            'description': forms.Textarea(attrs={'class':'form-control','rows':3}),
            'priority': forms.Select(attrs={'class':'form-select'}),
            'deadline': forms.DateInput(attrs={'class':'form-control','type':'date'}),
            'assigned_to': forms.Select(attrs={'class':'form-select'}),
            'linked_dak': forms.Select(attrs={'class':'form-select'}),
        }
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from django.contrib.auth.models import User as AuthUser
        self.fields['assigned_to'].queryset = AuthUser.objects.filter(is_active=True).order_by('username')
        self.fields['linked_dak'].queryset = DakMaster.objects.filter(is_active=True).order_by('-created_on')[:300]
        self.fields['linked_dak'].required = False
        self.fields['description'].required = False
        self.fields['deadline'].required = False


class UserCreateForm(forms.Form):
    # ── Account Details ────────────────────────────────────────
    username = forms.CharField(
        max_length=150,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. john.doe'}),
        help_text='Letters, digits and @/./+/-/_ only.'
    )
    first_name = forms.CharField(
        max_length=150, required=False,
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    last_name = forms.CharField(
        max_length=150, required=False,
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    email = forms.EmailField(
        required=False,
        widget=forms.EmailInput(attrs={'class': 'form-control'})
    )
    password = forms.CharField(
        min_length=8,
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Min. 8 characters'}),
        label='Password'
    )
    department = forms.CharField(
        max_length=120, required=False,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. R&D, Administration'}),
        label='Department'
    )

    # ── Account Flags ──────────────────────────────────────────
    is_staff = forms.BooleanField(
        required=False,
        label='Grant Admin (Staff) Access',
        help_text='Staff users can manage other users and perform bulk imports.'
    )
    is_active = forms.BooleanField(
        required=False, initial=True,
        label='Active Account'
    )

    # ── Module Access Checklist ────────────────────────────────
    can_access_incoming_dak = forms.BooleanField(
        required=False, initial=True,
        label='Incoming Dak'
    )
    can_access_edw = forms.BooleanField(
        required=False,
        label='eDW (Electronic Document Workflow)'
    )
    can_access_etot = forms.BooleanField(
        required=False,
        label='eTOT (Transfer of Technology)'
    )
    can_access_eiig = forms.BooleanField(
        required=False,
        label='eIIG (Industry Interface Group)'
    )
    can_access_reports = forms.BooleanField(
        required=False,
        label='Reports'
    )
    can_access_task = forms.BooleanField(
        required=False,
        label='Task Management'
    )

    # ── Special Permissions ────────────────────────────────────
    can_capture_photo = forms.BooleanField(
        required=False,
        label='Allow Photo / Camera Capture',
        help_text='Grants permission to use the camera for document scanning.'
    )
    can_take_screenshot = forms.BooleanField(
        required=False,
        initial=True,
        label='Allow Screenshots',
        help_text='If disabled, the user\'s screen will be blacked out when they attempt a screenshot or screen share.'
    )

    # ── Admin Notes ────────────────────────────────────────────
    notes = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 2,
                                     'placeholder': 'Internal notes about this user (not visible to them)'}),
        label='Admin Notes'
    )

    def clean_username(self):
        from django.contrib.auth.models import User as AuthUser
        uname = self.cleaned_data['username'].strip()
        if AuthUser.objects.filter(username=uname).exists():
            raise forms.ValidationError(f'Username "{uname}" is already taken.')
        return uname

    def save(self):
        """Creates and returns the User + UserProfile. Does NOT call user.save() — caller must do that."""
        from django.contrib.auth.models import User as AuthUser
        from .models import UserProfile
        d = self.cleaned_data

        user = AuthUser.objects.create(
            username=d['username'],
            first_name=d.get('first_name', ''),
            last_name=d.get('last_name', ''),
            email=d.get('email', ''),
            is_staff=d.get('is_staff', False),
            is_active=d.get('is_active', True),
        )
        user.set_password(d['password'])
        user.save()

        # The signal will have created a blank profile; update it with chosen permissions
        profile, _ = UserProfile.objects.get_or_create(user=user)
        profile.can_access_incoming_dak = d.get('can_access_incoming_dak', False)
        profile.can_access_edw          = d.get('can_access_edw', False)
        profile.can_access_etot         = d.get('can_access_etot', False)
        profile.can_access_eiig         = d.get('can_access_eiig', False)
        profile.can_access_reports      = d.get('can_access_reports', False)
        profile.can_access_task         = d.get('can_access_task', False)
        profile.can_capture_photo       = d.get('can_capture_photo', False)
        profile.can_take_screenshot     = d.get('can_take_screenshot', True)
        profile.department              = d.get('department', '')
        profile.notes                   = d.get('notes', '')
        profile.save()

        return user
