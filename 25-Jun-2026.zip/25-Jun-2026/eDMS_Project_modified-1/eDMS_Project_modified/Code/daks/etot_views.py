"""
eTOT Module — Transfer of Technology Views
"""
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.http import HttpResponse, JsonResponse
from django.db.models import Q, Count, Sum
from django.db import transaction
from .models import (
    eTOT, eTOTDakLink, GroupMaster, OrganizationMaster,
    PersonMaster, DakMaster, DakPartyMapping, DakGroupMapping
)
from .forms import eTOTForm, eTOTDakLinkForm
import pandas as pd
from io import BytesIO
from decimal import Decimal


# ─────────────────────────────────────────────────────────────────────────────
# HELPER: Build graph context data for eTOT form
# ─────────────────────────────────────────────────────────────────────────────

def _etot_graph_context():
    """
    Returns aggregated stats for all tab graphs in etot_form.html.
    All values default to 0 so the template never breaks.
    """
    qs = eTOT.objects.all()

    # Basic tab — stage counts
    stage_counts = {}
    for stage, _ in eTOT.STAGE_CHOICES:
        stage_counts[stage] = qs.filter(stage=stage).count()

    # Technology category counts
    tot_cat = {
        'A': qs.filter(technology_category='A').count(),
        'B': qs.filter(technology_category='B').count(),
    }

    # TNF tab
    tot_tnf = {
        'initiated':  qs.exclude(tnf_initiated_by_group_on__isnull=True).count(),
        'certified':  qs.exclude(tnf_certificate_issued_by_director_on__isnull=True).count(),
        'allotted':   qs.exclude(tnf_no_allotted_by_diitm_on__isnull=True).count(),
    }

    # EOI tab
    tot_eoi = {
        'published': qs.exclude(eoi_hosting_on_portal__isnull=True).count(),
        'pending':   qs.filter(eoi_hosting_on_portal__isnull=True).count(),
    }

    # CEC tab
    tot_cec = {
        'constituted': qs.exclude(cec_constitution_on__isnull=True).count(),
        'meeting':     qs.exclude(cec_meeting_held_on__isnull=True).count(),
        'signed':      qs.exclude(cec_report_signed_by_chairman_on__isnull=True).count(),
        'approved':    qs.exclude(cec_approved_by_dg_pc_s7_on__isnull=True).count(),
    }

    # TAC tab
    tot_tac = {
        'constituted': qs.exclude(tac_constitution_by_dir_dg_mss_on__isnull=True).count(),
        'meeting':     qs.exclude(tac1_meeting_held_on__isnull=True).count(),
        'approved':    qs.exclude(tac1_report_approved_by_dg_mss_on__isnull=True).count(),
        'forwarded':   qs.exclude(tac1_report_forwarded_to_diitm_on__isnull=True).count(),
    }

    # LAToT tab
    fee_agg = qs.aggregate(
        total_fee=Sum('tot_fee_paid_by_licensee'),
        total_royalty=Sum('royalty_fee_received'),
    )
    tot_latot = {
        'shared':          qs.exclude(vetted_latot_shared_with_industry_on__isnull=True).count(),
        'received':        qs.exclude(signed_stamped_latot_received_on__isnull=True).count(),
        'fee_paid':        qs.exclude(tot_fee_paid_on__isnull=True).count(),
        'signed':          qs.exclude(latot_signed_on__isnull=True).count(),
        'royalty_received': float(fee_agg['total_royalty'] or 0),
        'royalty_pending':  qs.filter(royalty_fee_received__isnull=True).count(),
    }

    # TTD tab
    tot_ttd = {
        'issued':     qs.exclude(ttd_issued_on__isnull=True).count(),
        'absorption': qs.exclude(tot_absorption_request_received_on__isnull=True).count(),
        'ta_rec':     qs.exclude(director_tbrl_recommendation_for_ta_on__isnull=True).count(),
    }

    # TA Certificate tab
    tot_ta = {
        'issued':  qs.exclude(ta_certificate_issued_on__isnull=True).count(),
        'pending': qs.filter(ta_certificate_issued_on__isnull=True).count(),
    }

    return {
        'tot_stage_counts': stage_counts,
        'tot_cat':          tot_cat,
        'tot_tnf':          tot_tnf,
        'tot_eoi':          tot_eoi,
        'tot_cec':          tot_cec,
        'tot_tac':          tot_tac,
        'tot_latot':        tot_latot,
        'tot_ttd':          tot_ttd,
        'tot_ta':           tot_ta,
    }


# ─────────────────────────────────────────────────────────────────────────────
# HELPER: Auto-populate eTOT fields from a linked DakMaster
# ─────────────────────────────────────────────────────────────────────────────

def _sync_etot_from_dak(etot_obj, dak_obj):
    changed = False

    if not etot_obj.technical_group_id:
        grp = DakGroupMapping.objects.filter(dak=dak_obj).values_list('group_id', flat=True).first()
        if grp:
            etot_obj.technical_group_id = grp
            changed = True

    if not etot_obj.licensee_company_id:
        sender = (
            DakPartyMapping.objects
            .filter(dak=dak_obj, party_role__role_code='SENDER')
            .select_related('organization', 'person__organization')
            .first()
        )
        if sender:
            org_id = (
                sender.organization_id
                or (sender.person.organization_id if sender.person else None)
            )
            if org_id:
                etot_obj.licensee_company_id = org_id
                changed = True

    if not etot_obj.meeting_held_on and dak_obj.issue_date:
        etot_obj.meeting_held_on = dak_obj.issue_date
        changed = True

    return changed


# ─────────────────────────────────────────────────────────────────────────────
# DASHBOARD
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def etot_dashboard(request):

    # ── Module access guard ──────────────────────────────────────
    if not request.user.is_staff:
        from .models import UserProfile
        try:
            profile = request.user.profile
        except UserProfile.DoesNotExist:
            profile = UserProfile.objects.create(user=request.user)
        if not getattr(profile, 'can_access_etot', False):
            from django.contrib import messages as _msg
            _msg.error(request, 'You do not have permission to access this module.')
            return redirect('daks:home')
    # ─────────────────────────────────────────────────────────────
    qs = (
        eTOT.objects.all()
        .select_related('technical_group', 'point_of_contact', 'licensee_company', 'created_by')
        .prefetch_related('dak_links')
        .order_by('-created_at')
    )

    search_query = request.GET.get('search', '').strip()
    if search_query:
        qs = qs.filter(
            Q(tot_file_no__icontains=search_query) |
            Q(product_technology__icontains=search_query) |
            Q(licensee_name__icontains=search_query) |
            Q(licensee_company__org_name__icontains=search_query) |
            Q(latot_no__icontains=search_query) |
            Q(ttd_no__icontains=search_query) |
            Q(ta_certificate_no__icontains=search_query)
        )

    stage_filter = request.GET.get('stage', '').strip()
    if stage_filter:
        qs = qs.filter(stage=stage_filter)

    group_filter = request.GET.get('group', '').strip()
    if group_filter:
        qs = qs.filter(technical_group_id=group_filter)

    category_filter = request.GET.get('category', '').strip()
    if category_filter:
        qs = qs.filter(technology_category=category_filter)

    stats = qs.aggregate(
        total=Count('id'),
        total_fee=Sum('tot_fee_paid_by_licensee'),
        total_royalty=Sum('royalty_fee_received'),
        total_licenses=Sum('total_no_of_awarded_licenses'),
    )
    stage_counts = {}
    for stage, _ in eTOT.STAGE_CHOICES:
        stage_counts[stage] = qs.filter(stage=stage).count()

    # List of (val, label, count) tuples — Django templates cannot do dict[var]
    # lookups so we flatten the data here for clean template access.
    stage_counts_list = [
        (val, label, stage_counts.get(val, 0))
        for val, label in eTOT.STAGE_CHOICES
    ]

    paginator = Paginator(qs, 50)
    try:
        page_obj = paginator.page(request.GET.get('page', 1))
    except (PageNotAnInteger, EmptyPage):
        page_obj = paginator.page(1)

    groups = list(GroupMaster.objects.filter(is_active=True).values('id', 'group_name').order_by('group_name'))

    context = {
        'page_obj': page_obj,
        'total_count': stats['total'] or 0,
        'search_query': search_query,
        'stage_filter': stage_filter,
        'group_filter': group_filter,
        'category_filter': category_filter,
        'groups': groups,
        'stage_choices': eTOT.STAGE_CHOICES,
        'stage_counts_list': stage_counts_list,
        'total_fee': stats['total_fee'] or Decimal('0'),
        'total_royalty': stats['total_royalty'] or Decimal('0'),
        'total_licenses': stats['total_licenses'] or 0,
        'stage_counts': stage_counts,
    }
    return render(request, 'daks/etot_dashboard.html', context)


# ─────────────────────────────────────────────────────────────────────────────
# DETAIL
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def etot_detail(request, public_id):
    record = get_object_or_404(
        eTOT.objects.select_related(
            'technical_group', 'point_of_contact',
            'licensee_company', 'created_by'
        ).prefetch_related('dak_links__dak'),
        public_id=public_id
    )
    link_form = eTOTDakLinkForm()
    context = {
        'record': record,
        'dak_links': record.dak_links.all().select_related('dak'),
        'link_form': link_form,
    }
    return render(request, 'daks/etot_detail.html', context)


# ─────────────────────────────────────────────────────────────────────────────
# CREATE
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def etot_create(request):
    if request.method == 'POST':
        form = eTOTForm(request.POST)
        if form.is_valid():
            with transaction.atomic():
                etot = form.save(commit=False)
                etot.created_by = request.user
                etot.save()
            messages.success(request, f'eTOT record {etot.tot_file_no} created successfully!')
            return redirect('daks:etot_detail', public_id=etot.public_id)
    else:
        form = eTOTForm()

    ctx = {'form': form, 'title': 'Create eTOT Record'}
    ctx.update(_etot_graph_context())
    return render(request, 'daks/etot_form.html', ctx)


# ─────────────────────────────────────────────────────────────────────────────
# EDIT
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def etot_edit(request, public_id):
    record = get_object_or_404(eTOT, public_id=public_id)
    if request.method == 'POST':
        form = eTOTForm(request.POST, instance=record)
        if form.is_valid():
            with transaction.atomic():
                form.save()
            messages.success(request, f'eTOT record {record.tot_file_no} updated successfully!')
            return redirect('daks:etot_detail', public_id=record.public_id)
    else:
        form = eTOTForm(instance=record)

    ctx = {
        'form': form,
        'title': f'Edit eTOT — {record.tot_file_no}',
        'record': record,
    }
    ctx.update(_etot_graph_context())
    return render(request, 'daks/etot_form.html', ctx)


# ─────────────────────────────────────────────────────────────────────────────
# LINK / UNLINK DAK
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def etot_link_dak(request, public_id):
    record = get_object_or_404(eTOT, public_id=public_id)
    if request.method == 'POST':
        form = eTOTDakLinkForm(request.POST)
        if form.is_valid():
            link = form.save(commit=False)
            link.etot = record
            try:
                link.save()
                messages.success(request, f'Dak {link.dak.dak_index_no} linked successfully!')
            except Exception:
                messages.error(request, 'This Dak is already linked to this eTOT record.')
        else:
            messages.error(request, 'Invalid form. Please check the fields.')
    return redirect('daks:etot_detail', public_id=public_id)


@login_required
def etot_unlink_dak(request, public_id, link_pk):
    record = get_object_or_404(eTOT, public_id=public_id)
    link = get_object_or_404(eTOTDakLink, pk=link_pk, etot=record)
    dak_no = link.dak.dak_index_no
    link.delete()
    messages.success(request, f'Dak {dak_no} unlinked successfully.')
    return redirect('daks:etot_detail', public_id=public_id)


# ─────────────────────────────────────────────────────────────────────────────
# EXPORT
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def etot_export_excel(request):
    qs = eTOT.objects.all().select_related(
        'technical_group', 'point_of_contact', 'licensee_company', 'created_by'
    ).order_by('-created_at')

    if request.GET.get('search'):
        q = request.GET['search'].strip()
        qs = qs.filter(
            Q(tot_file_no__icontains=q) |
            Q(product_technology__icontains=q) |
            Q(licensee_name__icontains=q)
        )
    if request.GET.get('stage'):
        qs = qs.filter(stage=request.GET['stage'])
    if request.GET.get('group'):
        qs = qs.filter(technical_group_id=request.GET['group'])

    def fmt(d):
        return d.strftime('%d-%m-%Y') if d else ''

    def money(v):
        return float(v) if v else ''

    data = []
    for i, r in enumerate(qs, 1):
        data.append({
            '#': i,
            'ToT File No.': r.tot_file_no,
            'Product / Technology': r.product_technology,
            'Technical Group': r.technical_group.group_name if r.technical_group else '',
            'Point of Contact': r.point_of_contact.person_name if r.point_of_contact else '',
            'Stage': r.get_stage_display(),
            'Technology Category': r.technology_category or '',
            'Licensee Company': r.licensee_company.org_name if r.licensee_company else '',
            'Licensee Name': r.licensee_name or '',
            'Licensee Address': r.licensee_address or '',
            'Meeting Held On': fmt(r.meeting_held_on),
            'Minute Signed by Chairman': fmt(r.minute_signed_by_chairman_on),
            'Minute Approved by Director': fmt(r.minute_approved_by_director_on),
            'TNF Initiated by Group': fmt(r.tnf_initiated_by_group_on),
            'TNF Certificate Issued': fmt(r.tnf_certificate_issued_by_director_on),
            'TNF NOM No.': r.tnf_nom_no or '',
            'TNF No. Allotted by DIITM': fmt(r.tnf_no_allotted_by_diitm_on),
            'No. of Licenses Approved': r.no_of_licenses_approved or '',
            'EOI Hosting on Portal': fmt(r.eoi_hosting_on_portal),
            'CEC Constitution': fmt(r.cec_constitution_on),
            'CEC Meeting': fmt(r.cec_meeting_held_on),
            'CEC Approved by DG(PC & S7)': fmt(r.cec_approved_by_dg_pc_s7_on),
            'TAC Constitution': fmt(r.tac_constitution_by_dir_dg_mss_on),
            'TAC-1 EOI Received': r.tac1_no_of_eoi_received or '',
            'TAC-1 Meeting': fmt(r.tac1_meeting_held_on),
            'TAC-1 Recommended Firms': r.tac1_recommended_firms or '',
            'Vetted LAToT Shared': fmt(r.vetted_latot_shared_with_industry_on),
            'Signed LAToT Received': fmt(r.signed_stamped_latot_received_on),
            'eMRO No.': r.emro_no or '',
            'ToT Fee Paid (Rs.)': money(r.tot_fee_paid_by_licensee),
            'Fee Paid On': fmt(r.tot_fee_paid_on),
            'LAToT No.': r.latot_no or '',
            'LAToT Signed On': fmt(r.latot_signed_on),
            'TTD No.': r.ttd_no or '',
            'TTD Issued On': fmt(r.ttd_issued_on),
            'Hand Holding Support (Weeks)': r.hand_holding_support_weeks or '',
            'ToT Absorption Request': fmt(r.tot_absorption_request_received_on),
            'Director TBRL Recommendation for TA': fmt(r.director_tbrl_recommendation_for_ta_on),
            'TA Certificate No.': r.ta_certificate_no or '',
            'TA Certificate Issued On': fmt(r.ta_certificate_issued_on),
            'TA Validity': r.ta_certificate_validity or '',
            'Royalty Fee Received (Rs.)': money(r.royalty_fee_received),
            'Total Licenses Awarded': r.total_no_of_awarded_licenses or '',
            'Licenses Available': r.no_of_available_licensee or '',
            'Remarks': r.remarks or '',
            'Created By': r.created_by.username if r.created_by else '',
            'Created At': fmt(r.created_at.date()) if r.created_at else '',
        })

    df = pd.DataFrame(data)
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name='eTOT Records', index=False)
    output.seek(0)

    response = HttpResponse(
        output.read(),
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )
    response['Content-Disposition'] = 'attachment; filename="etot_records.xlsx"'
    return response


# ─────────────────────────────────────────────────────────────────────────────
# ADMIN-ONLY HARD DELETE
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def etot_delete(request, public_id):
    """Superuser-only: permanently delete an eTOT record and all related data."""
    if not request.user.is_superuser:
        messages.error(request, 'Only superusers can delete eTOT records.')
        return redirect('daks:etot_detail', public_id=public_id)

    record = get_object_or_404(eTOT, public_id=public_id)

    if request.method == 'POST':
        identifier = record.tot_file_no
        record.delete()
        messages.success(request, f'eTOT record "{identifier}" permanently deleted.')
        return redirect('daks:etot_dashboard')

    return render(request, 'daks/etot_confirm_delete.html', {'record': record})


# ─────────────────────────────────────────────────────────────────────────────
# BULK IMPORT
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def etot_bulk_import(request):
    """Admin-only: import eTOT records from Excel / CSV."""
    if not request.user.is_staff:
        messages.error(request, 'Only admins can perform bulk imports.')
        return redirect('daks:etot_dashboard')

    if request.method != 'POST':
        return render(request, 'daks/etot_bulk_import.html', {})

    import_file = request.FILES.get('import_file')
    if not import_file:
        messages.error(request, 'Please select a file.')
        return render(request, 'daks/etot_bulk_import.html', {})

    ext = import_file.name.lower().split('.')[-1]
    try:
        import pandas as pd
        from io import BytesIO

        if ext == 'csv':
            df = pd.read_csv(import_file, dtype=str)
        elif ext in ('xlsx', 'xls'):
            df = pd.read_excel(BytesIO(import_file.read()), dtype=str)
        else:
            messages.error(request, 'Only CSV and Excel files are supported.')
            return render(request, 'daks/etot_bulk_import.html', {})

        df = df.where(pd.notnull(df), None)
        df.columns = df.columns.str.lower().str.strip().str.replace(' ', '_')

        required = {'tot_file_no', 'product_technology'}
        missing = required - set(df.columns)
        if missing:
            messages.error(request, f'Missing required columns: {", ".join(missing)}')
            return render(request, 'daks/etot_bulk_import.html', {})

        def parse_date(val):
            if not val:
                return None
            try:
                return pd.to_datetime(val).date()
            except Exception:
                return None

        # Valid choice values
        valid_stages     = [s[0] for s in eTOT.STAGE_CHOICES]
        valid_categories = [c[0] for c in eTOT.CATEGORY_CHOICES]

        success = skipped = 0
        errors = []

        for idx, row in df.iterrows():
            rn = idx + 2
            try:
                tot_file_no = str(row.get('tot_file_no') or '').strip()
                product     = str(row.get('product_technology') or '').strip()
                if not tot_file_no or not product:
                    errors.append(f'Row {rn}: Missing ToT File No. or Product/Technology — skipped.')
                    skipped += 1
                    continue

                # Stage
                stage_val = str(row.get('stage') or 'INITIATED').strip().upper()
                if stage_val not in valid_stages:
                    stage_val = 'INITIATED'

                # Category A/B
                cat_val = str(row.get('technology_category') or '').strip().upper()
                if cat_val not in valid_categories:
                    cat_val = None

                # Licensee name (plain text) or company FK
                licensee_name = str(row.get('licensee_name') or '').strip() or None

                # Technical group
                group = None
                group_val = str(row.get('technical_group') or '').strip()
                if group_val:
                    group = GroupMaster.objects.filter(
                        group_name__iexact=group_val
                    ).first() or GroupMaster.objects.filter(
                        group_code__iexact=group_val
                    ).first()

                eTOT.objects.create(
                    tot_file_no=tot_file_no,
                    product_technology=product,
                    stage=stage_val,
                    technology_category=cat_val,
                    licensee_name=licensee_name,
                    technical_group=group,
                    licensee_address=str(row.get('licensee_address') or '').strip() or None,
                    remarks=str(row.get('remarks') or '').strip() or None,
                    meeting_held_on=parse_date(row.get('meeting_held_on')),
                    created_by=request.user,
                )
                success += 1

            except Exception as e:
                errors.append(f'Row {rn}: {str(e)} — skipped.')
                skipped += 1

        return render(request, 'daks/etot_bulk_import.html', {
            'done': True, 'success': success, 'skipped': skipped,
            'errors': errors[:50], 'total': success + skipped,
        })

    except Exception as e:
        messages.error(request, f'Import failed: {str(e)}')
        return render(request, 'daks/etot_bulk_import.html', {})
