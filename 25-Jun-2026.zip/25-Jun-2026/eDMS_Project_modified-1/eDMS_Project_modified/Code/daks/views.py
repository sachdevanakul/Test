from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q, Count
from django.utils import timezone
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from .models import *
from .forms import *
from django.http import JsonResponse
from django.core.cache import cache
# from django.views.decorators.cache import cache_page
from django.views.decorators.vary import vary_on_cookie
# from .cache_utils import get_cached_dropdowns, clear_all_caches
from .cache_utils import get_dashboard_stats, get_recent_daks, get_cached_dropdowns
from django.views.decorators.cache import cache_page
from django.http import HttpResponse
# from django.shortcuts import get_object_or_404, redirect
# from django.contrib import messages
from .encryption_utils import decrypt_file
from .models import UserNotes
from django.http import JsonResponse


@login_required
def api_persons_by_organization(request):
    """API endpoint to get persons for a given organization"""
    org_id = request.GET.get('org_id')
    if org_id:
        persons = PersonMaster.objects.filter(
            organization_id=org_id,
            is_active=True
        ).values('id', 'person_name')
        return JsonResponse({'persons': list(persons)})
    return JsonResponse({'persons': []})


@login_required
def api_thread_subject(request):
    """Return the subject of a thread so the outgoing form can auto-fill it."""
    thread_id = request.GET.get('thread_id')
    if thread_id:
        try:
            thread = DakThread.objects.get(pk=thread_id)
            return JsonResponse({'subject': thread.subject_summary or ''})
        except DakThread.DoesNotExist:
            pass
    return JsonResponse({'subject': ''})


@login_required
def api_thread_daks(request):
    """List the daks inside a thread, for the 'reply to which dak' dropdown.
    Scoping the reply_dak choices to the chosen thread is what lets you
    tell, on a thread with multiple daks, exactly which one a given reply
    belongs to."""
    thread_id = request.GET.get('thread_id')
    daks = []
    if thread_id:
        qs = DakMaster.objects.filter(thread_id=thread_id, is_active=True).order_by('issue_date')
        daks = [
            {
                'id': d.id,
                'dak_index_no': d.dak_index_no,
                'subject': d.subject[:80],
                'direction': d.dak_direction,
                'issue_date': d.issue_date.isoformat() if d.issue_date else '',
            }
            for d in qs
        ]
    return JsonResponse({'daks': daks})


@login_required
def api_threads_for_party(request):
    """Suggest OPEN threads already involving this correspondent (org and/or
    person), so creating a new dak about a different subject with the same
    correspondent can still land in the same thread instead of silently
    starting a new one — and so a different correspondent who happens to
    write about the same subject does NOT get merged into an existing
    thread just because the subject text matches."""
    org_id = request.GET.get('org_id')
    person_id = request.GET.get('person_id')

    thread_ids = set()
    if org_id:
        thread_ids.update(
            DakPartyMapping.objects.filter(organization_id=org_id)
            .values_list('dak__thread_id', flat=True)
        )
        thread_ids.update(
            DakMaster.objects.filter(receiver_org_id=org_id)
            .values_list('thread_id', flat=True)
        )
    if person_id:
        thread_ids.update(
            DakPartyMapping.objects.filter(person_id=person_id)
            .values_list('dak__thread_id', flat=True)
        )
        thread_ids.update(
            DakMaster.objects.filter(receiver_person_id=person_id)
            .values_list('thread_id', flat=True)
        )

    threads = (
        DakThread.objects.filter(id__in=thread_ids, status='OPEN')
        .order_by('-last_activity')[:5]
    )
    return JsonResponse({
        'threads': [
            {
                'id': t.id,
                'thread_code': t.thread_code,
                'subject_summary': t.subject_summary[:80],
                'dak_count': t.dak_count,
            }
            for t in threads
        ]
    })


@login_required
def api_quick_create_org(request):
    """AJAX: create a new OrganizationMaster on the fly from a modal."""
    if request.method != 'POST':
        return JsonResponse({'error': 'POST required'}, status=405)
    org_name = request.POST.get('org_name', '').strip()
    if not org_name:
        return JsonResponse({'error': 'Organization name is required.'}, status=400)
    if OrganizationMaster.objects.filter(org_name__iexact=org_name).exists():
        org = OrganizationMaster.objects.filter(org_name__iexact=org_name).first()
        return JsonResponse({'id': org.pk, 'org_name': org.org_name, 'created': False})
    try:
        default_type = OrganizationTypeMaster.objects.filter(is_active=True).first()
        org = OrganizationMaster.objects.create(
            org_name=org_name,
            org_type=default_type,
            phone=request.POST.get('phone', '') or '',
            email=request.POST.get('email', '') or '',
            created_by=request.user,
            source='DYNAMIC',
        )
        return JsonResponse({'id': org.pk, 'org_name': org.org_name, 'created': True})
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=400)


@login_required
def api_quick_create_person(request):
    """AJAX: create a new PersonMaster on the fly from a modal."""
    if request.method != 'POST':
        return JsonResponse({'error': 'POST required'}, status=405)
    person_name = request.POST.get('person_name', '').strip()
    if not person_name:
        return JsonResponse({'error': 'Person name is required.'}, status=400)
    org_id = request.POST.get('org_id') or None
    org = None
    if org_id:
        try:
            org = OrganizationMaster.objects.get(pk=org_id)
        except OrganizationMaster.DoesNotExist:
            pass
    try:
        person = PersonMaster.objects.create(
            person_name=person_name,
            organization=org,
            designation=request.POST.get('designation', '') or '',
            email=request.POST.get('email', '') or '',
            mobile_no=request.POST.get('mobile_no', '') or '',
            created_by=request.user,
            source='DYNAMIC',
        )
        return JsonResponse({'id': person.pk, 'person_name': person.person_name, 'created': True})
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=400)
# ============================================
# HOME PAGE VIEW (with all modules)
# ============================================

@login_required
def home(request):
    """Home page with all modules - USING CACHE + live module stats"""
    from django.db.models import Count
    from datetime import date

    # Dak stats from cache
    stats = get_dashboard_stats()
    recent_daks = get_recent_daks(8)

    # eDW stats
    try:
        from .models import eDW
        edw_count   = eDW.objects.count()
        edw_ongoing = eDW.objects.filter(status='ONGOING').count()
        edw_status = {
            'active':    eDW.objects.filter(status='ONGOING').count(),
            'completed': eDW.objects.filter(status='COMPLETED').count(),
            'pending':   eDW.objects.filter(status='PENDING').count(),
            'closure':   eDW.objects.filter(for_closure=True).count(),
        }
    except Exception:
        edw_count = edw_ongoing = 0
        edw_status = {'active':0,'completed':0,'pending':0,'closure':0}

    # eTOT stats + stage breakdown
    try:
        from .models import eTOT
        etot_count     = eTOT.objects.count()
        etot_completed = eTOT.objects.filter(stage='COMPLETED').count()
        etot_stages = {}
        for stage, _ in eTOT.STAGE_CHOICES:
            etot_stages[stage] = eTOT.objects.filter(stage=stage).count()
    except Exception:
        etot_count = etot_completed = 0
        etot_stages = {s:0 for s in ['INITIATED','TNF','EOI','CEC','TAC','LAToT','TTD','COMPLETED']}

    # eIIG stats + category breakdown
    try:
        from .models import eIIGVisit, eIIGVisitor
        eiig_visits   = eIIGVisit.objects.count()
        eiig_visitors = eIIGVisitor.objects.count()
        eiig_cat = {
            'industry':   eIIGVisit.objects.filter(company_category='INDUSTRY').count(),
            'govt':       eIIGVisit.objects.filter(company_category='GOVT').count(),
            'research':   eIIGVisit.objects.filter(company_category='RESEARCH').count(),
            'individual': eIIGVisit.objects.filter(company_category='INDIVIDUAL').count(),
        }
    except Exception:
        eiig_visits = eiig_visitors = 0
        eiig_cat = {'industry':0,'govt':0,'research':0,'individual':0}

    # Monthly trend for current year
    try:
        from .models import DakMaster
        current_year = date.today().year
        monthly_incoming = []
        monthly_outgoing = []
        for month in range(1, 13):
            monthly_incoming.append(
                DakMaster.objects.filter(
                    dak_direction='INCOMING', issue_date__year=current_year,
                    issue_date__month=month, is_active=True
                ).count()
            )
            monthly_outgoing.append(
                DakMaster.objects.filter(
                    dak_direction='OUTGOING', issue_date__year=current_year,
                    issue_date__month=month, is_active=True
                ).count()
            )
    except Exception:
        monthly_incoming = [0] * 12
        monthly_outgoing = [0] * 12

    # My Tasks — shown in right-panel task inbox on home page
    try:
        from .models import WorkTask
        my_tasks = list(
            WorkTask.objects.filter(
                assigned_to=request.user,
                status__in=['PENDING', 'IN_PROGRESS']
            ).select_related('assigned_by', 'linked_dak')
             .order_by('deadline', '-priority')[:10]
        )
    except Exception:
        my_tasks = []

    context = {
        'total_daks':       stats['total_daks'],
        'incoming_count':   stats['incoming_count'],
        'outgoing_count':   stats['outgoing_count'],
        'open_threads':     stats['open_threads'],
        'recent_daks':      recent_daks,
        'edw_count':        edw_count,
        'edw_ongoing':      edw_ongoing,
        'edw_status':       edw_status,
        'etot_count':       etot_count,
        'etot_completed':   etot_completed,
        'etot_stages':      etot_stages,
        'eiig_visits':      eiig_visits,
        'eiig_visitors':    eiig_visitors,
        'eiig_cat':         eiig_cat,
        'monthly_incoming': monthly_incoming,
        'monthly_outgoing': monthly_outgoing,
        'my_tasks':         my_tasks,
    }
    return render(request, 'daks/home.html', context)
# @cache_page(60 * 60 * 2)
# def home(request):
#     """Home page with all modules"""
#     recent_daks = DakMaster.objects.filter(is_active=True).order_by('-created_on')[:5]
#     context = {
#         'total_daks': DakMaster.objects.filter(is_active=True).count(),
#         'incoming_count': DakMaster.objects.filter(dak_direction='INCOMING', is_active=True).count(),
#         'outgoing_count': DakMaster.objects.filter(dak_direction='OUTGOING', is_active=True).count(),
#         'open_threads': DakThread.objects.filter(status='OPEN').count(),
#         'recent_daks': recent_daks,
#     }
#     return render(request, 'daks/home.html', context)


# ============================================
# DASHBOARD VIEW (redirects to home)
# ============================================

@login_required
def dashboard(request):
    """Redirect to home page"""
    return redirect('home')


# ============================================
# DAK LIST VIEWS
# ============================================

@login_required
def dak_list(request):

    # ── Module access guard ──────────────────────────────────────
    if not request.user.is_staff:
        from .models import UserProfile
        try:
            profile = request.user.profile
        except UserProfile.DoesNotExist:
            profile = UserProfile.objects.create(user=request.user)
        if not getattr(profile, 'can_access_incoming_dak', False):
            from django.contrib import messages as _msg
            _msg.error(request, 'You do not have permission to access this module.')
            return redirect('daks:home')
    # ─────────────────────────────────────────────────────────────
    """List all daks with search and filter"""
    
    daks = DakMaster.objects.filter(is_active=True).select_related(
        'thread', 'dak_category', 'nature', 'created_by'
    ).order_by('-created_on')
    
    form = DakSearchForm(request.GET)
    if form.is_valid():
        query = form.cleaned_data.get('query')
        date_from = form.cleaned_data.get('date_from')
        date_to = form.cleaned_data.get('date_to')
        direction = form.cleaned_data.get('direction')
        category = form.cleaned_data.get('category')
        nature = form.cleaned_data.get('nature')
        
        if query:
            daks = daks.filter(
                Q(dak_index_no__icontains=query) |
                Q(iig_ref_no__icontains=query) |
                Q(subject__icontains=query)
            )
        if date_from:
            daks = daks.filter(issue_date__gte=date_from)
        if date_to:
            daks = daks.filter(issue_date__lte=date_to)
        if direction:
            daks = daks.filter(dak_direction=direction)
        if category:
            daks = daks.filter(dak_category=category)
        if nature:
            daks = daks.filter(nature=nature)
    
    paginator = Paginator(daks, 25)
    page_number = request.GET.get('page', 1)
    
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)
    
    context = {
        'page_obj': page_obj,
        'form': form,
        'total_count': daks.count(),
    }
    return render(request, 'daks/dak_list.html', context)


@login_required
def dak_incoming(request):
    """List incoming daks"""
    daks = DakMaster.objects.filter(
        dak_direction='INCOMING', is_active=True
    ).select_related('thread', 'dak_category', 'nature').order_by('-created_on')
    
    paginator = Paginator(daks, 25)
    page_number = request.GET.get('page', 1)
    
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)
    
    context = {
        'page_obj': page_obj,
        'title': 'Incoming Daks',
    }
    return render(request, 'daks/dak_list.html', context)


@login_required
def dak_outgoing(request):
    """List outgoing daks"""
    daks = DakMaster.objects.filter(
        dak_direction='OUTGOING', is_active=True
    ).select_related('thread', 'dak_category', 'nature').order_by('-created_on')
    
    paginator = Paginator(daks, 25)
    page_number = request.GET.get('page', 1)
    
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)
    
    context = {
        'page_obj': page_obj,
        'title': 'Outgoing Daks',
    }
    return render(request, 'daks/dak_list.html', context)


# ============================================
# DAK DETAIL VIEW
# ============================================

@login_required
def dak_detail(request, public_id):
    """View dak details with all related information"""
    
    dak = get_object_or_404(
        DakMaster.objects.select_related(
            'thread', 'dak_category', 'nature', 'created_by', 'reply_dak'
        ).prefetch_related(
            'party_mappings__person',
            'party_mappings__party_role',
            'group_mappings__group',
            'attachments',
            'replies'
        ),
        public_id=public_id, is_active=True
    )
    
    try:
        report_details = dak.report_details
    except DakReportDetails.DoesNotExist:
        report_details = None
    
    try:
        dispatch_details = dak.dispatch_details
    except DakDispatchDetails.DoesNotExist:
        dispatch_details = None
    
    context = {
        'dak': dak,
        'report_details': report_details,
        'dispatch_details': dispatch_details,
    }
    return render(request, 'daks/dak_detail.html', context)


# ============================================
# DAK CREATE VIEWS
# ============================================
@login_required
def dak_create_incoming(request):
    """Create new incoming dak with sender details and file attachments"""
    
    if request.method == 'POST':
        form = IncomingDakForm(request.POST, request=request)
        
        if form.is_valid():
            dak = form.save(commit=False)
            dak.dak_direction = 'INCOMING'
            dak.created_by = request.user
            
            # Thread: use the one the user explicitly picked (same ongoing
            # correspondence, even if the subject text has changed since);
            # otherwise start a brand new thread. We deliberately no longer
            # auto-match by subject text — two different correspondents
            # writing about the same topic used to get merged into one
            # thread, and the same correspondent writing about a new topic
            # used to get split into a different one. Explicit selection
            # (helped by the "suggested threads" list in the form) fixes
            # both directions.
            thread = form.cleaned_data.get('thread')
            if not thread:
                thread_subject = form.cleaned_data['subject'][:100]
                year = timezone.now().year
                seq = DakThread.objects.filter(created_on__year=year).count() + 1
                thread = DakThread.objects.create(
                    subject_summary=thread_subject,
                    thread_code=f"THREAD-{year}-{seq:04d}",
                    created_by=request.user,
                    status='OPEN'
                )
            dak.thread = thread
            dak.reply_dak = form.cleaned_data.get('reply_dak')
            if dak.reply_dak and dak.reply_dak.thread_id != dak.thread_id:
                dak.reply_dak = None  # safety net — JS should already constrain choices to this thread
            # Save reply_due_date
            raw_due = request.POST.get('reply_due_date','').strip()
            if raw_due:
                try:
                    import datetime; dak.reply_due_date = datetime.date.fromisoformat(raw_due)
                except ValueError: pass
            raw_letter = request.POST.get('letter_no_incoming','').strip()
            if raw_letter: dak.letter_no = raw_letter
            dak.save()
            
            # Handle sender organization
            sender_org = None
            if form.cleaned_data.get('new_sender_org'):
                org = OrganizationMaster.objects.create(
                    org_name=form.cleaned_data['new_sender_org'],
                    org_type=OrganizationTypeMaster.objects.get(type_name='COMPANY'),
                    created_by=request.user,
                    source='DYNAMIC'
                )
                sender_org = org
            elif form.cleaned_data.get('sender_org'):
                sender_org = form.cleaned_data['sender_org']
            
            # Handle sender person
            if form.cleaned_data.get('new_sender_person'):
                person = PersonMaster.objects.create(
                    person_name=form.cleaned_data['new_sender_person'],
                    organization=sender_org,
                    created_by=request.user,
                    source='DYNAMIC'
                )
                DakPartyMapping.objects.create(
                    dak=dak,
                    person=person,
                    party_role=PartyRoleMaster.objects.get(role_code='SENDER'),
                    organization=sender_org
                )
            elif form.cleaned_data.get('sender_person'):
                DakPartyMapping.objects.create(
                    dak=dak,
                    person=form.cleaned_data['sender_person'],
                    party_role=PartyRoleMaster.objects.get(role_code='SENDER'),
                    organization=sender_org
                )
            
            # Handle marked_to person
            if form.cleaned_data.get('new_marked_to_person'):
                person = PersonMaster.objects.create(
                    person_name=form.cleaned_data['new_marked_to_person'],
                    created_by=request.user,
                    source='DYNAMIC'
                )
                DakPartyMapping.objects.create(
                    dak=dak,
                    person=person,
                    party_role=PartyRoleMaster.objects.get(role_code='MARKED_TO')
                )
            elif form.cleaned_data.get('marked_to_person'):
                DakPartyMapping.objects.create(
                    dak=dak,
                    person=form.cleaned_data['marked_to_person'],
                    party_role=PartyRoleMaster.objects.get(role_code='MARKED_TO')
                )
            
            # ========== ADD FILE UPLOAD ENCRYPTION CODE HERE ==========
            # Check if file was uploaded
            if request.FILES.get('attachment'):
                uploaded_file = request.FILES['attachment']

                from .cache_utils import get_max_attachment_size_mb
                max_mb = get_max_attachment_size_mb()
                if uploaded_file.size > max_mb * 1024 * 1024:
                    messages.error(
                        request,
                        f'Attachment "{uploaded_file.name}" is too large '
                        f'({uploaded_file.size / (1024*1024):.1f} MB). '
                        f'Max allowed is {max_mb} MB.'
                    )
                    return redirect('daks:dak_detail', public_id=dak.public_id)

                # Create attachments directory if not exists
                import os
                from django.conf import settings
                attachments_dir = os.path.join(settings.MEDIA_ROOT, 'attachments')
                os.makedirs(attachments_dir, exist_ok=True)
                
                # Define file path
                file_path = os.path.join(attachments_dir, uploaded_file.name)
                
                # Save file temporarily
                with open(file_path, 'wb') as f:
                    for chunk in uploaded_file.chunks():
                        f.write(chunk)
                
                # Calculate checksum (before encryption)
                from .encryption_utils import get_file_checksum, encrypt_file
                checksum = get_file_checksum(file_path)
                
                # Encrypt the file
                encrypt_file(file_path)
                
                # Create attachment record
                from .models import DakFileAttachment
                DakFileAttachment.objects.create(
                    dak=dak,
                    file_name=uploaded_file.name,
                    file_path=file_path,
                    file_size=uploaded_file.size,
                    mime_type=uploaded_file.content_type,
                    checksum=checksum,
                    is_encrypted=True,
                    uploaded_by=request.user
                )
                messages.success(request, "File attached and encrypted successfully!")
            # ========== END OF FILE UPLOAD ENCRYPTION ==========
            
            messages.success(request, f'Incoming dak created! Index: {dak.dak_index_no}')
            return redirect('daks:dak_detail', public_id=dak.public_id)
    else:
        form = IncomingDakForm(request=request)
    
    context = {'incoming_form': form, 'outgoing_form': OutgoingDakForm(request=request), 'title': 'Dak Entry', 'due_date_alerts': _get_due_date_alerts(request.user)}
    return render(request, 'daks/dak_form.html', context)
# @login_required
# def dak_create_incoming(request):
#     """Create new incoming dak"""
    
#     if request.method == 'POST':
#         form = IncomingDakForm(request.POST, request=request)
        
#         if form.is_valid():
#             dak = form.save(commit=False)
            
#             thread_subject = form.cleaned_data['subject'][:100]
#             thread, created = DakThread.objects.get_or_create(
#                 subject_summary=thread_subject,
#                 defaults={
#                     'thread_code': f"THREAD-{timezone.now().year}-{DakThread.objects.count()+1:04d}",
#                     'created_by': request.user,
#                     'status': 'OPEN'
#                 }
#             )
#             dak.thread = thread
#             dak.save()
            
#             messages.success(request, f'Incoming dak created! Index: {dak.dak_index_no}')
#             return redirect('daks:dak_detail', pk=dak.pk)
#     else:
#         form = IncomingDakForm(request=request)
    
#     context = {'form': form, 'title': 'New Incoming Dak'}
#     return render(request, 'daks/dak_form.html', context)


@login_required
def dak_create_outgoing(request):
    """Create new outgoing dak"""

    if request.method == 'POST':
        form = OutgoingDakForm(request.POST, request=request)

        if form.is_valid():
            dak = form.save(commit=False)
            dak.dak_direction = 'OUTGOING'
            dak.created_by = request.user

            # Handle thread — create one if not linked
            thread = form.cleaned_data.get('thread')
            if not thread:
                thread_subject = form.cleaned_data['subject'][:100]
                year = timezone.now().year
                seq = DakThread.objects.filter(created_on__year=year).count() + 1
                thread = DakThread.objects.create(
                    subject_summary=thread_subject,
                    thread_code=f"THREAD-{year}-{seq:04d}",
                    created_by=request.user,
                    status='OPEN'
                )
            dak.thread = thread
            dak.reply_dak = form.cleaned_data.get('reply_dak')
            if dak.reply_dak and dak.reply_dak.thread_id != dak.thread_id:
                dak.reply_dak = None  # safety net — JS should already constrain choices to this thread

            # reply_type
            dak.reply_type = form.cleaned_data.get('reply_type') or 'NONE'

            # Receiver org — may be an existing pk or 'new' (modal will have already created it via AJAX)
            receiver_org_val = request.POST.get('receiver_org')
            receiver_org = None
            if receiver_org_val and receiver_org_val != 'new':
                try:
                    receiver_org = OrganizationMaster.objects.get(pk=receiver_org_val)
                except OrganizationMaster.DoesNotExist:
                    pass
            dak.receiver_org = receiver_org

            # Receiver person
            receiver_person_val = request.POST.get('receiver_person')
            receiver_person = None
            if receiver_person_val and receiver_person_val != 'new':
                try:
                    receiver_person = PersonMaster.objects.get(pk=receiver_person_val)
                except PersonMaster.DoesNotExist:
                    pass
            dak.receiver_person = receiver_person

            dak.save()

            # Record receiver in DakPartyMapping too
            if receiver_person:
                DakPartyMapping.objects.create(
                    dak=dak,
                    person=receiver_person,
                    party_role=PartyRoleMaster.objects.filter(role_code='RECEIVER').first(),
                    organization=receiver_org
                )

            messages.success(request, f'Outgoing dak created! Index: {dak.dak_index_no}')
            return redirect('daks:dak_detail', public_id=dak.public_id)
    else:
        form = OutgoingDakForm(request=request)
        thread_id = request.GET.get('thread')
        if thread_id:
            form.fields['thread'].initial = thread_id

    context = {'outgoing_form': form, 'incoming_form': IncomingDakForm(request=request), 'title': 'Dak Entry', 'due_date_alerts': _get_due_date_alerts(request.user)}
    return render(request, 'daks/dak_form.html', context)



# ============================================
# THREAD VIEWS
# ============================================

@login_required
def thread_list(request):
    """List all threads"""
    
    threads = DakThread.objects.all().order_by('-last_activity')
    status = request.GET.get('status')
    
    if status:
        threads = threads.filter(status=status)
    
    paginator = Paginator(threads, 20)
    page_number = request.GET.get('page', 1)
    
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)
    
    context = {
        'page_obj': page_obj,
        'status_filter': status,
    }
    return render(request, 'daks/thread_list.html', context)


@login_required
def thread_detail(request, public_id):
    """View thread with all daks"""
    
    thread = get_object_or_404(DakThread, public_id=public_id)
    daks = thread.dak_set.filter(is_active=True).select_related('reply_dak').prefetch_related(
        'party_mappings__person', 'party_mappings__person__group', 'attachments'
    ).order_by('created_on')
    
    context = {
        'thread': thread,
        'daks': daks,
    }
    return render(request, 'daks/thread_detail.html', context)


@login_required
def thread_close(request, public_id):
    """Close a thread"""
    
    thread = get_object_or_404(DakThread, public_id=public_id)
    
    if request.method == 'POST':
        thread.status = 'CLOSED'
        thread.closed_on = timezone.now()
        thread.closed_by = request.user
        thread.save()
        messages.success(request, f'Thread {thread.thread_code} closed.')
        return redirect('daks:thread_detail', public_id=thread.public_id)
    
    context = {'thread': thread}
    return render(request, 'daks/thread_confirm_close.html', context)


@login_required
def thread_delete(request, public_id):
    """Superuser-only: permanently delete a thread and all its daks."""
    if not request.user.is_superuser:
        messages.error(request, 'Only superusers can delete threads.')
        return redirect('daks:thread_detail', public_id=public_id)

    thread = get_object_or_404(DakThread, public_id=public_id)

    if request.method == 'POST':
        code = thread.thread_code
        thread.delete()
        messages.success(request, f'Thread "{code}" and all its daks permanently deleted.')
        return redirect('daks:thread_list')

    return render(request, 'daks/thread_confirm_delete.html', {'thread': thread})

# ============================================
# CACHE HELPERS
# ============================================

@login_required
def download_attachment(request, public_id):
    """Download attachment — handles both encrypted and plain files.
    Requires an authenticated session (fixes: attachments were previously
    fetchable by pasting the URL directly, with no login check at all).
    """
    import os
    attachment = get_object_or_404(DakFileAttachment, public_id=public_id)
    file_path  = attachment.file_path
    if not os.path.exists(file_path):
        messages.error(request, f'File not found: {attachment.file_name}')
        return redirect('daks:dak_detail', public_id=attachment.dak.public_id)
    mime = attachment.mime_type or 'application/octet-stream'
    try:
        if getattr(attachment, 'is_encrypted', True):
            decrypted = decrypt_file(file_path)
            if decrypted:
                response = HttpResponse(decrypted, content_type=mime)
                response['Content-Disposition'] = f'attachment; filename="{attachment.file_name}"'
                return response
        with open(file_path, 'rb') as fp:
            response = HttpResponse(fp.read(), content_type=mime)
        response['Content-Disposition'] = f'attachment; filename="{attachment.file_name}"'
        return response
    except Exception as e:
        messages.error(request, f'Download error: {str(e)}')
        return redirect('daks:dak_detail', public_id=attachment.dak.public_id)
    
@login_required
def get_notes(request):
    """Get user notes via AJAX"""
    try:
        notes = UserNotes.objects.get(user=request.user)
        data = {'content': notes.content or '', 'success': True}
    except UserNotes.DoesNotExist:
        data = {'content': '', 'success': True}
    except Exception as e:
        data = {'content': '', 'success': False, 'error': str(e)}
    return JsonResponse(data)

@login_required
def save_notes(request):
    """Save user notes via AJAX"""
    if request.method != 'POST':
        return JsonResponse({'success': False, 'message': 'POST required'})
    try:
        content = request.POST.get('content', '')
        notes, created = UserNotes.objects.get_or_create(user=request.user)
        notes.content = content
        notes.save()
        return JsonResponse({'success': True, 'message': 'Saved'})
    except Exception as e:
        return JsonResponse({'success': False, 'message': str(e)})

# ═══════════════════════════════════════════════════════════════════
# HELPER — Due-date alerts for dak reply deadlines
# ═══════════════════════════════════════════════════════════════════
def _get_due_date_alerts(user=None):
    from django.utils import timezone as tz
    today = tz.now().date()
    alerts = []
    try:
        qs = DakMaster.objects.filter(
            dak_direction='INCOMING', is_active=True,
            reply_due_date__isnull=False,
        ).values('pk','dak_index_no','subject','reply_due_date')
        for dak in qs:
            days_left = (dak['reply_due_date'] - today).days
            if days_left < 0:
                show = True
            elif days_left < 5:
                show = True
            else:
                show = (dak['pk'] % 2 == today.day % 2)
            if show:
                alerts.append({
                    'dak_index_no': dak['dak_index_no'],
                    'subject':      dak['subject'],
                    'days_left':    days_left,
                    'due_date':     dak['reply_due_date'].strftime('%d %b %Y'),
                    'due_date_iso': dak['reply_due_date'].strftime('%Y-%m-%d'),
                })
    except Exception:
        pass
    return alerts


# ═══════════════════════════════════════════════════════════════════
# DAK DELETE
# ═══════════════════════════════════════════════════════════════════
@login_required
def dak_delete(request, public_id):
    if not request.user.is_staff:
        messages.error(request, 'Only admins can delete daks.')
        return redirect('daks:dak_detail', public_id=public_id)
    dak = get_object_or_404(DakMaster, public_id=public_id, is_active=True)
    if request.method == 'POST':
        dak.is_active = False
        dak.save()
        try:
            from .cache_utils import clear_dashboard_cache, clear_recent_daks_cache
            clear_dashboard_cache(); clear_recent_daks_cache()
        except Exception:
            pass
        try:
            AuditLog.objects.create(
                user=request.user, action='DELETE',
                entity_type='DAK', entity_id=dak.id,
                entity_name=dak.dak_index_no,
                details={'subject': dak.subject[:100]},
                ip_address=request.META.get('REMOTE_ADDR'),
            )
        except Exception:
            pass
        messages.success(request, f'Dak {dak.dak_index_no} deleted.')
        return redirect('daks:dak_list')
    return render(request, 'daks/dak_confirm_delete.html', {'dak': dak})


# ═══════════════════════════════════════════════════════════════════
# BULK IMPORT
# ═══════════════════════════════════════════════════════════════════
@login_required
def bulk_import(request):
    if not request.user.is_staff:
        messages.error(request, 'Only admins can perform bulk imports.')
        return redirect('daks:dak_list')
    if request.method == 'POST':
        import_file = request.FILES.get('import_file')
        if not import_file:
            messages.error(request, 'Please select a file.')
            return render(request, 'daks/bulk_import.html', {})
        ext = import_file.name.lower().split('.')[-1]
        try:
            import pandas as pd
            from io import BytesIO
            from django.utils import timezone as tz
            if ext == 'csv':
                df = pd.read_csv(import_file, dtype=str)
            elif ext in ('xlsx','xls'):
                df = pd.read_excel(BytesIO(import_file.read()), dtype=str)
            else:
                messages.error(request, 'Only CSV and Excel files supported.')
                return render(request, 'daks/bulk_import.html', {})
            df = df.where(pd.notnull(df), None)
            df.columns = df.columns.str.lower().str.strip()
            required = {'subject','issue_date','dak_direction'}
            missing  = required - set(df.columns)
            if missing:
                messages.error(request, f'Missing columns: {", ".join(missing)}')
                return render(request, 'daks/bulk_import.html', {})
            bulk_thread, _ = DakThread.objects.get_or_create(
                thread_code='BULK-IMPORT',
                defaults={'subject_summary':'Bulk Import','status':'OPEN','created_by':request.user}
            )
            default_cat = DakCategoryMaster.objects.filter(is_active=True).first()
            if default_cat is None:
                messages.error(request, 'No active Dak Category exists yet — create at least one before importing.')
                return render(request, 'daks/bulk_import.html', {})
            success = skipped = 0
            errors = []
            for idx, row in df.iterrows():
                rn = idx + 2
                try:
                    direction = str(row.get('dak_direction','INCOMING')).upper().strip()
                    if direction not in ('INCOMING','OUTGOING'):
                        errors.append(f'Row {rn}: Invalid direction. Skipped.')
                        skipped += 1; continue
                    subject = str(row.get('subject','')).strip()
                    if not subject:
                        errors.append(f'Row {rn}: Empty subject. Skipped.')
                        skipped += 1; continue
                    try:
                        issue_date = pd.to_datetime(row['issue_date']).date()
                    except Exception:
                        issue_date = tz.now().date()
                    year   = issue_date.year
                    prefix = 'IN' if direction == 'INCOMING' else 'OUT'
                    count  = DakMaster.objects.filter(dak_direction=direction, issue_date__year=year).count() + 1
                    idx_no = f'{prefix}-{year}-{count:04d}'
                    if DakMaster.objects.filter(dak_index_no=idx_no).exists():
                        skipped += 1; errors.append(f'Row {rn}: Duplicate {idx_no}. Skipped.'); continue
                    DakMaster.objects.create(
                        thread=bulk_thread, dak_direction=direction,
                        dak_category=default_cat, dak_index_no=idx_no,
                        subject=subject, issue_date=issue_date,
                        receipt_date=tz.now().date() if direction=='INCOMING' else None,
                        created_by=request.user, is_active=True,
                    )
                    success += 1
                except Exception as e:
                    errors.append(f'Row {rn}: {str(e)}'); skipped += 1
            try:
                from .cache_utils import clear_dashboard_cache, clear_recent_daks_cache
                clear_dashboard_cache(); clear_recent_daks_cache()
            except Exception:
                pass
            return render(request, 'daks/bulk_import.html', {
                'done':True,'success':success,'skipped':skipped,
                'errors':errors[:50],'total':success+skipped,
            })
        except Exception as e:
            messages.error(request, f'Import failed: {str(e)}')
    return render(request, 'daks/bulk_import.html', {})


# ═══════════════════════════════════════════════════════════════════
# SYSTEM SETTINGS (#12/#13 — admin-configurable max attachment size)
# ═══════════════════════════════════════════════════════════════════
@login_required
def system_settings(request):
    if not request.user.is_staff:
        messages.error(request, 'Access denied.'); return redirect('daks:home')

    from .cache_utils import get_max_attachment_size_mb, DEFAULT_MAX_ATTACHMENT_SIZE_MB

    if request.method == 'POST':
        raw = request.POST.get('max_attachment_size_mb', '').strip()
        try:
            new_size = int(raw)
            if new_size <= 0:
                raise ValueError
        except ValueError:
            messages.error(request, 'Enter a whole number of MB greater than 0.')
            return redirect('daks:system_settings')

        SystemConfig.objects.update_or_create(
            config_key='MAX_ATTACHMENT_SIZE_MB',
            defaults={
                'config_value': str(new_size),
                'data_type': 'INTEGER',
                'category': 'ATTACHMENTS',
                'description': 'Maximum allowed attachment size, in MB.',
                'is_active': True,
            }
        )
        # The post_save signal also clears this, but being explicit here
        # means the very next page load (this redirect) already sees the
        # new value, with no dependency on signal wiring to do so.
        from .cache_utils import clear_max_attachment_size_cache
        clear_max_attachment_size_cache()
        messages.success(request, f'Max attachment size updated to {new_size} MB.')
        return redirect('daks:system_settings')

    context = {
        'max_attachment_size_mb': get_max_attachment_size_mb(),
        'default_max_attachment_size_mb': DEFAULT_MAX_ATTACHMENT_SIZE_MB,
    }
    return render(request, 'daks/system_settings.html', context)


# ═══════════════════════════════════════════════════════════════════
# USER MANAGEMENT
# ═══════════════════════════════════════════════════════════════════
@login_required
def user_management(request):
    if not request.user.is_staff:
        messages.error(request, 'Access denied.'); return redirect('daks:home')
    from django.contrib.auth.models import User as AuthUser
    users = AuthUser.objects.all().order_by('username')
    return render(request, 'daks/user_management.html', {
        'users': users, 'total_users': users.count(),
        'active_users': users.filter(is_active=True).count(),
        'staff_users': users.filter(is_staff=True).count(),
    })


@login_required
def user_create(request):
    if not request.user.is_staff:
        messages.error(request, 'Access denied.'); return redirect('daks:home')
    from .forms import UserCreateForm
    if request.method == 'POST':
        form = UserCreateForm(request.POST)
        if form.is_valid():
            user = form.save()
            user.set_password(form.cleaned_data['password'])
            user.save()
            messages.success(request, f'User {user.username} created.')
            return redirect('daks:user_management')
    else:
        form = UserCreateForm()
    return render(request, 'daks/user_form.html', {'form': form, 'title': 'Create User'})


@login_required
def user_toggle_active(request, user_id):
    if not request.user.is_staff:
        return JsonResponse({'error': 'Access denied'}, status=403)
    from django.contrib.auth.models import User as AuthUser
    target = get_object_or_404(AuthUser, pk=user_id)
    if target == request.user:
        return JsonResponse({'error': 'Cannot deactivate yourself'}, status=400)
    target.is_active = not target.is_active
    target.save()
    return JsonResponse({'status': 'active' if target.is_active else 'inactive'})


@login_required
def user_toggle_staff(request, user_id):
    if not request.user.is_superuser:
        return JsonResponse({'error': 'Superuser only'}, status=403)
    from django.contrib.auth.models import User as AuthUser
    target = get_object_or_404(AuthUser, pk=user_id)
    if target == request.user:
        return JsonResponse({'error': 'Cannot change own staff status'}, status=400)
    target.is_staff = not target.is_staff
    target.save()
    return JsonResponse({'is_staff': target.is_staff})


@login_required
def user_delete(request, user_id):
    if not request.user.is_superuser:
        messages.error(request, 'Superuser only.'); return redirect('daks:user_management')
    from django.contrib.auth.models import User as AuthUser
    target = get_object_or_404(AuthUser, pk=user_id)
    if target == request.user:
        messages.error(request, 'Cannot delete yourself.'); return redirect('daks:user_management')
    if request.method == 'POST':
        uname = target.username; target.delete()
        messages.success(request, f'User {uname} deleted.')
        return redirect('daks:user_management')
    return render(request, 'daks/user_confirm_delete.html', {'target': target})


# ═══════════════════════════════════════════════════════════════════
# TASK MANAGEMENT
# ═══════════════════════════════════════════════════════════════════
@login_required
def task_list(request):

    # All authenticated users can see tasks assigned to them.
    # Admins (is_staff) see ALL tasks; regular users only see their own.
    # ─────────────────────────────────────────────────────────────
    from .models import WorkTask
    from django.db.models import Case, When, IntegerField
    if request.user.is_staff:
        qs = WorkTask.objects.select_related('assigned_to', 'assigned_by', 'linked_dak').all()
        user_filter = request.GET.get('user', '')
        if user_filter:
            qs = qs.filter(assigned_to_id=user_filter)
    else:
        qs = WorkTask.objects.filter(assigned_to=request.user).select_related('assigned_by', 'linked_dak')

    status   = request.GET.get('status', '')
    priority = request.GET.get('priority', '')
    if status:
        qs = qs.filter(status=status)
    if priority:
        qs = qs.filter(priority=priority)

    # Order: active tasks first (PENDING → IN_PROGRESS), then by deadline ASC (NULLs last), then priority
    status_order = Case(
        When(status='IN_PROGRESS', then=0),
        When(status='PENDING',     then=1),
        When(status='COMPLETED',   then=2),
        When(status='CANCELLED',   then=3),
        default=4,
        output_field=IntegerField(),
    )
    priority_order = Case(
        When(priority='URGENT', then=0),
        When(priority='HIGH',   then=1),
        When(priority='MEDIUM', then=2),
        When(priority='LOW',    then=3),
        default=4,
        output_field=IntegerField(),
    )
    from django.db.models.functions import Coalesce
    from django.db.models import Value
    import datetime
    qs = qs.annotate(
        s_order=status_order,
        p_order=priority_order,
    ).order_by('s_order', 'p_order', 'deadline')

    from django.contrib.auth.models import User as AuthUser
    return render(request, 'daks/task_list.html', {
        'tasks':           qs,
        'status_filter':   status,
        'priority_filter': priority,
        'user_filter':     request.GET.get('user', ''),
        'users':           AuthUser.objects.filter(is_active=True).order_by('username') if request.user.is_staff else [],
        'status_choices':  WorkTask.STATUS_CHOICES,
        'priority_choices': WorkTask.PRIORITY_CHOICES,
    })


@login_required
def task_create(request):
    from .models import WorkTask
    from .forms import WorkTaskForm
    if not request.user.is_staff:
        messages.error(request, 'Only admins can assign tasks.'); return redirect('daks:task_list')
    if request.method == 'POST':
        form = WorkTaskForm(request.POST)
        if form.is_valid():
            task = form.save(commit=False); task.assigned_by = request.user; task.save()
            messages.success(request, f'Task "{task.title}" assigned to {task.assigned_to.username}.')
            return redirect('daks:task_list')
    else:
        form = WorkTaskForm()
        if request.GET.get('dak'): form.fields['linked_dak'].initial = request.GET['dak']
    return render(request, 'daks/task_form.html', {'form': form, 'title': 'Assign New Task'})


@login_required
def task_edit(request, public_id):
    """Allow admin to edit task details after creation (title, priority, deadline, assigned_to, etc.)."""
    from .models import WorkTask
    from .forms import WorkTaskForm
    if not request.user.is_staff:
        messages.error(request, 'Only admins can edit tasks.'); return redirect('daks:task_list')
    task = get_object_or_404(WorkTask, public_id=public_id)
    if request.method == 'POST':
        form = WorkTaskForm(request.POST, instance=task)
        if form.is_valid():
            form.save()
            messages.success(request, f'Task "{task.title}" updated.')
            return redirect('daks:task_list')
    else:
        form = WorkTaskForm(instance=task)
    return render(request, 'daks/task_form.html', {
        'form': form,
        'title': f'Edit Task — {task.title}',
        'task': task,
        'is_edit': True,
    })


@login_required
def task_update_status(request, public_id):
    from .models import WorkTask
    task = get_object_or_404(WorkTask, public_id=public_id)
    if task.assigned_to != request.user and not request.user.is_staff:
        messages.error(request, 'Access denied.'); return redirect('daks:task_list')
    if request.method == 'POST':
        new_status = request.POST.get('status','')
        if new_status in [s[0] for s in WorkTask.STATUS_CHOICES]:
            task.status = new_status
            note = request.POST.get('completion_note','').strip()
            if note: task.completion_note = note
            if new_status == 'COMPLETED':
                from django.utils import timezone as tz; task.completed_at = tz.now()
            task.save()
            messages.success(request, f'Task updated to {task.get_status_display()}.')
    return redirect('daks:task_detail', public_id=public_id)


@login_required
def task_delete(request, public_id):
    from .models import WorkTask
    if not request.user.is_staff:
        messages.error(request, 'Admin only.'); return redirect('daks:task_list')
    task = get_object_or_404(WorkTask, public_id=public_id)
    if request.method == 'POST':
        title = task.title; task.delete()
        messages.success(request, f'Task "{title}" deleted.')
        return redirect('daks:task_list')
    return render(request, 'daks/task_confirm_delete.html', {'task': task})


@login_required
def task_detail(request, public_id):
    """Detail view for a single task — accessible by the assigned user or any staff."""
    from .models import WorkTask
    task = get_object_or_404(WorkTask, public_id=public_id)
    # Non-staff users can only see their own tasks
    if not request.user.is_staff and task.assigned_to != request.user:
        messages.error(request, 'Access denied.')
        return redirect('daks:task_list')
    return render(request, 'daks/task_detail.html', {'task': task})


@login_required
def task_api_counts(request):
    from .models import WorkTask
    from django.utils import timezone as tz
    pending = WorkTask.objects.filter(assigned_to=request.user, status__in=['PENDING','IN_PROGRESS']).count()
    overdue = WorkTask.objects.filter(assigned_to=request.user, status__in=['PENDING','IN_PROGRESS'], deadline__lt=tz.now().date()).count()
    return JsonResponse({'pending': pending, 'overdue': overdue})


# ═══════════════════════════════════════════════════════════════════
# USER PROFILE EDIT (admin: adjust module access for existing users)
# ═══════════════════════════════════════════════════════════════════

@login_required
def user_edit_profile(request, user_id):
    """Allow admin/superuser to edit an existing user's module permissions."""
    if not request.user.is_staff:
        messages.error(request, 'Access denied.')
        return redirect('daks:home')

    from django.contrib.auth.models import User as AuthUser
    from .models import UserProfile

    target = get_object_or_404(AuthUser, pk=user_id)
    profile, _ = UserProfile.objects.get_or_create(user=target)

    if request.method == 'POST':
        # Superuser-only: toggle staff flag
        if request.user.is_superuser and target != request.user:
            target.is_staff = request.POST.get('is_staff') == 'on'
        target.is_active = request.POST.get('is_active') == 'on'
        target.first_name = request.POST.get('first_name', target.first_name).strip()
        target.last_name = request.POST.get('last_name', target.last_name).strip()
        target.email = request.POST.get('email', target.email).strip()
        target.save()

        profile.can_access_incoming_dak = request.POST.get('can_access_incoming_dak') == 'on'
        profile.can_access_edw          = request.POST.get('can_access_edw') == 'on'
        profile.can_access_etot         = request.POST.get('can_access_etot') == 'on'
        profile.can_access_eiig         = request.POST.get('can_access_eiig') == 'on'
        profile.can_access_reports      = request.POST.get('can_access_reports') == 'on'
        profile.can_access_task         = request.POST.get('can_access_task') == 'on'
        profile.can_capture_photo       = request.POST.get('can_capture_photo') == 'on'
        profile.can_take_screenshot     = request.POST.get('can_take_screenshot') == 'on'
        profile.department              = request.POST.get('department', '').strip()
        profile.notes                   = request.POST.get('notes', '').strip()
        profile.save()

        messages.success(request, f'Permissions updated for {target.username}.')
        return redirect('daks:user_management')

    return render(request, 'daks/user_edit_profile.html', {
        'title': f'Edit Permissions — {target.username}',
        'target': target,
        'profile': profile,
    })


# ═══════════════════════════════════════════════════════════════════
# NTR / BQ
# ═══════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════
# FIX 6 — ADMIN: MANAGE EXTRA COLUMNS for eDW / eToT / eIIG
# ═══════════════════════════════════════════════════════════════════

@login_required
def admin_extra_columns(request):
    """List all admin-defined extra columns grouped by module."""
    if not request.user.is_staff:
        from django.contrib import messages as _m
        _m.error(request, 'Staff access required.')
        return redirect('daks:home')
    from .models import ModuleExtraColumn
    columns = ModuleExtraColumn.objects.select_related('created_by').all()
    return render(request, 'daks/admin_extra_columns.html', {
        'title': 'Manage Extra Columns',
        'columns': columns,
        'modules': [('edw', 'eDW'), ('etot', 'eToT'), ('eiig', 'eIIG')],
    })


@login_required
def admin_extra_column_add(request):
    """Add a new extra column for a module."""
    if not request.user.is_staff:
        return redirect('daks:home')
    from .models import ModuleExtraColumn
    if request.method == 'POST':
        module       = request.POST.get('module', '').strip()
        column_label = request.POST.get('column_label', '').strip()
        field_type   = request.POST.get('field_type', 'text').strip()
        sort_order   = int(request.POST.get('sort_order', 0) or 0)
        if module and column_label:
            ModuleExtraColumn.objects.create(
                module=module,
                column_label=column_label,
                field_type=field_type,
                sort_order=sort_order,
                created_by=request.user,
            )
            from django.contrib import messages as _m
            _m.success(request, f'Column "{column_label}" added to {module.upper()}.')
        return redirect('daks:admin_extra_columns')
    return render(request, 'daks/admin_extra_columns.html', {
        'title': 'Add Extra Column',
        'add_mode': True,
        'columns': [],
        'modules': [('edw', 'eDW'), ('etot', 'eToT'), ('eiig', 'eIIG')],
        'field_types': [('text','Text'),('number','Number'),('date','Date'),('bool','Yes/No')],
    })


@login_required
def admin_extra_column_edit(request, col_id):
    """Edit an existing extra column."""
    if not request.user.is_staff:
        return redirect('daks:home')
    from .models import ModuleExtraColumn
    from django.shortcuts import get_object_or_404
    col = get_object_or_404(ModuleExtraColumn, pk=col_id)
    if request.method == 'POST':
        col.column_label = request.POST.get('column_label', col.column_label).strip()
        col.field_type   = request.POST.get('field_type', col.field_type).strip()
        col.sort_order   = int(request.POST.get('sort_order', col.sort_order) or 0)
        col.save()
        from django.contrib import messages as _m
        _m.success(request, f'Column "{col.column_label}" updated.')
        return redirect('daks:admin_extra_columns')
    return render(request, 'daks/admin_extra_columns.html', {
        'title': 'Edit Extra Column',
        'edit_col': col,
        'columns': [],
        'modules': [('edw', 'eDW'), ('etot', 'eToT'), ('eiig', 'eIIG')],
        'field_types': [('text','Text'),('number','Number'),('date','Date'),('bool','Yes/No')],
    })


@login_required
def admin_extra_column_delete(request, col_id):
    """Delete an extra column (and all its stored values)."""
    if not request.user.is_staff:
        return redirect('daks:home')
    from .models import ModuleExtraColumn
    from django.shortcuts import get_object_or_404
    col = get_object_or_404(ModuleExtraColumn, pk=col_id)
    if request.method == 'POST':
        label = col.column_label
        col.delete()
        from django.contrib import messages as _m
        _m.success(request, f'Column "{label}" deleted.')
    return redirect('daks:admin_extra_columns')


@login_required
def admin_extra_column_toggle(request, col_id):
    """Toggle active/inactive on an extra column."""
    if not request.user.is_staff:
        return redirect('daks:home')
    from .models import ModuleExtraColumn
    from django.shortcuts import get_object_or_404
    col = get_object_or_404(ModuleExtraColumn, pk=col_id)
    col.is_active = not col.is_active
    col.save(update_fields=['is_active'])
    return redirect('daks:admin_extra_columns')
