"""
Column registry for the custom report builder (#21).

Rather than hand-listing every one of eDW's ~50 fields and eTOT's ~55
(error-prone, and goes stale the moment someone adds a field to the
model), this introspects each model's real fields and builds the
checklist from them automatically. A small per-model OVERRIDES dict
handles the handful of fields that need special treatment — mainly
foreign keys, where we want to show a human-readable related field
(e.g. the company's name, not "OrganizationMaster object (4)").
"""

from .models import eDW, eTOT, eIIGVisit

# Fields left out of the picker entirely — not meaningful to a human reading a report
_COMMON_EXCLUDE = {'id', 'public_id'}

# field_name -> (label override, dotted accessor override)
_OVERRIDES = {
    'eDW': {
        'company_name': ('Company Name', 'company_name.org_name'),
        'group':        ('Group', 'group.group_name'),
        'dak':          ('Linked Dak', 'dak.dak_index_no'),
        'created_by':   ('Created By', 'created_by.username'),
    },
    'eTOT': {
        'technical_group':  ('Technical Group', 'technical_group.group_name'),
        'point_of_contact': ('Point of Contact', 'point_of_contact.person_name'),
        'licensee_company': ('Licensee Company', 'licensee_company.org_name'),
        'created_by':       ('Created By', 'created_by.username'),
    },
    'eIIGVisit': {
        'created_by': ('Created By', 'created_by.username'),
    },
}


_KNOWN_ACRONYMS = {
    'acn', 'rdr', 'bq', 'gst', 'rcm', 'dpsu', 'psu', 'capf', 'mro', 'te',
    'jcc', 'i2g', 'tnf', 'nom', 'eoi', 'cec', 'tac', 'dg', 'mss', 'peso',
    'latot', 'ttd', 'emro', 'ta', 'id', 'ntr', 'iig', 'dcmm', 'tot',
}


def _label_from_field_name(name):
    words = name.replace('_', ' ').strip().split(' ')
    return ' '.join(w.upper() if w.lower() in _KNOWN_ACRONYMS else w.title() for w in words)


def _build_columns(model, model_key):
    overrides = _OVERRIDES.get(model_key, {})
    columns = []
    for f in model._meta.get_fields():
        # Only real columns on THIS model's table — excludes reverse FK/M2M
        # relations (e.g. eDW.bqs, eDW.ntr, eDW.dak_links) which aren't
        # single values a report row could show.
        if not getattr(f, 'concrete', False):
            continue
        name = f.name
        if name in _COMMON_EXCLUDE:
            continue
        if name in overrides:
            label, accessor = overrides[name]
        else:
            label = _label_from_field_name(name)
            accessor = name
        columns.append({'key': name, 'label': label, 'accessor': accessor})
    return columns


EDW_COLUMNS = _build_columns(eDW, 'eDW')
ETOT_COLUMNS = _build_columns(eTOT, 'eTOT')
EIIG_COLUMNS = _build_columns(eIIGVisit, 'eIIGVisit')

# Curated default column set for each module's one-click "quick report" —
# as opposed to the full picker, which exposes every field. Keeps the
# same field choices used for the read-only SQL views (migration 0004)
# for consistency between what a direct DB query and a generated report
# both consider "the sensible summary" of each module.
DEFAULT_REPORT_COLUMNS = {
    'edw': ['acn_no', 'rdr_register_number', 'company_name', 'group', 'acn_date',
            'workflow_stage', 'status', 'is_closed', 'amount_paid_by_firm',
            'dak', 'created_by', 'created_at'],
    'etot': ['tot_file_no', 'product_technology', 'technology_category', 'stage',
              'licensee_name', 'latot_no', 'ttd_no', 'no_of_licenses_approved',
              'technical_group', 'point_of_contact', 'licensee_company',
              'created_by', 'created_at'],
    'eiig': ['visit_id', 'date_of_visit', 'firm_name', 'firm_state', 'company_category',
             'company_sub_category', 'created_by', 'created_at'],
}


def get_default_columns(module_key):
    """The curated column subset for module_key, in registry order, filtered
    down to the keys in DEFAULT_REPORT_COLUMNS (skips silently if a key
    listed above doesn't actually exist on the model, instead of raising)."""
    info = MODULE_REGISTRY.get(module_key)
    if not info:
        return []
    wanted = set(DEFAULT_REPORT_COLUMNS.get(module_key, []))
    by_key = {c['key']: c for c in info['columns']}
    return [by_key[k] for k in DEFAULT_REPORT_COLUMNS.get(module_key, []) if k in by_key]

MODULE_REGISTRY = {
    'edw':  {'label': 'eDW',  'model': eDW,       'columns': EDW_COLUMNS},
    'etot': {'label': 'eToT', 'model': eTOT,      'columns': ETOT_COLUMNS},
    'eiig': {'label': 'eIIG', 'model': eIIGVisit, 'columns': EIIG_COLUMNS},
}


def resolve_value(obj, accessor):
    """Resolve a dotted accessor path against an instance, e.g.
    'company_name.org_name' -> obj.company_name.org_name. Returns '' for
    any broken link (null FK, missing attr) instead of raising — a
    half-filled eDW record shouldn't crash the whole report."""
    value = obj
    for part in accessor.split('.'):
        if value is None:
            return ''
        value = getattr(value, part, None)
    if value is None:
        return ''
    if callable(value):
        try:
            value = value()
        except Exception:
            return ''
    return value
