"""
eIIG Module — Visitor Management Views
"""
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.http import HttpResponse, JsonResponse
from django.db.models import Q, Count, Prefetch
from django.db import transaction
from .models import eIIGVisit, eIIGVisitor
from .forms import eIIGVisitForm, VisitorFormSet
import pandas as pd
from io import BytesIO


# ─────────────────────────────────────────────────────────────────────────────
# DASHBOARD
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def eiig_dashboard(request):

    # ── Module access guard ──────────────────────────────────────
    if not request.user.is_staff:
        from .models import UserProfile
        try:
            profile = request.user.profile
        except UserProfile.DoesNotExist:
            profile = UserProfile.objects.create(user=request.user)
        if not getattr(profile, 'can_access_eiig', False):
            from django.contrib import messages as _msg
            _msg.error(request, 'You do not have permission to access this module.')
            return redirect('daks:home')
    # ─────────────────────────────────────────────────────────────
    qs = (
        eIIGVisit.objects.all()
        .annotate(visitor_count=Count('visitors'))
        .prefetch_related('visitors')
        .order_by('-date_of_visit', '-created_at')
    )

    # Search
    search = request.GET.get('search', '').strip()
    if search:
        qs = qs.filter(
            Q(visit_id__icontains=search) |
            Q(firm_name__icontains=search) |
            Q(visitors__name__icontains=search) |
            Q(purpose_of_visit__icontains=search)
        ).distinct()

    # Filters
    category_filter = request.GET.get('category', '').strip()
    if category_filter:
        qs = qs.filter(company_category=category_filter)

    state_filter = request.GET.get('state', '').strip()
    if state_filter:
        qs = qs.filter(firm_state=state_filter)

    year_filter = request.GET.get('fy', '').strip()
    if year_filter:
        qs = qs.filter(visit_id__contains=f'/{year_filter}/')

    date_from = request.GET.get('date_from', '').strip()
    if date_from:
        qs = qs.filter(date_of_visit__gte=date_from)

    date_to = request.GET.get('date_to', '').strip()
    if date_to:
        qs = qs.filter(date_of_visit__lte=date_to)

    # Stats
    total_visits   = qs.count()
    total_visitors = eIIGVisitor.objects.filter(visit__in=qs).count()

    # Pagination
    paginator = Paginator(qs, 50)
    try:
        page_obj = paginator.page(request.GET.get('page', 1))
    except (PageNotAnInteger, EmptyPage):
        page_obj = paginator.page(1)

    # Current financial year for display
    from datetime import date
    current_fy = eIIGVisit.get_financial_year(date.today())

    context = {
        'page_obj': page_obj,
        'total_count': total_visits,
        'total_visitors': total_visitors,
        'search': search,
        'category_filter': category_filter,
        'state_filter': state_filter,
        'year_filter': year_filter,
        'date_from': date_from,
        'date_to': date_to,
        'category_choices': eIIGVisit.CATEGORY_CHOICES,
        'state_choices': eIIGVisit.INDIAN_STATES,
        'current_fy': current_fy,
    }
    return render(request, 'daks/eiig_dashboard.html', context)


# ─────────────────────────────────────────────────────────────────────────────
# DETAIL
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def eiig_detail(request, public_id):
    visit = get_object_or_404(
        eIIGVisit.objects.prefetch_related('visitors').select_related('created_by'),
        public_id=public_id
    )
    return render(request, 'daks/eiig_detail.html', {'visit': visit})


# ─────────────────────────────────────────────────────────────────────────────
# HELPER: Build graph context data for eIIG form
# ─────────────────────────────────────────────────────────────────────────────

def _eiig_graph_context():
    """Aggregated stats for eIIG tab graphs. All values default to 0."""
    from django.db.models import Count, Avg
    qs = eIIGVisit.objects.all()

    eiig_cat = {
        'industry':   qs.filter(company_category='INDUSTRY').count(),
        'govt':       qs.filter(company_category='GOVT').count(),
        'research':   qs.filter(company_category='RESEARCH').count(),
        'individual': qs.filter(company_category='INDIVIDUAL').count(),
    }

    total_visits   = qs.count()
    total_visitors = sum(v.visitors.count() for v in qs) if total_visits else 0
    avg_per_visit  = round(total_visitors / total_visits, 1) if total_visits else 0

    eiig_visitors = {
        'total_visits':   total_visits,
        'total_visitors': total_visitors,
        'avg_per_visit':  avg_per_visit,
    }

    return {
        'eiig_cat':      eiig_cat,
        'eiig_visitors': eiig_visitors,
    }


# ─────────────────────────────────────────────────────────────────────────────
# CREATE
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def eiig_create(request):
    if request.method == 'POST':
        form = eIIGVisitForm(request.POST)
        formset = VisitorFormSet(request.POST, prefix='visitors')
        if form.is_valid() and formset.is_valid():
            with transaction.atomic():
                visit = form.save(commit=False)
                visit.created_by = request.user
                visit.save()
                formset.instance = visit
                formset.save()
            messages.success(request, f'Visit {visit.visit_id} recorded successfully!')
            return redirect('daks:eiig_detail', public_id=visit.public_id)
        else:
            # Surface formset errors in the messages so the user knows what failed
            for i, vform in enumerate(formset.forms):
                for field, errs in vform.errors.items():
                    for err in errs:
                        messages.error(request, f'Visitor {i+1} — {field}: {err}')
            for err in formset.non_form_errors():
                messages.error(request, f'Visitor list: {err}')
    else:
        form = eIIGVisitForm()
        formset = VisitorFormSet(prefix='visitors')

    ctx = {'form': form, 'formset': formset, 'title': 'Record New Visit'}
    ctx.update(_eiig_graph_context())
    return render(request, 'daks/eiig_form.html', ctx)


# ─────────────────────────────────────────────────────────────────────────────
# EDIT
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def eiig_edit(request, public_id):
    visit = get_object_or_404(eIIGVisit, public_id=public_id)
    if request.method == 'POST':
        form = eIIGVisitForm(request.POST, instance=visit)
        formset = VisitorFormSet(request.POST, instance=visit, prefix='visitors')
        if form.is_valid() and formset.is_valid():
            with transaction.atomic():
                form.save()
                formset.save()
            messages.success(request, f'Visit {visit.visit_id} updated successfully!')
            return redirect('daks:eiig_detail', public_id=visit.public_id)
        else:
            for i, vform in enumerate(formset.forms):
                for field, errs in vform.errors.items():
                    for err in errs:
                        messages.error(request, f'Visitor {i+1} — {field}: {err}')
            for err in formset.non_form_errors():
                messages.error(request, f'Visitor list: {err}')
    else:
        form = eIIGVisitForm(instance=visit)
        formset = VisitorFormSet(instance=visit, prefix='visitors')

    ctx = {
        'form': form,
        'formset': formset,
        'title': f'Edit Visit — {visit.visit_id}',
        'visit': visit,
    }
    ctx.update(_eiig_graph_context())
    return render(request, 'daks/eiig_form.html', ctx)


# ─────────────────────────────────────────────────────────────────────────────
# API: Sub-categories for a given category (AJAX)
# ─────────────────────────────────────────────────────────────────────────────

SUBCATEGORY_MAP = {
    'INDUSTRY':   ['PRIVATE', 'DPSU', 'PSU', 'MSME', 'STARTUP'],
    'GOVERNMENT': ['CENTRAL', 'STATE', 'DEFENCE', 'CAPF'],
    'RESEARCH':   ['UNIVERSITY', 'RESEARCH_INST', 'IIT_NIT', 'LAB'],
    'INDIVIDUAL': ['ENTREPRENEUR', 'STUDENT', 'RESEARCHER'],
    'OTHER':      ['OTHER'],
}

SUBCATEGORY_LABELS = dict(eIIGVisit.SUBCATEGORY_CHOICES)

@login_required
def eiig_api_subcategories(request):
    category = request.GET.get('category', '')
    subs = SUBCATEGORY_MAP.get(category, [])
    data = [{'value': v, 'label': SUBCATEGORY_LABELS.get(v, v)} for v in subs]
    return JsonResponse({'subcategories': data})


# ─────────────────────────────────────────────────────────────────────────────
# EXPORT
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def eiig_export_excel(request):
    qs = (
        eIIGVisit.objects.all()
        .prefetch_related('visitors')
        .order_by('-date_of_visit')
    )
    if request.GET.get('search'):
        q = request.GET['search'].strip()
        qs = qs.filter(
            Q(visit_id__icontains=q) |
            Q(firm_name__icontains=q) |
            Q(visitors__name__icontains=q)
        ).distinct()
    if request.GET.get('category'):
        qs = qs.filter(company_category=request.GET['category'])
    if request.GET.get('state'):
        qs = qs.filter(firm_state=request.GET['state'])

    state_labels = dict(eIIGVisit.INDIAN_STATES)
    cat_labels   = dict(eIIGVisit.CATEGORY_CHOICES)
    sub_labels   = dict(eIIGVisit.SUBCATEGORY_CHOICES)

    data = []
    sno = 1
    for visit in qs:
        visitors = list(visit.visitors.all())
        if not visitors:
            visitors = [None]  # at least one row per visit

        for i, visitor in enumerate(visitors):
            data.append({
                '#': sno if i == 0 else '',
                'Visit ID': visit.visit_id if i == 0 else '',
                'Date of Visit': visit.date_of_visit.strftime('%d-%m-%Y') if i == 0 else '',
                'Name of Visitor': visitor.name if visitor else '',
                'Designation': visitor.designation or '' if visitor else '',
                'Mobile No. 1': visitor.mobile_1 or '' if visitor else '',
                'Mobile No. 2': visitor.mobile_2 or '' if visitor else '',
                'Email ID 1': visitor.email_1 or '' if visitor else '',
                'Email ID 2': visitor.email_2 or '' if visitor else '',
                'Firm / Industry': visit.firm_name if i == 0 else '',
                'Address': visit.firm_address or '' if i == 0 else '',
                'State': state_labels.get(visit.firm_state, visit.firm_state or '') if i == 0 else '',
                'Company Category': cat_labels.get(visit.company_category, '') if i == 0 else '',
                'Sub Category': sub_labels.get(visit.company_sub_category, '') if i == 0 else '',
                'Purpose of Visit': visit.purpose_of_visit or '' if i == 0 else '',
                'Feedback': visit.feedback or '' if i == 0 else '',
                'Remarks': visit.remarks or '' if i == 0 else '',
            })
        sno += 1

    df = pd.DataFrame(data)
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name='IIG Visits', index=False)
    output.seek(0)

    response = HttpResponse(
        output.read(),
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )
    response['Content-Disposition'] = 'attachment; filename="iig_visits.xlsx"'
    return response


@login_required
def eiig_slideshow(request):
    """IIG photo slideshow page — photos stored client-side via localStorage."""
    return render(request, 'daks/eiig_slideshow.html', {'title': 'IIG Visit Gallery'})


# ─────────────────────────────────────────────────────────────────────────────
# ADMIN-ONLY HARD DELETE
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def eiig_delete(request, public_id):
    """Superuser-only: permanently delete an eIIG visit record."""
    if not request.user.is_superuser:
        messages.error(request, 'Only superusers can delete eIIG records.')
        return redirect('daks:eiig_detail', public_id=public_id)

    visit = get_object_or_404(eIIGVisit, public_id=public_id)

    if request.method == 'POST':
        identifier = visit.visit_id
        visit.delete()
        messages.success(request, f'eIIG visit "{identifier}" permanently deleted.')
        return redirect('daks:eiig_dashboard')

    return render(request, 'daks/eiig_confirm_delete.html', {'visit': visit})


# ─────────────────────────────────────────────────────────────────────────────
# BULK IMPORT
# ─────────────────────────────────────────────────────────────────────────────

@login_required
def eiig_bulk_import(request):
    """
    Admin-only: import eIIG visits from Excel / CSV.
    Each row = one visit. Visitor names go in visitor_1_name, visitor_2_name etc.
    """
    if not request.user.is_staff:
        messages.error(request, 'Only admins can perform bulk imports.')
        return redirect('daks:eiig_dashboard')

    if request.method != 'POST':
        return render(request, 'daks/eiig_bulk_import.html', {})

    import_file = request.FILES.get('import_file')
    if not import_file:
        messages.error(request, 'Please select a file.')
        return render(request, 'daks/eiig_bulk_import.html', {})

    ext = import_file.name.lower().split('.')[-1]
    try:
        import pandas as pd
        from io import BytesIO

        if ext == 'csv':
            df = pd.read_csv(import_file, dtype=str)
        elif ext in ('xlsx', 'xls'):
            df = pd.read_excel(BytesIO(import_file.read()), dtype=str)
        else:
            messages.error(request, 'Only CSV and Excel files are supported.')
            return render(request, 'daks/eiig_bulk_import.html', {})

        df = df.where(pd.notnull(df), None)
        df.columns = df.columns.str.lower().str.strip().str.replace(' ', '_')

        required = {'firm_name', 'date_of_visit'}
        missing = required - set(df.columns)
        if missing:
            messages.error(request, f'Missing required columns: {", ".join(missing)}')
            return render(request, 'daks/eiig_bulk_import.html', {})

        # Valid choice values
        valid_categories    = [c[0] for c in eIIGVisit.CATEGORY_CHOICES]
        valid_subcategories = [c[0] for c in eIIGVisit.SUBCATEGORY_CHOICES]
        valid_states        = [s[0] for s in eIIGVisit.INDIAN_STATES if s[0]]

        success = skipped = 0
        errors = []

        for idx, row in df.iterrows():
            rn = idx + 2
            try:
                firm_name = str(row.get('firm_name') or '').strip()
                if not firm_name:
                    errors.append(f'Row {rn}: Empty firm name — skipped.')
                    skipped += 1
                    continue

                try:
                    date_of_visit = pd.to_datetime(row['date_of_visit']).date()
                except Exception:
                    errors.append(f'Row {rn}: Invalid date_of_visit — skipped.')
                    skipped += 1
                    continue

                cat_val = str(row.get('company_category') or '').strip().upper()
                if cat_val not in valid_categories:
                    cat_val = None

                subcat_val = str(row.get('company_sub_category') or '').strip().upper()
                if subcat_val not in valid_subcategories:
                    subcat_val = None

                state_val = str(row.get('firm_state') or '').strip().upper()
                if state_val not in valid_states:
                    state_val = None

                with transaction.atomic():
                    visit = eIIGVisit.objects.create(
                        firm_name=firm_name,
                        date_of_visit=date_of_visit,
                        firm_address=str(row.get('firm_address') or '').strip() or None,
                        firm_state=state_val,
                        company_category=cat_val,
                        company_sub_category=subcat_val,
                        purpose_of_visit=str(row.get('purpose_of_visit') or '').strip() or None,
                        remarks=str(row.get('remarks') or '').strip() or None,
                        created_by=request.user,
                    )

                    # Import up to 5 visitors per row: visitor_1_name, visitor_2_name...
                    for i in range(1, 6):
                        v_name = str(row.get(f'visitor_{i}_name') or '').strip()
                        if not v_name:
                            break
                        eIIGVisitor.objects.create(
                            visit=visit,
                            name=v_name,
                            designation=str(row.get(f'visitor_{i}_designation') or '').strip() or None,
                            mobile_1=str(row.get(f'visitor_{i}_mobile') or '').strip() or None,
                            email_1=str(row.get(f'visitor_{i}_email') or '').strip() or None,
                        )

                success += 1

            except Exception as e:
                errors.append(f'Row {rn}: {str(e)} — skipped.')
                skipped += 1

        return render(request, 'daks/eiig_bulk_import.html', {
            'done': True, 'success': success, 'skipped': skipped,
            'errors': errors[:50], 'total': success + skipped,
        })

    except Exception as e:
        messages.error(request, f'Import failed: {str(e)}')
        return render(request, 'daks/eiig_bulk_import.html', {})
