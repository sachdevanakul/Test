from django.apps import AppConfig

class DaksConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'daks'
    
    def ready(self):
        import daks.signals  # Register signals