"""
Reporting Module for eDMS
Generates PDF, Excel, and CSV reports
"""

import pandas as pd
from io import BytesIO
from datetime import datetime, timedelta
from django.http import HttpResponse
from django.db.models import Count, Q
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, landscape, A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, KeepTogether
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch, mm
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from .models import *

# ─── TBRL Report Constants ────────────────────────────────────────────────────
# Colours matching the official TBRL letterhead
TBRL_NAVY   = colors.HexColor('#1a1a5e')   # deep navy for borders / header text
TBRL_RED    = colors.HexColor('#cc0000')   # red for classification labels
TBRL_GREEN  = colors.HexColor('#1a6b1a')   # dark green for the I2G badge
TBRL_LGREY  = colors.HexColor('#f5f5f5')   # light grey table row alternate

# Watermark for every report
DEFAULT_WATERMARK = 'DCMM-I2G@TBRL'
# ─────────────────────────────────────────────────────────────────────────────


# ═══════════════════════════════════════════════════════════════════════════════
#  TBRL OFFICIAL REPORT LAYOUT
#  Matches the letterhead image:
#    ┌──────────────────────────────────────────────────────────────┐
#    │  RESTRICTED  (classification — top centre, red)              │
#    │ [logo] TERMINAL BALLISTICS RESEARCH LABORATORY      [I2G]   │
#    │         Sector-30, Chandigarh - 160030                       │
#    │         Dte of Control Materials & Management (DCMM)         │
#    │         Industry Interface Group (I2G)                       │
#    ├──────────────────────────────────────────────────────────────┤
#    │ Report: _______________   Period: _______ to _______         │
#    ├──────────────────────────────────────────────────────────────┤
#    │ Sr No │ Col 1 │ Col 2 │ … │ Col N                           │
#    │       │       │       │   │                                  │
#    ├──────────────────────────────────────────────────────────────┤
#    │ Copyright: I2G-DCMM  │  RESTRICTED / Page N of M  │ Generated│
#    └──────────────────────────────────────────────────────────────┘
# ═══════════════════════════════════════════════════════════════════════════════

# Heights (in points) used for page layout calculations
_HEADER_H = 1.55 * inch     # space the header block occupies at top
_FOOTER_H = 0.55 * inch     # space the footer block occupies at bottom
_META_H   = 0.35 * inch     # Report / Period line below header


def _draw_tbrl_header_footer(canvas, doc, report_name, start_date, end_date,
                              classification, watermark_text,
                              total_pages=None,
                              signatures=None, sig_page='last'):
    """
    Draw the full TBRL official letterhead header + footer on `canvas`.
    Called via onFirstPage / onLaterPages hooks in doc.build().

    signatures : list of dicts [{'name':…,'rank':…,'designation':…}, …]
                 ordered highest-rank first (left-most on the page).
    sig_page   : 'last' → only on last page; 'every' → on every page.
    total_pages: pass doc.page_count after build for "Page N of M";
                 during build use doc.page for current, None for total.
    """
    canvas.saveState()
    pw, ph = doc.pagesize          # page width, page height
    lm = doc.leftMargin
    rm = doc.rightMargin
    usable = pw - lm - rm          # usable width between margins

    current_page = canvas._pageNumber  # ReportLab internal page counter

    # ── WATERMARK (drawn first so content sits on top) ──────────────
    if watermark_text:
        canvas.saveState()
        canvas.setFont('Helvetica-Bold', 55)
        canvas.setFillColor(colors.Color(0.75, 0.75, 0.75, alpha=0.15))
        canvas.translate(pw / 2, ph / 2)
        canvas.rotate(40)
        canvas.drawCentredString(0, 0, watermark_text)
        canvas.restoreState()

    # ── OUTER PAGE BORDER (thin navy rectangle) ────────────────────
    border_pad = 6
    canvas.setStrokeColor(TBRL_NAVY)
    canvas.setLineWidth(1.2)
    canvas.rect(border_pad, border_pad, pw - 2 * border_pad, ph - 2 * border_pad)

    # ── TOP CLASSIFICATION LINE ─────────────────────────────────────
    cls_y = ph - 18
    canvas.setFont('Helvetica-Bold', 9)
    canvas.setFillColor(TBRL_RED)
    canvas.drawCentredString(pw / 2, cls_y, classification.upper())

    # ── HEADER BLOCK ────────────────────────────────────────────────
    # Spans from cls_y - 4 down to (ph - _HEADER_H)
    hdr_top    = cls_y - 4
    hdr_bottom = ph - _HEADER_H
    hdr_mid_y  = (hdr_top + hdr_bottom) / 2          # vertical centre

    # Left logo area (approximate circle, navy)
    logo_cx = lm + 0.52 * inch
    logo_cy = hdr_mid_y + 2
    logo_r  = 0.42 * inch
    # Draw decorative circle (stand-in for the DRDO/TBRL emblem)
    canvas.setStrokeColor(TBRL_NAVY)
    canvas.setFillColor(colors.HexColor('#f0f0fa'))
    canvas.setLineWidth(1.5)
    canvas.circle(logo_cx, logo_cy, logo_r, fill=1, stroke=1)
    # Inner ring
    canvas.setFillColor(TBRL_NAVY)
    canvas.setFont('Helvetica-Bold', 5.5)
    canvas.drawCentredString(logo_cx, logo_cy + logo_r * 0.55, 'DRDO')
    canvas.drawCentredString(logo_cx, logo_cy + logo_r * 0.25, 'DEFENCE R&D')
    canvas.setFont('Helvetica', 4.5)
    canvas.drawCentredString(logo_cx, logo_cy - logo_r * 0.05, 'ORGANISATION')
    canvas.setFont('Helvetica-Bold', 5)
    canvas.drawCentredString(logo_cx, logo_cy - logo_r * 0.38, 'TBRL')
    canvas.setFont('Helvetica', 4)
    canvas.drawCentredString(logo_cx, logo_cy - logo_r * 0.65, 'MINISTRY OF')
    canvas.drawCentredString(logo_cx, logo_cy - logo_r * 0.82, 'DEFENCE')
    # "DRDO / TBRL" label below circle
    canvas.setFont('Helvetica-Bold', 6.5)
    canvas.setFillColor(TBRL_NAVY)
    canvas.drawCentredString(logo_cx, hdr_bottom + 4, 'DRDO / TBRL')

    # Right I2G badge (green filled rectangle with white "I 2 G")
    badge_w, badge_h = 0.75 * inch, 0.44 * inch
    badge_x = pw - rm - badge_w
    badge_y = hdr_mid_y - badge_h / 2 + 4
    canvas.setFillColor(TBRL_GREEN)
    canvas.setStrokeColor(TBRL_GREEN)
    canvas.roundRect(badge_x, badge_y, badge_w, badge_h, 4, fill=1, stroke=0)
    canvas.setFillColor(colors.white)
    canvas.setFont('Helvetica-Bold', 20)
    canvas.drawCentredString(badge_x + badge_w / 2, badge_y + 10, 'I 2 G')

    # Centre text block
    centre_x = pw / 2
    canvas.setFillColor(TBRL_NAVY)
    # Organisation name — large bold
    canvas.setFont('Helvetica-Bold', 13)
    canvas.drawCentredString(centre_x, hdr_mid_y + 0.32 * inch,
                             'TERMINAL BALLISTICS RESEARCH LABORATORY')
    canvas.setFont('Helvetica', 9)
    canvas.drawCentredString(centre_x, hdr_mid_y + 0.13 * inch,
                             'Sector-30, Chandigarh - 160030')
    canvas.setFont('Helvetica-Bold', 9)
    canvas.drawCentredString(centre_x, hdr_mid_y - 0.06 * inch,
                             'Dte of Control Materials & Management (DCMM)')
    canvas.drawCentredString(centre_x, hdr_mid_y - 0.22 * inch,
                             'Industry Interface Group (I2G)')

    # ── DOUBLE SEPARATOR LINE below header ──────────────────────────
    sep_y = hdr_bottom - 2
    canvas.setStrokeColor(TBRL_NAVY)
    canvas.setLineWidth(1.5)
    canvas.line(lm, sep_y, pw - rm, sep_y)
    canvas.setLineWidth(0.5)
    canvas.line(lm, sep_y - 3, pw - rm, sep_y - 3)

    # ── REPORT / PERIOD META LINE ────────────────────────────────────
    meta_y = sep_y - 18
    canvas.setFillColor(colors.black)
    canvas.setFont('Helvetica-Bold', 8.5)
    canvas.drawString(lm, meta_y, 'Report :')
    # Underlined report name placeholder
    rn_x = lm + 52
    canvas.setFont('Helvetica', 8.5)
    canvas.setFillColor(TBRL_NAVY)
    canvas.drawString(rn_x, meta_y, report_name)
    canvas.setStrokeColor(TBRL_NAVY)
    canvas.setLineWidth(0.5)
    rn_end = min(rn_x + len(report_name) * 5.5 + 10, pw / 2 + 50)
    canvas.line(rn_x - 2, meta_y - 2, rn_end, meta_y - 2)

    # Period on the right
    canvas.setFillColor(colors.black)
    canvas.setFont('Helvetica-Bold', 8.5)
    period_label_x = pw / 2 + 70
    canvas.drawString(period_label_x, meta_y, 'Period :')
    canvas.setFont('Helvetica', 8.5)
    canvas.setFillColor(TBRL_NAVY)
    sd_str = start_date.strftime('%d-%b-%Y') if start_date else '—'
    ed_str = end_date.strftime('%d-%b-%Y') if end_date else '—'
    sd_x = period_label_x + 50
    canvas.drawString(sd_x, meta_y, sd_str)
    canvas.line(sd_x - 2, meta_y - 2, sd_x + len(sd_str) * 5.5, meta_y - 2)
    to_x = sd_x + len(sd_str) * 5.5 + 10
    canvas.setFillColor(colors.black)
    canvas.setFont('Helvetica', 8.5)
    canvas.drawString(to_x, meta_y, 'to')
    ed_x = to_x + 18
    canvas.setFillColor(TBRL_NAVY)
    canvas.drawString(ed_x, meta_y, ed_str)
    canvas.line(ed_x - 2, meta_y - 2, ed_x + len(ed_str) * 5.5, meta_y - 2)

    # Thin line below meta row
    canvas.setStrokeColor(TBRL_NAVY)
    canvas.setLineWidth(0.4)
    canvas.line(lm, meta_y - 8, pw - rm, meta_y - 8)

    # ── FOOTER ──────────────────────────────────────────────────────
    # Separator above footer
    ft_sep_y = _FOOTER_H + 4
    canvas.setStrokeColor(TBRL_NAVY)
    canvas.setLineWidth(1.2)
    canvas.line(lm, ft_sep_y, pw - rm, ft_sep_y)

    ft_y = _FOOTER_H - 10
    # Left: copyright
    canvas.setFillColor(colors.black)
    canvas.setFont('Helvetica', 7.5)
    canvas.drawString(lm, ft_y, 'Copyright :  I2G -DCMM')

    # Centre: classification + page number
    page_str = f'Page {current_page}'
    if total_pages:
        page_str += f' of {total_pages}'
    canvas.setFont('Helvetica-Bold', 8)
    canvas.setFillColor(TBRL_RED)
    canvas.drawCentredString(pw / 2, ft_y + 8, classification.upper())
    canvas.setFillColor(colors.black)
    canvas.setFont('Helvetica', 7.5)
    canvas.drawCentredString(pw / 2, ft_y, page_str)

    # Right: generated timestamp
    gen_str = f"Generated on :  {datetime.now().strftime('%d-%b-%Y %H:%M')}"
    canvas.setFont('Helvetica', 7.5)
    canvas.setFillColor(colors.black)
    canvas.drawRightString(pw - rm, ft_y, gen_str)

    # ── SIGNATURES (last page only, or every page per user choice) ──
    is_last = (total_pages is not None and current_page == total_pages)
    show_sigs = signatures and (sig_page == 'every' or is_last)
    if show_sigs:
        sig_y_top = ft_sep_y - 6
        sig_slot_w = usable / len(signatures)
        for i, sig in enumerate(signatures):
            sx = lm + i * sig_slot_w
            # Signature box
            canvas.setStrokeColor(colors.HexColor('#aaaaaa'))
            canvas.setLineWidth(0.5)
            sig_line_y = sig_y_top - 28
            canvas.line(sx + 8, sig_line_y, sx + sig_slot_w - 16, sig_line_y)
            # Name / Rank / Designation
            canvas.setFont('Helvetica-Bold', 7)
            canvas.setFillColor(colors.black)
            canvas.drawCentredString(sx + sig_slot_w / 2, sig_line_y - 10,
                                     sig.get('name', ''))
            canvas.setFont('Helvetica', 6.5)
            canvas.drawCentredString(sx + sig_slot_w / 2, sig_line_y - 20,
                                     sig.get('rank', ''))
            canvas.drawCentredString(sx + sig_slot_w / 2, sig_line_y - 29,
                                     sig.get('designation', ''))

    canvas.restoreState()


def _tbrl_top_margin(has_signatures=False):
    """Return the top margin needed so the flowable content starts below
    the header + meta row.  Signature block sits in the footer zone."""
    return _HEADER_H + _META_H + 0.25 * inch


def get_date_range(report_type):
    """Get date range based on report type"""
    today = datetime.now().date()
    
    if report_type == 'daily':
        return today, today
    elif report_type == 'weekly':
        start = today - timedelta(days=7)
        return start, today
    elif report_type == 'monthly':
        start = today.replace(day=1)
        return start, today
    elif report_type == 'yearly':
        start = today.replace(month=1, day=1)
        return start, today
    else:
        return None, None

def get_report_data(start_date, end_date, category=None, nature=None):
    """Fetch data for reports.

    Date basis (this is the fix for the reporting date-basis issue):
    - INCOMING daks are filtered by receipt_date — the day TBRL actually
      received the dak, not the day someone happened to type it into the
      system (which could be days later for a backlog entry).
    - OUTGOING daks are filtered by dispatch_date (from DakDispatchDetails)
      — the day it was actually sent, not the day the record was created.
      An outgoing dak with no dispatch recorded yet hasn't been "sent" in
      any meaningful sense, so it correctly won't appear in a date-ranged
      report until dispatch is logged.
    """
    daks = DakMaster.objects.filter(
        is_active=True
    ).filter(
        Q(dak_direction='INCOMING', receipt_date__gte=start_date, receipt_date__lte=end_date) |
        Q(dak_direction='OUTGOING', dispatch_details__dispatch_date__gte=start_date,
          dispatch_details__dispatch_date__lte=end_date)
    ).select_related('dak_category', 'nature', 'thread', 'created_by', 'dispatch_details')

    if category:
        daks = daks.filter(dak_category__category_code=category)

    if nature:
        daks = daks.filter(nature__nature_name=nature)

    return daks


def report_basis_date(dak):
    """The one date a report should show/sort by for this dak — receipt
    date if incoming, dispatch date if outgoing. Used by the export
    functions so the displayed date matches what was actually filtered on."""
    if dak.dak_direction == 'INCOMING':
        return dak.receipt_date
    try:
        return dak.dispatch_details.dispatch_date
    except DakDispatchDetails.DoesNotExist:
        return None

def generate_excel_report(data, title):
    """Generate Excel report"""
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment
    
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = title[:31]  # Excel sheet name max 31 chars
    
    # Headers
    headers = ['S.No', 'Dak Index', 'Direction', 'Category', 'Nature', 
               'Subject', 'Report Date', 'Issue Date', 'Reply Status', 'Created By', 'Created On']
    
    # Style headers
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
    
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center')
    
    # Add data
    for row_idx, dak in enumerate(data, 2):
        basis_date = report_basis_date(dak)
        ws.cell(row=row_idx, column=1, value=row_idx-1)
        ws.cell(row=row_idx, column=2, value=dak.dak_index_no)
        ws.cell(row=row_idx, column=3, value=dak.dak_direction)
        ws.cell(row=row_idx, column=4, value=dak.dak_category.category_code)
        ws.cell(row=row_idx, column=5, value=dak.nature.nature_name if dak.nature else '-')
        ws.cell(row=row_idx, column=6, value=dak.subject[:100])
        ws.cell(row=row_idx, column=7, value=basis_date.strftime('%d-%b-%Y') if basis_date else '-')
        ws.cell(row=row_idx, column=8, value=dak.issue_date.strftime('%d-%b-%Y'))
        ws.cell(row=row_idx, column=9, value='Pending' if dak.reply_mode == 'NOT_YET' else 'Replied')
        ws.cell(row=row_idx, column=10, value=dak.created_by.username if dak.created_by else 'System')
        ws.cell(row=row_idx, column=11, value=dak.created_on.strftime('%d-%b-%Y %H:%M'))
    
    # Auto-adjust column widths
    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = len(str(cell.value))
            except:
                pass
        adjusted_width = min(max_length + 2, 50)
        ws.column_dimensions[column_letter].width = adjusted_width
    
    # Save to response
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = f'attachment; filename="{title}_{datetime.now().strftime("%Y%m%d")}.xlsx"'
    wb.save(response)
    return response

def generate_csv_report(data, title):
    """Generate CSV report"""
    import csv
    
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="{title}_{datetime.now().strftime("%Y%m%d")}.csv"'
    
    writer = csv.writer(response)
    
    # Write headers
    writer.writerow(['S.No', 'Dak Index', 'Direction', 'Category', 'Nature', 
                     'Subject', 'Report Date', 'Issue Date', 'Reply Status', 'Created By', 'Created On'])
    
    # Write data
    for idx, dak in enumerate(data, 1):
        basis_date = report_basis_date(dak)
        writer.writerow([
            idx, dak.dak_index_no, dak.dak_direction, dak.dak_category.category_code,
            dak.nature.nature_name if dak.nature else '-', dak.subject[:100],
            basis_date.strftime('%d-%b-%Y') if basis_date else '-',
            dak.issue_date.strftime('%d-%b-%Y'), 
            'Pending' if dak.reply_mode == 'NOT_YET' else 'Replied',
            dak.created_by.username if dak.created_by else 'System',
            dak.created_on.strftime('%d-%b-%Y %H:%M')
        ])
    
    return response

def generate_module_pdf_report(queryset, columns, title,
                               watermark_text=None,
                               classification='RESTRICTED',
                               start_date=None, end_date=None,
                               signatures=None, sig_page='last'):
    """
    Generate a PDF report in the official TBRL letterhead format.

    Layout (matches the provided image exactly):
    ┌─────────────────────────────────────────────────────────────┐
    │  RESTRICTED  (classification — top centre, red)             │
    │ [DRDO logo]  TERMINAL BALLISTICS RESEARCH LABORATORY [I2G] │
    │              Sector-30, Chandigarh - 160030                 │
    │              Dte of Control Materials & Management (DCMM)   │
    │              Industry Interface Group (I2G)                 │
    ├═════════════════════════════════════════════════════════════╡
    │ Report: <title>              Period: <start> to <end>       │
    ├─────────────────────────────────────────────────────────────┤
    │ Sr No │ Col 1 │ Col 2 │ … │ Col N  (navy-bordered table)   │
    ├─────────────────────────────────────────────────────────────┤
    │ Copyright: I2G-DCMM │ RESTRICTED / Page N of M │ Generated │
    └─────────────────────────────────────────────────────────────┘
    Diagonal watermark: DCMM-I2G@TBRL (light grey).
    Signatures on last page (or every page), left = highest rank.
    """
    from .report_columns import resolve_value

    wm = watermark_text if watermark_text is not None else DEFAULT_WATERMARK
    if start_date is None:
        start_date = datetime.now().date()
    if end_date is None:
        end_date = datetime.now().date()

    # ── Page setup: landscape A4 ────────────────────────────────────
    page_size = landscape(letter)       # 11 × 8.5 in
    lm = rm = 0.45 * inch
    tm = _tbrl_top_margin()             # space for header block
    bm = _FOOTER_H + 0.45 * inch       # space for footer + sigs

    # Build table data
    rows_data = []
    for idx, obj in enumerate(queryset, 1):
        row = [str(idx)]
        for c in columns:
            val = resolve_value(obj, c['accessor'])
            row.append(str(val) if val is not None else '')
        rows_data.append(row)

    header_row = ['Sr No'] + [c['label'] for c in columns]
    table_data = [header_row] + rows_data

    n_cols = len(header_row)
    usable_w = page_size[0] - lm - rm
    srno_w   = 0.42 * inch
    rest_w   = (usable_w - srno_w) / max(n_cols - 1, 1)
    col_widths = [srno_w] + [rest_w] * (n_cols - 1)

    # Navy-bordered table matching the image
    data_table = Table(table_data, colWidths=col_widths, repeatRows=1)
    data_table.setStyle(TableStyle([
        # Header row
        ('BACKGROUND',   (0, 0), (-1, 0),  colors.white),
        ('TEXTCOLOR',    (0, 0), (-1, 0),  TBRL_NAVY),
        ('FONTNAME',     (0, 0), (-1, 0),  'Helvetica-Bold'),
        ('FONTSIZE',     (0, 0), (-1, 0),  8),
        ('BOTTOMPADDING',(0, 0), (-1, 0),  7),
        ('TOPPADDING',   (0, 0), (-1, 0),  6),
        # Data rows
        ('FONTNAME',     (0, 1), (-1, -1), 'Helvetica'),
        ('FONTSIZE',     (0, 1), (-1, -1), 7.5),
        ('TOPPADDING',   (0, 1), (-1, -1), 5),
        ('BOTTOMPADDING',(0, 1), (-1, -1), 5),
        # Alignment
        ('ALIGN',        (0, 0), (0, -1),  'CENTER'),   # Sr No centred
        ('ALIGN',        (1, 0), (-1, -1), 'CENTER'),
        ('VALIGN',       (0, 0), (-1, -1), 'MIDDLE'),
        # Navy grid borders (matching image exactly)
        ('GRID',         (0, 0), (-1, -1), 0.6, TBRL_NAVY),
        ('BOX',          (0, 0), (-1, -1), 1.0, TBRL_NAVY),
    ]))

    # We need total_pages for the footer "Page N of M".
    # Use a two-pass approach: build to a buffer to count pages, then build to response.
    buf = BytesIO()
    _build_tbrl_pdf(buf, page_size, lm, rm, tm, bm,
                    [data_table], title, start_date, end_date,
                    classification, wm, signatures, sig_page)

    # Count pages from first pass
    buf.seek(0)
    try:
        from pypdf import PdfReader as _PR
        total_pages = len(_PR(buf).pages)
    except Exception:
        try:
            from PyPDF2 import PdfReader as _PR2
            total_pages = len(_PR2(buf).pages)
        except Exception:
            total_pages = None

    # Second pass to response with correct total
    response = HttpResponse(content_type='application/pdf')
    safe_title = title.replace(' ', '_')
    response['Content-Disposition'] = (
        f'attachment; filename="{safe_title}_{datetime.now().strftime("%Y%m%d")}.pdf"'
    )
    _build_tbrl_pdf(response, page_size, lm, rm, tm, bm,
                    [data_table], title, start_date, end_date,
                    classification, wm, signatures, sig_page,
                    total_pages=total_pages)
    return response


def _build_tbrl_pdf(dest, page_size, lm, rm, tm, bm,
                    elements, title, start_date, end_date,
                    classification, watermark_text,
                    signatures, sig_page, total_pages=None):
    """Internal helper: build the TBRL-formatted PDF into `dest`."""
    doc = SimpleDocTemplate(
        dest, pagesize=page_size,
        topMargin=tm, bottomMargin=bm,
        leftMargin=lm, rightMargin=rm,
    )

    def _hf(canvas, doc):
        _draw_tbrl_header_footer(
            canvas, doc,
            report_name=title,
            start_date=start_date,
            end_date=end_date,
            classification=classification,
            watermark_text=watermark_text,
            total_pages=total_pages,
            signatures=signatures,
            sig_page=sig_page,
        )

    doc.build(elements, onFirstPage=_hf, onLaterPages=_hf)


def generate_module_docx_report(queryset, columns, title,
                                watermark_text=None,
                                classification='RESTRICTED',
                                start_date=None, end_date=None,
                                signatures=None, sig_page='last'):
    """
    Generate a Word (.docx) report with the TBRL header style.
    The header block (organisation name, classification, period) repeats
    on every page natively in Word via the header section.
    Signature lines are appended after the table.
    """
    from docx import Document
    from docx.shared import Pt, RGBColor, Inches, Cm
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
    from .report_columns import resolve_value

    wm = watermark_text if watermark_text is not None else DEFAULT_WATERMARK

    document = Document()
    section = document.sections[0]
    # Landscape A4
    section.orientation = 1
    section.page_width, section.page_height = section.page_height, section.page_width
    section.left_margin   = Cm(1.2)
    section.right_margin  = Cm(1.2)
    section.top_margin    = Cm(1.5)
    section.bottom_margin = Cm(1.5)

    # ── Word header (repeats every page) ────────────────────────────
    hdr = section.header
    # Classification line
    cls_para = hdr.paragraphs[0]
    cls_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    cls_run = cls_para.add_run(classification.upper())
    cls_run.font.size = Pt(10)
    cls_run.font.bold = True
    cls_run.font.color.rgb = RGBColor(0xCC, 0x00, 0x00)  # red

    # Organisation block
    for text, bold, size in [
        ('TERMINAL BALLISTICS RESEARCH LABORATORY', True,  13),
        ('Sector-30, Chandigarh - 160030',           False,  9),
        ('Dte of Control Materials & Management (DCMM)', True, 9),
        ('Industry Interface Group (I2G)',            True,  9),
    ]:
        p = hdr.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(text)
        r.font.size = Pt(size)
        r.font.bold = bold
        r.font.color.rgb = RGBColor(0x1a, 0x1a, 0x5e)

    # Report name / period row
    meta_p = hdr.add_paragraph()
    meta_p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    meta_r = meta_p.add_run(
        f"Report: {title}     "
        f"Period: {start_date.strftime('%d-%b-%Y') if start_date else '—'}"
        f" to {end_date.strftime('%d-%b-%Y') if end_date else '—'}"
    )
    meta_r.font.size = Pt(8.5)

    # Watermark paragraph (light grey, large)
    wm_p = hdr.add_paragraph()
    wm_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    wm_r = wm_p.add_run(wm)
    wm_r.font.size = Pt(28)
    wm_r.font.bold = True
    wm_r.font.color.rgb = RGBColor(0xDD, 0xDD, 0xDD)

    # ── Data table ──────────────────────────────────────────────────
    document.add_paragraph()  # breathing room
    table = document.add_table(rows=1, cols=len(columns) + 1)
    table.style = 'Table Grid'
    hdr_cells = table.rows[0].cells
    hdr_cells[0].text = 'Sr No'
    for i, c in enumerate(columns, 1):
        hdr_cells[i].text = c['label']
    # Bold navy header
    for cell in hdr_cells:
        for para in cell.paragraphs:
            for run in para.runs:
                run.font.bold = True
                run.font.size = Pt(8)
                run.font.color.rgb = RGBColor(0x1a, 0x1a, 0x5e)

    for idx, obj in enumerate(queryset, 1):
        row_cells = table.add_row().cells
        row_cells[0].text = str(idx)
        for i, c in enumerate(columns, 1):
            val = resolve_value(obj, c['accessor'])
            row_cells[i].text = str(val) if val is not None else ''

    # ── Footer (classification + page number) ──────────────────────
    ftr = section.footer
    ftr_p = ftr.paragraphs[0]
    ftr_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    ftr_cls = ftr_p.add_run(classification.upper() + '    ')
    ftr_cls.font.size = Pt(8)
    ftr_cls.font.bold = True
    ftr_cls.font.color.rgb = RGBColor(0xCC, 0x00, 0x00)
    ftr_pg = ftr_p.add_run('Page ')
    ftr_pg.font.size = Pt(8)
    # Add auto page-number field
    fldChar = OxmlElement('w:fldChar')
    fldChar.set(qn('w:fldCharType'), 'begin')
    instrText = OxmlElement('w:instrText')
    instrText.set(qn('xml:space'), 'preserve')
    instrText.text = ' PAGE '
    fldChar2 = OxmlElement('w:fldChar')
    fldChar2.set(qn('w:fldCharType'), 'end')
    run_elem = ftr_pg._r
    run_elem.append(fldChar)
    run_elem.append(instrText)
    run_elem.append(fldChar2)
    gen_r = ftr_p.add_run(
        f"    Copyright: I2G-DCMM    "
        f"Generated: {datetime.now().strftime('%d-%b-%Y %H:%M')}"
    )
    gen_r.font.size = Pt(7)

    # ── Signatures (at end of document) ────────────────────────────
    if signatures:
        document.add_paragraph()
        sig_tbl = document.add_table(rows=3, cols=len(signatures))
        sig_tbl.style = 'Table Grid'
        # Row 0: signature line (empty, just border bottom)
        # Row 1: Name (bold)
        # Row 2: Rank | Designation
        for col_i, sig in enumerate(signatures):
            sig_tbl.cell(0, col_i).text = '(Signature)'
            name_cell = sig_tbl.cell(1, col_i)
            name_cell.text = sig.get('name', '')
            for p in name_cell.paragraphs:
                for r in p.runs:
                    r.font.bold = True
                    r.font.size = Pt(8)
            sig_tbl.cell(2, col_i).text = (
                f"{sig.get('rank', '')} / {sig.get('designation', '')}"
            )

    response = HttpResponse(
        content_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    )
    safe_title = title.replace(' ', '_')
    response['Content-Disposition'] = (
        f'attachment; filename="{safe_title}_{datetime.now().strftime("%Y%m%d")}.docx"'
    )
    document.save(response)
    return response


def get_module_report_data(module_key, start_date=None, end_date=None):
    """Queryset for a module's quick report, optionally filtered by
    created_at date range. Each module gets its own select_related list
    matching the FK columns its default report columns actually use."""
    from .models import eDW, eTOT, eIIGVisit

    if module_key == 'edw':
        qs = eDW.objects.select_related('company_name', 'group', 'dak', 'created_by')
    elif module_key == 'etot':
        qs = eTOT.objects.select_related('technical_group', 'point_of_contact', 'licensee_company', 'created_by')
    elif module_key == 'eiig':
        qs = eIIGVisit.objects.select_related('created_by')
    else:
        return None

    if start_date:
        qs = qs.filter(created_at__date__gte=start_date)
    if end_date:
        qs = qs.filter(created_at__date__lte=end_date)
    return qs.order_by('-created_at')


def generate_module_excel_report(queryset, columns, title):
    """Generic Excel export for any module (eDW/eToT/eIIG) and any column
    subset — same idea as generate_excel_report, but not hard-coded to
    Dak fields. Fills the Excel-shaped gap in the report builder, which
    previously only offered PDF and Word."""
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment
    from .report_columns import resolve_value

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = title[:31]

    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="0F766E", end_color="0F766E", fill_type="solid")

    ws.cell(row=1, column=1, value='S.No').font = header_font
    ws.cell(row=1, column=1).fill = header_fill
    for col, c in enumerate(columns, 2):
        cell = ws.cell(row=1, column=col, value=c['label'])
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center')

    for row_idx, obj in enumerate(queryset, 2):
        ws.cell(row=row_idx, column=1, value=row_idx - 1)
        for col, c in enumerate(columns, 2):
            val = resolve_value(obj, c['accessor'])
            ws.cell(row=row_idx, column=col, value=str(val) if val is not None else '')

    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = len(str(cell.value))
            except Exception:
                pass
        ws.column_dimensions[column_letter].width = min(max_length + 2, 50)

    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = f'attachment; filename="{title}_{datetime.now().strftime("%Y%m%d")}.xlsx"'
    wb.save(response)
    return response


def generate_module_csv_report(queryset, columns, title):
    """Generic CSV export for any module and any column subset."""
    import csv
    from .report_columns import resolve_value

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="{title}_{datetime.now().strftime("%Y%m%d")}.csv"'
    writer = csv.writer(response)
    writer.writerow(['S.No'] + [c['label'] for c in columns])
    for idx, obj in enumerate(queryset, 1):
        row = [idx]
        for c in columns:
            val = resolve_value(obj, c['accessor'])
            row.append(val if val is not None else '')
        writer.writerow(row)
    return response



def generate_pdf_report(data, title, start_date, end_date,
                        watermark_text=None, classification='RESTRICTED',
                        signatures=None, sig_page='last'):
    """
    Generate the Dak-section PDF report in TBRL official letterhead format.
    Watermark default: DCMM-I2G@TBRL.  Classification shown top + footer.
    """
    data = list(data)

    # Summary stats mini-table (sits above the main data table)
    stats = {
        'Total Daks':    len(data),
        'Incoming':      sum(1 for d in data if d.dak_direction == 'INCOMING'),
        'Outgoing':      sum(1 for d in data if d.dak_direction == 'OUTGOING'),
        'Pending Reply': sum(1 for d in data if d.reply_mode == 'NOT_YET'),
    }
    stats_data = [['Category', 'Count']] + [[k, str(v)] for k, v in stats.items()]
    stats_table = Table(stats_data, colWidths=[2 * inch, 1.2 * inch])
    stats_table.setStyle(TableStyle([
        ('BACKGROUND',   (0, 0), (-1, 0),  TBRL_NAVY),
        ('TEXTCOLOR',    (0, 0), (-1, 0),  colors.white),
        ('FONTNAME',     (0, 0), (-1, 0),  'Helvetica-Bold'),
        ('FONTSIZE',     (0, 0), (-1, 0),  8),
        ('ALIGN',        (0, 0), (-1, -1), 'CENTER'),
        ('FONTSIZE',     (0, 1), (-1, -1), 8),
        ('GRID',         (0, 0), (-1, -1), 0.6, TBRL_NAVY),
        ('BOX',          (0, 0), (-1, -1), 1.0, TBRL_NAVY),
    ]))

    # Main data table
    header_row = ['Sr No', 'Dak Index', 'Direction', 'Category', 'Date', 'Reply Status']
    rows = []
    for idx, dak in enumerate(data, 1):
        basis_date = report_basis_date(dak)
        rows.append([
            str(idx),
            dak.dak_index_no,
            dak.dak_direction,
            dak.dak_category.category_code,
            basis_date.strftime('%d-%b-%Y') if basis_date else '—',
            'Pending' if dak.reply_mode == 'NOT_YET' else 'Replied',
        ])
    table_data = [header_row] + rows
    col_widths = [0.5*inch, 1.4*inch, 0.9*inch, 0.9*inch, 1.0*inch, 0.9*inch]
    data_table = Table(table_data, colWidths=col_widths, repeatRows=1)
    data_table.setStyle(TableStyle([
        ('BACKGROUND',   (0, 0), (-1, 0),  colors.white),
        ('TEXTCOLOR',    (0, 0), (-1, 0),  TBRL_NAVY),
        ('FONTNAME',     (0, 0), (-1, 0),  'Helvetica-Bold'),
        ('FONTSIZE',     (0, 0), (-1, 0),  8),
        ('BOTTOMPADDING',(0, 0), (-1, 0),  6),
        ('TOPPADDING',   (0, 0), (-1, 0),  6),
        ('FONTNAME',     (0, 1), (-1, -1), 'Helvetica'),
        ('FONTSIZE',     (0, 1), (-1, -1), 7.5),
        ('ALIGN',        (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN',       (0, 0), (-1, -1), 'MIDDLE'),
        ('TOPPADDING',   (0, 1), (-1, -1), 4),
        ('BOTTOMPADDING',(0, 1), (-1, -1), 4),
        ('GRID',         (0, 0), (-1, -1), 0.6, TBRL_NAVY),
        ('BOX',          (0, 0), (-1, -1), 1.0, TBRL_NAVY),
    ]))

    elements = [stats_table, Spacer(1, 14), data_table]

    wm = watermark_text if watermark_text is not None else DEFAULT_WATERMARK

    page_size = landscape(letter)
    lm = rm = 0.45 * inch
    tm = _tbrl_top_margin()
    bm = _FOOTER_H + 0.45 * inch

    # Two-pass for total page count
    buf = BytesIO()
    _build_tbrl_pdf(buf, page_size, lm, rm, tm, bm,
                    elements, title, start_date, end_date,
                    classification, wm, signatures, sig_page)
    buf.seek(0)
    try:
        from pypdf import PdfReader as _PR
        total_pages = len(_PR(buf).pages)
    except Exception:
        try:
            from PyPDF2 import PdfReader as _PR2
            total_pages = len(_PR2(buf).pages)
        except Exception:
            total_pages = None

    response = HttpResponse(content_type='application/pdf')
    safe_title = title.replace(' ', '_')
    response['Content-Disposition'] = (
        f'attachment; filename="{safe_title}_{datetime.now().strftime("%Y%m%d")}.pdf"'
    )
    _build_tbrl_pdf(response, page_size, lm, rm, tm, bm,
                    elements, title, start_date, end_date,
                    classification, wm, signatures, sig_page,
                    total_pages=total_pages)
    return response