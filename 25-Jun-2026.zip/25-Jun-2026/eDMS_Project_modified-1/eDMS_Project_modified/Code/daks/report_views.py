"""
Report Views for eDMS
Handles report generation requests
"""

from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from datetime import datetime, timedelta
from .models import *
from .reports import *

@login_required
def report_dashboard(request):

    # ── Module access guard ──────────────────────────────────────
    if not request.user.is_staff:
        from .models import UserProfile
        try:
            profile = request.user.profile
        except UserProfile.DoesNotExist:
            profile = UserProfile.objects.create(user=request.user)
        if not getattr(profile, 'can_access_reports', False):
            from django.contrib import messages as _msg
            _msg.error(request, 'You do not have permission to access this module.')
            return redirect('daks:home')
    # ─────────────────────────────────────────────────────────────
    """Report selection dashboard with statistics and category list."""
    total_daks    = DakMaster.objects.filter(is_active=True).count()
    # Resolved = any reply was sent (MAIL, LETTER, or ION)
    resolved_daks = DakMaster.objects.filter(
        is_active=True
    ).exclude(reply_mode='NOT_YET').count()
    pending_daks  = DakMaster.objects.filter(is_active=True, reply_mode='NOT_YET').count()
    total_threads = DakThread.objects.count()
    categories    = DakCategoryMaster.objects.filter(is_active=True).order_by('category_name')

    return render(request, 'daks/report_dashboard.html', {
        'total_daks':    total_daks,
        'resolved_daks': resolved_daks,
        'pending_daks':  pending_daks,
        'total_threads': total_threads,
        'categories':    categories,
        'module_report_list': [
            ('edw', 'eDW', 'fa-coins'),
            ('etot', 'eToT', 'fa-sync-alt'),
            ('eiig', 'eIIG', 'fa-microscope'),
        ],
    })

@login_required
def generate_daily_report(request):
    """Generate daily report"""
    today = datetime.now().date()
    format_type = request.GET.get('format', 'excel')
    
    data = get_report_data(today, today)
    
    if format_type == 'excel':
        return generate_excel_report(data, 'Daily_Dak_Report')
    elif format_type == 'csv':
        return generate_csv_report(data, 'Daily_Dak_Report')
    elif format_type == 'pdf':
        return generate_pdf_report(data, 'Daily Dak Report', today, today)
    
    return HttpResponse("Invalid format", status=400)

@login_required
def generate_monthly_report(request):
    """Generate monthly report"""
    today = datetime.now().date()
    start_date = today.replace(day=1)
    
    format_type = request.GET.get('format', 'excel')
    
    data = get_report_data(start_date, today)
    
    if format_type == 'excel':
        return generate_excel_report(data, 'Monthly_Dak_Report')
    elif format_type == 'csv':
        return generate_csv_report(data, 'Monthly_Dak_Report')
    elif format_type == 'pdf':
        return generate_pdf_report(data, 'Monthly Dak Report', start_date, today)
    
    return HttpResponse("Invalid format", status=400)

@login_required
def generate_range_report(request):
    """Generate a report for a user-chosen start/end date — same date
    basis as the other reports (receipt_date for incoming, dispatch_date
    for outgoing), just with a range the user picks instead of a fixed
    daily/monthly window."""
    format_type = request.GET.get('format', 'excel')
    start_str = request.GET.get('start_date', '')
    end_str = request.GET.get('end_date', '')

    try:
        start_date = datetime.strptime(start_str, '%Y-%m-%d').date()
        end_date = datetime.strptime(end_str, '%Y-%m-%d').date()
    except ValueError:
        return HttpResponse("Please provide valid start_date and end_date (YYYY-MM-DD).", status=400)

    if start_date > end_date:
        return HttpResponse("start_date must be before end_date.", status=400)

    data = get_report_data(start_date, end_date)

    if format_type == 'excel':
        return generate_excel_report(data, 'Custom_Range_Dak_Report')
    elif format_type == 'csv':
        return generate_csv_report(data, 'Custom_Range_Dak_Report')
    elif format_type == 'pdf':
        return generate_pdf_report(data, 'Custom Range Dak Report', start_date, end_date)

    return HttpResponse("Invalid format", status=400)


@login_required
def generate_module_quick_report(request, module_key):
    """One-click report for a module (eDW/eToT/eIIG) — curated default
    columns, in TBRL official format. Classification defaults to RESTRICTED
    but can be overridden via ?classification= query param."""
    from .models import UserProfile
    from .report_columns import MODULE_REGISTRY, get_default_columns

    info = MODULE_REGISTRY.get(module_key)
    if not info:
        return HttpResponse('Unknown module.', status=404)

    if not request.user.is_staff:
        try:
            profile = request.user.profile
        except UserProfile.DoesNotExist:
            profile = UserProfile.objects.create(user=request.user)
        if not getattr(profile, f'can_access_{module_key}', False):
            from django.contrib import messages as _msg
            _msg.error(request, 'You do not have permission to access this module.')
            return redirect('daks:home')

    start_str = request.GET.get('start_date') or None
    end_str   = request.GET.get('end_date') or None
    fmt       = request.GET.get('format', 'pdf').lower()
    classification = request.GET.get('classification', 'RESTRICTED').strip() or 'RESTRICTED'

    start_date = end_date = None
    if start_str:
        try:
            start_date = datetime.strptime(start_str, '%Y-%m-%d').date()
        except ValueError:
            pass
    if end_str:
        try:
            end_date = datetime.strptime(end_str, '%Y-%m-%d').date()
        except ValueError:
            pass

    queryset = get_module_report_data(module_key, start_str, end_str)
    columns  = get_default_columns(module_key)
    title    = f"{info['label']} Report"

    if fmt == 'xlsx':
        return generate_module_excel_report(queryset, columns, title)
    elif fmt == 'csv':
        return generate_module_csv_report(queryset, columns, title)
    elif fmt == 'docx':
        return generate_module_docx_report(
            queryset, columns, title,
            classification=classification,
            start_date=start_date, end_date=end_date,
        )
    else:
        return generate_module_pdf_report(
            queryset, columns, title,
            classification=classification,
            start_date=start_date, end_date=end_date,
        )


@login_required
def report_builder(request):
    """Column-picker report builder (#21) — admin picks a module
    (eDW/eToT/eIIG), checks which columns to include, picks PDF or DOCX,
    and gets a watermarked export with just those columns."""
    if not request.user.is_staff:
        from django.contrib import messages as _msg
        _msg.error(request, 'You do not have permission to access this module.')
        return redirect('daks:home')

    from .report_columns import MODULE_REGISTRY
    modules = {
        key: {'label': info['label'], 'columns': info['columns']}
        for key, info in MODULE_REGISTRY.items()
    }
    return render(request, 'daks/report_builder.html', {'modules_json': modules})


@login_required
def generate_module_report(request):
    """Generate the report builder's export. POST only."""
    if not request.user.is_staff:
        return HttpResponse("Staff access required.", status=403)
    if request.method != 'POST':
        return HttpResponse("POST required.", status=405)

    from .report_columns import MODULE_REGISTRY

    module_key   = request.POST.get('module')
    format_type  = request.POST.get('format', 'pdf')
    selected_keys= request.POST.getlist('columns')
    watermark_text = request.POST.get('watermark', '').strip() or None  # None → default

    # ── Classification (SECRET / CONFIDENTIAL / RESTRICTED / etc.) ─
    classification = request.POST.get('classification', 'RESTRICTED').strip() or 'RESTRICTED'

    # ── Signatures ──────────────────────────────────────────────────
    sig_needed = request.POST.get('signatures_needed', 'no') == 'yes'
    sig_page   = request.POST.get('sig_page', 'last')           # 'last' or 'every'
    signatures = []
    if sig_needed:
        try:
            sig_count = min(int(request.POST.get('sig_count', 0)), 5)
        except (ValueError, TypeError):
            sig_count = 0
        for i in range(1, sig_count + 1):
            name  = request.POST.get(f'sig_name_{i}', '').strip()
            rank  = request.POST.get(f'sig_rank_{i}', '').strip()
            desig = request.POST.get(f'sig_designation_{i}', '').strip()
            if name or rank or desig:
                signatures.append({'name': name, 'rank': rank, 'designation': desig})

    info = MODULE_REGISTRY.get(module_key)
    if not info:
        return HttpResponse("Unknown module.", status=400)

    all_columns = {c['key']: c for c in info['columns']}
    columns = [all_columns[k] for k in selected_keys if k in all_columns]
    if not columns:
        return HttpResponse("Select at least one column.", status=400)

    queryset = info['model'].objects.all().order_by(
        '-created_at' if hasattr(info['model'], 'created_at') else '-id'
    )

    start_date = end_date = None
    start_str = request.POST.get('start_date', '').strip()
    end_str   = request.POST.get('end_date', '').strip()
    if start_str and end_str and hasattr(info['model'], 'created_at'):
        try:
            start_date = datetime.strptime(start_str, '%Y-%m-%d').date()
            end_date   = datetime.strptime(end_str,   '%Y-%m-%d').date()
            queryset = queryset.filter(
                created_at__date__gte=start_date,
                created_at__date__lte=end_date,
            )
        except ValueError:
            pass

    title = f"{info['label']} Report"

    if format_type == 'docx':
        return generate_module_docx_report(
            queryset, columns, title,
            watermark_text=watermark_text,
            classification=classification,
            start_date=start_date,
            end_date=end_date,
            signatures=signatures,
            sig_page=sig_page,
        )
    return generate_module_pdf_report(
        queryset, columns, title,
        watermark_text=watermark_text,
        classification=classification,
        start_date=start_date,
        end_date=end_date,
        signatures=signatures,
        sig_page=sig_page,
    )


@login_required
def generate_category_report(request):
    """Generate category-wise report"""
    category = request.GET.get('category')
    format_type = request.GET.get('format', 'excel')
    today = datetime.now().date()
    start_date = today.replace(day=1)
    
    data = get_report_data(start_date, today, category=category)
    
    category_name = category if category else 'All'
    
    if format_type == 'excel':
        return generate_excel_report(data, f'Category_{category_name}_Report')
    elif format_type == 'csv':
        return generate_csv_report(data, f'Category_{category_name}_Report')
    elif format_type == 'pdf':
        return generate_pdf_report(data, f'Category {category_name} Report', start_date, today)
    
    return HttpResponse("Invalid format", status=400)

@login_required
def generate_pending_report(request):
    """Generate pending daks report"""
    format_type = request.GET.get('format', 'excel')
    
    data = DakMaster.objects.filter(
        is_active=True,
        reply_mode='NOT_YET'
    ).select_related('dak_category', 'nature', 'thread', 'created_by')
    
    if format_type == 'excel':
        return generate_excel_report(data, 'Pending_Daks_Report')
    elif format_type == 'csv':
        return generate_csv_report(data, 'Pending_Daks_Report')
    elif format_type == 'pdf':
        today = datetime.now().date()
        return generate_pdf_report(data, 'Pending Daks Report', today, today)
    
    return HttpResponse("Invalid format", status=400)

@login_required
def generate_thread_report(request):
    """Generate thread summary report"""
    format_type = request.GET.get('format', 'excel')
    
    threads = DakThread.objects.all().order_by('-last_activity')
    
    # Convert to list for report
    data = []
    for thread in threads:
        data.append({
            'thread_code': thread.thread_code,
            'subject_summary': thread.subject_summary[:100],
            'status': thread.status,
            'dak_count': thread.dak_count,
            'created_on': thread.created_on,
            'last_activity': thread.last_activity
        })
    
    if format_type == 'excel':
        return generate_thread_excel(data, 'Thread_Summary_Report')
    elif format_type == 'csv':
        return generate_thread_csv(data, 'Thread_Summary_Report')
    
    return HttpResponse("Invalid format", status=400)

def generate_thread_excel(data, title):
    """Generate Excel for thread report"""
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment
    
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = title[:31]
    
    headers = ['S.No', 'Thread Code', 'Subject', 'Status', 'Total Daks', 'Created On', 'Last Activity']
    
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
    
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center')
    
    for row_idx, item in enumerate(data, 2):
        ws.cell(row=row_idx, column=1, value=row_idx-1)
        ws.cell(row=row_idx, column=2, value=item['thread_code'])
        ws.cell(row=row_idx, column=3, value=item['subject_summary'])
        ws.cell(row=row_idx, column=4, value=item['status'])
        ws.cell(row=row_idx, column=5, value=item['dak_count'])
        ws.cell(row=row_idx, column=6, value=item['created_on'].strftime('%d-%b-%Y'))
        ws.cell(row=row_idx, column=7, value=item['last_activity'].strftime('%d-%b-%Y %H:%M'))
    
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = f'attachment; filename="{title}_{datetime.now().strftime("%Y%m%d")}.xlsx"'
    wb.save(response)
    return response

def generate_thread_csv(data, title):
    """Generate CSV for thread report"""
    import csv
    
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="{title}_{datetime.now().strftime("%Y%m%d")}.csv"'
    
    writer = csv.writer(response)
    writer.writerow(['S.No', 'Thread Code', 'Subject', 'Status', 'Total Daks', 'Created On', 'Last Activity'])
    
    for idx, item in enumerate(data, 1):
        writer.writerow([
            idx, item['thread_code'], item['subject_summary'], item['status'],
            item['dak_count'], item['created_on'].strftime('%d-%b-%Y'),
            item['last_activity'].strftime('%d-%b-%Y %H:%M')
        ])
    
    return response