@echo off
echo Starting eDMS Development Environment...
cd /d C:\eDMS_Project\Code
call venv\Scripts\activate
echo Virtual Environment Activated: (venv)
python manage.py runserver