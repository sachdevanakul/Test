-- ============================================================
-- Phase 3 — Item #1: stop running the app as the postgres superuser.
--
-- Creates two roles:
--   edms_admin  — full DML + DDL. Used by a human (the system head) for
--                 `python manage.py migrate`, the fix_*_tables.py scripts,
--                 and any manual schema work. NOT what the running app uses.
--   edms_app    — DML only (SELECT/INSERT/UPDATE/DELETE). This is what the
--                 actual deployed Django app connects as. It cannot create,
--                 alter, or drop tables — so even if the running app were
--                 ever compromised, the attacker can't touch the schema,
--                 only the rows the app itself can already touch.
--
-- Run this as a Postgres superuser (e.g. `psql -U postgres -d edms_db -f phase3_db_users.sql`)
-- AFTER you've applied the Phase 2 and Phase 3 migrations (so the views
-- created in 0004 already exist and get covered by the grants below).
-- ============================================================

-- ── Create roles ────────────────────────────────────────────
-- CHANGE THESE PASSWORDS before running — don't reuse the password that
-- was sitting in settings.py (Nakul@123). Generate fresh ones, e.g.:
--   python -c "import secrets; print(secrets.token_urlsafe(24))"

DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'edms_admin') THEN
        CREATE ROLE edms_admin WITH LOGIN PASSWORD 'CHANGE_ME_ADMIN_PASSWORD';
    END IF;
    IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'edms_app') THEN
        CREATE ROLE edms_app WITH LOGIN PASSWORD 'CHANGE_ME_APP_PASSWORD';
    END IF;
END
$$;

-- ── Database / schema access ────────────────────────────────
GRANT CONNECT ON DATABASE edms_db TO edms_admin, edms_app;
GRANT USAGE ON SCHEMA public TO edms_admin, edms_app;

-- edms_admin can create/alter/drop objects in the schema (needed for
-- migrations and the manual fix_*_tables.py-style scripts)
GRANT CREATE ON SCHEMA public TO edms_admin;

-- ── edms_admin: full DML + full DDL on everything that exists today ──
GRANT ALL PRIVILEGES ON ALL TABLES    IN SCHEMA public TO edms_admin;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO edms_admin;

-- ── edms_app: DML only on everything that exists today ──────
-- (this also covers the v_* views from migration 0004 — Postgres treats
-- views as part of "ALL TABLES IN SCHEMA" for grant purposes)
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO edms_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO edms_app;
-- Deliberately NOT granting edms_app any CREATE/ALTER/DROP/TRUNCATE rights.

-- The blanket grant above also touched the v_* views (Postgres treats views
-- as tables for grant purposes). Pull the write grants back off them
-- specifically — these are meant to be genuinely read-only, not just
-- incidentally un-writable because the views happen to be JOINs.
REVOKE INSERT, UPDATE, DELETE ON
    v_dak_summary, v_dak_attachment_safe, v_thread_summary,
    v_task_summary, v_edw_summary, v_etot_summary, v_eiig_summary
FROM edms_app;

-- ── Keep this working for tables created LATER (future migrations) ──
-- Whenever edms_admin creates a new table/sequence, edms_app automatically
-- gets the same DML access — you won't need to re-run grants by hand
-- after every future migration.
ALTER DEFAULT PRIVILEGES FOR ROLE edms_admin IN SCHEMA public
    GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO edms_app;
ALTER DEFAULT PRIVILEGES FOR ROLE edms_admin IN SCHEMA public
    GRANT USAGE, SELECT ON SEQUENCES TO edms_app;

-- ── Sanity check — list what each role can now do ───────────
SELECT grantee, table_name, privilege_type
FROM information_schema.table_privileges
WHERE grantee IN ('edms_admin', 'edms_app')
ORDER BY grantee, table_name, privilege_type;
