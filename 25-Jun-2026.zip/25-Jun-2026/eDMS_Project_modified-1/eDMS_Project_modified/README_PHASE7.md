# Phase 7 — Attachment size limit, cached and admin-configurable (#12, #13)

6 files: `daks/cache_utils.py`, `daks/signals.py`, `daks/views.py`,
`daks/urls.py`, `templates/daks/system_settings.html` (new),
`templates/daks/base.html`.

## What this builds
This didn't exist yet — there was no max-attachment-size concept anywhere
in the app (just Django's generic 5MB request-body setting in
`settings.py`, which isn't admin-changeable from the frontend and isn't
specific to attachments). Built from scratch using `SystemConfig`, a
generic key-value settings model that already existed but was only wired
into Django Admin, never the actual app.

**New page: System Settings** (staff-only, linked in the sidebar). One
field for now — max attachment size in MB — saves instantly.

**Caching, per your two notes together:**
- #12 said cache it and refresh after 24h; #13 said reduce that to 15
  minutes — implemented the final number, 15 minutes, not both.
- Saving a new value in System Settings clears the cache immediately
  (via a signal on `SystemConfig` saves), so a change is live right away,
  not after waiting out the cache window.
- #13 also asked for it to "update when a user logs in" — added a
  `user_logged_in` signal that clears the cache on every login, so a
  freshly started session never inherits a value that's been sitting in
  cache for up to 15 minutes from someone else's session.

**Enforcement:** the one place in the whole codebase that creates an
attachment (`dak_create_incoming`) now checks the upload against this
limit before saving. Over the limit → the dak itself still gets created
(your data entry isn't lost), but the attachment is rejected with a clear
message stating the actual size and the limit.

## Tested for real
16 checks, all passed:
- Default (25MB) when no setting has ever been saved.
- Value actually lands in cache.
- Non-staff blocked from the settings page.
- Admin saves a new value (5MB) — confirmed it's both in the DB and
  immediately reflected in the cached read, no waiting.
- Garbage input (non-numeric) rejected cleanly, doesn't change anything.
- Manually staged a stale cached value, logged a user in, confirmed the
  cache got cleared and the next read pulled the real current value —
  this is the actual mechanism behind "update when a user logs in."
- A small upload under the limit succeeds and the attachment is saved.
- A 6MB upload against a 5MB limit: dak still gets created, attachment is
  rejected, clear error message shown.
