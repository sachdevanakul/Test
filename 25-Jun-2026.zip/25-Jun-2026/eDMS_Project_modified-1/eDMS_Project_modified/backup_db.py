#!/usr/bin/env python3
"""
eDMS database backup — DATABASE ONLY (no media/attachment files, per request).

Usage:
    python backup_db.py

Reads DB connection info the same way Django does (from .env via
python-decouple), so it stays in sync if you ever change DB_HOST/DB_NAME.
Uses edms_admin credentials (needs at least SELECT on everything, which
edms_admin has — see phase3_db_users.sql). Doesn't need DB_USER/PASSWORD
from .env at all if you'd rather pass them via the standard PG* env vars
instead; see the override section below.

What it does each run:
    1. pg_dump the database in compressed custom format (-F c) — this is
       the format that supports selective/parallel restore later, and is
       already gzip-compressed so the files are small.
    2. Name the file with a timestamp: edms_db_YYYYMMDD_HHMMSS.dump
    3. Delete dump files older than RETENTION_DAYS (default 14).
    4. Print a clear OK/FAIL line and exit 0/1, so cron or Task Scheduler
       can detect failures (e.g. email you, or just show up in logs).

Schedule it:
    Linux (cron) — daily at 2 AM:
        0 2 * * * /usr/bin/python3 /path/to/backup_db.py >> /path/to/backup.log 2>&1

    Windows (Task Scheduler):
        Create a Basic Task → Trigger: Daily → Action: Start a program
            Program: C:\\path\\to\\venv\\Scripts\\python.exe
            Arguments: C:\\path\\to\\backup_db.py
            Start in: C:\\path\\to\\project
"""

import os
import subprocess
import sys
from datetime import datetime, timedelta
from pathlib import Path

# ── Config ──────────────────────────────────────────────────────────
BASE_DIR = Path(__file__).resolve().parent
BACKUP_DIR = BASE_DIR / 'db_backups'
RETENTION_DAYS = 14

# ── Load DB connection info the same way Django does ────────────────
try:
    from decouple import config
    DB_NAME = config('DB_NAME', default='edms_db')
    DB_USER = config('DB_USER', default='edms_admin')
    DB_PASSWORD = config('DB_PASSWORD', default='')
    DB_HOST = config('DB_HOST', default='localhost')
    DB_PORT = config('DB_PORT', default='5432')
except Exception:
    # Fall back to plain environment variables if decouple/.env isn't set up
    DB_NAME = os.environ.get('DB_NAME', 'edms_db')
    DB_USER = os.environ.get('DB_USER', 'edms_admin')
    DB_PASSWORD = os.environ.get('DB_PASSWORD', '')
    DB_HOST = os.environ.get('DB_HOST', 'localhost')
    DB_PORT = os.environ.get('DB_PORT', '5432')


def run_backup():
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    dump_path = BACKUP_DIR / f'edms_db_{timestamp}.dump'

    env = os.environ.copy()
    if DB_PASSWORD:
        env['PGPASSWORD'] = DB_PASSWORD

    cmd = [
        'pg_dump',
        '-h', DB_HOST,
        '-p', str(DB_PORT),
        '-U', DB_USER,
        '-F', 'c',          # custom format: compressed, supports selective restore
        '-f', str(dump_path),
        DB_NAME,
    ]

    print(f"[{datetime.now().isoformat()}] Starting backup of '{DB_NAME}' -> {dump_path}")
    result = subprocess.run(cmd, env=env, capture_output=True, text=True)

    if result.returncode != 0:
        print(f"[{datetime.now().isoformat()}] FAILED — pg_dump exit code {result.returncode}")
        print(result.stderr)
        if dump_path.exists():
            dump_path.unlink()  # don't leave a partial/corrupt dump lying around
        return False

    size_mb = dump_path.stat().st_size / (1024 * 1024)
    print(f"[{datetime.now().isoformat()}] OK — {dump_path.name} ({size_mb:.2f} MB)")
    return True


def prune_old_backups():
    cutoff = datetime.now() - timedelta(days=RETENTION_DAYS)
    removed = 0
    for f in BACKUP_DIR.glob('edms_db_*.dump'):
        try:
            stamp_str = f.stem.replace('edms_db_', '')
            file_time = datetime.strptime(stamp_str, '%Y%m%d_%H%M%S')
        except ValueError:
            continue
        if file_time < cutoff:
            f.unlink()
            removed += 1
    if removed:
        print(f"[{datetime.now().isoformat()}] Pruned {removed} backup(s) older than {RETENTION_DAYS} days")


if __name__ == '__main__':
    ok = run_backup()
    if ok:
        prune_old_backups()
    sys.exit(0 if ok else 1)
