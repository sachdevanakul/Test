# Phase 5 — Import fixes (#16) + Thread management redesign (#7)

9 files: `daks/views.py`, `daks/edw_views.py`, `daks/forms.py`, `daks/models.py`,
`daks/urls.py`, `daks/migrations/0005_alter_dakmaster_reply_dak.py`,
`templates/daks/dak_form.html`, `templates/daks/dak_detail.html`,
`templates/daks/thread_detail.html`.

## Part 1 — Import feature (#16)

I actually ran every import path with real data rather than just reading
the code, since "not working" could've meant several different things.
Found two real, reproducible bugs:

**1. eDW import crashed on any new company name.**
`edw_bulk_import` tried to auto-create an `OrganizationMaster` for any
company name not already in the system, but never gave it a required
`org_type` — every row with an unrecognized company crashed with
`NOT NULL constraint failed: organization_master.org_type_id`. Since most
real imports introduce new companies, this likely broke most real-world
imports. Fixed: new companies now get a generic "Unspecified" type instead
of crashing (you can fix the type later from the UI).

**2. Generic Dak import (`/import/`) generated wrong index numbers.**
The numbering formula double-counted: `db_count + success + 1` — but
`db_count` already included every row created earlier in the same import
(since each row saves immediately), so `success` got added on top
unnecessarily. Result: numbers like `IN-2026-0001, IN-2026-0003,
IN-2026-0007...` — skipping ahead each row instead of going 1, 2, 3. Fixed
to just `db_count + 1`. Also added a clear error message instead of a raw
crash if no active Dak Category exists yet.

**Checked but found clean:** `etot_bulk_import` and `eiig_bulk_import` —
ran both with real data, no issues.

**Found but deliberately not touched:** `daks/import_views.py` (837
lines) is a separate, more advanced import system — proper upsert,
dry-run, Excel templates with dropdowns — built at some point but **never
wired into urls.py**. It's dead code right now; the simpler functions in
`edw_views.py`/`etot_views.py`/`eiig_views.py` are what's actually live.
I didn't swap them in since etot/eiig already work fine and replacing a
working flow with an unused one is unnecessary risk for today — but if you
want those nicer features (especially the upsert-on-reimport behavior),
say so and I'll wire it up properly as its own pass.

## Part 2 — Thread management (#7)

**The actual fix turned out smaller than expected** — `reply_dak` (a
self-referencing FK on `DakMaster`, exactly "which dak is this one a reply
to") already existed in your model and migration, it was just never used
anywhere outside Django admin's raw-ID field. No new field needed, just a
`related_name` added for clean reverse access (`dak.replies.all()`) — a
safe metadata-only migration, no data changes.

**What changed in behavior:**
- Incoming dak creation no longer auto-matches/creates threads by exact
  subject text. That was the root problem both ways: two different firms
  writing about the same topic used to get merged into one thread; the
  same firm writing about a new topic used to get split into a separate
  one. Now: pick an existing thread to continue the same correspondence,
  or leave it blank to start a new one — your call, not a silent text
  match.
- Added a **suggested threads** box next to the sender/receiver fields:
  pick (or change) the organization/person, and it shows any open threads
  that correspondent already has, one click to continue one. Doesn't force
  anything — still just a suggestion.
- Added a **"Replying To"** dropdown, scoped to daks already in the
  selected thread, so a thread with multiple daks doesn't leave you
  guessing which one a given reply was actually answering. Shown on the
  dak detail page and in the thread timeline as "↳ Reply to IN-2026-0001".
- Fixed the same kind of numbering bug as the import issue, but in
  `thread_code` generation (`THREAD-2026-0001`, `0002`...) — it was
  counting threads across all years instead of the current year.

**Found but deliberately not touched:** to make the new suggestion feature
actually find a correspondent, that correspondent needs a named contact
person recorded — `DakPartyMapping.person` is a required field, so
selecting only an organization with no specific person currently never
gets recorded as a party on the dak at all (pre-existing, not something I
introduced). Worth deciding whether `person` should become optional there;
didn't change it without your say since it's a schema decision with its
own ripple effects.

## Tested for real
- Reproduced both import bugs with real uploads before fixing them, then
  confirmed the fixes with the same uploads.
- Built a full scenario for the thread redesign: two firms with the exact
  same subject text (confirmed separate threads), the same firm with a
  different subject and an explicit thread pick (confirmed same thread),
  an outgoing reply with `reply_dak` set (confirmed it's traceable both
  ways), a reply_dak deliberately from the wrong thread (confirmed the
  safety net rejects it), both new AJAX endpoints, sequential thread-code
  numbering, and both templates rendering with the new info — 11 checks,
  all passed.
- Full `py_compile` + `manage.py check` — clean.
