# Final delivery — Screenshot deterrence (#18) + Apache deployment (#11)

8 files: `templates/daks/base.html`, `edms/settings.py`,
`requirements.txt`, `.env` (replaces the Phase 3 one — has 2 new lines),
`.env.example`, `apache_edms_final.conf` (new), `DEPLOYMENT_GUIDE.md`
(new — read this one first for #11).

## #18 — Screenshot blocking: an honest answer, not a fix

I want to be direct about this one rather than ship something that looks
like it works but doesn't: **no web page can prevent an OS-level
screenshot.** PrintScreen, Windows' Snipping Tool, Win+Shift+S, or just a
phone camera pointed at the monitor all happen completely outside the
browser — JavaScript is never given a chance to stop any of them.

The existing code tried to intercept the PrintScreen key and blank the
page during tab-visibility changes. Neither actually stops a screenshot
— `e.preventDefault()` on a keydown doesn't reach the OS shortcut that
already fired, and visibility changes don't reliably fire for screenshot
tools at all (the browser window stays fully visible while a screenshot
of it is taken). This is very likely exactly what "not working" meant —
it was never going to work, regardless of how the JS was written.

**What I replaced it with**: a tiled watermark (the logged-in user's
name + timestamp) overlaid faintly across the screen for any user with
screenshots disabled in their profile. It doesn't stop a screenshot —
but it makes every screenshot taken traceable to exactly who took it,
which is the realistic, achievable version of this control. Kept the
right-click and drag blockers from before since those do raise the bar
for casual copy/paste, even though they don't address screenshots either.

Found and fixed while building this: my first attempt used a multi-line
`{# #}` Django comment for the explanation above the code — turns out
Django's short comment syntax doesn't reliably strip multi-line content,
and the explanation text was leaking into the actual rendered page.
Switched to `{% comment %}...{% endcomment %}`, which does work
correctly for multi-line content, and confirmed the leak is gone by
rendering the page and checking the output.

## #11 — Apache deployment

Full details, exact commands, and the two real bugs this surfaced are in
`DEPLOYMENT_GUIDE.md` — short version:

I installed Apache 2.4.58 + mod_wsgi in a sandbox and actually deployed
this codebase against a real PostgreSQL database, rather than just
writing instructions from documentation. That surfaced two genuine bugs,
both fixed here:

1. **`.env` silently didn't control `DEBUG`/`SECRET_KEY`/`ALLOWED_HOSTS`.**
   Phase 3 moved `DATABASES` to read through `python-decouple`, but these
   three settings were still on plain `os.environ`, which decouple's
   `.env` file doesn't populate. Now consistent — one `.env` controls all
   of it. Also flipped `DEBUG`'s default from `True` to `False` for the
   same "fail toward safe" reasoning as the DB password change in Phase 3.
   **This needs your local `.env` updated too** — the version in this zip
   already has the two new lines that keep `manage.py runserver` working
   locally; without them it would start rejecting every request.

2. **`pywin32` in `requirements.txt` would have broken `pip install` on
   Linux entirely** — that package doesn't have a Linux build, and it's
   not actually imported anywhere in the app. Made it conditional
   (`pywin32>=306; sys_platform == 'win32'`) so the same file works on
   your Windows dev machine and the Linux Apache server.

3. **Directory permissions** — login crashed with a real `PermissionError`
   the first time I tried it through Apache, because `mod_wsgi` runs as
   `www-data`, and `cache/`/`media/` were owned by a different user.
   Documented the exact `chown` needed in the guide — you'll hit this on
   your server too unless it's done.

`apache_edms_final.conf` is the same structure I actually got working,
with your real paths swapped in as placeholders.

## Tested for real, end to end
- Real PostgreSQL (not SQLite), migrations applied, Apache + mod_wsgi
  serving the actual WSGI app.
- A full login → dashboard flow over real HTTP, both with `DEBUG=False`
  (production) and `DEBUG=True` (your local setup) — confirmed both work
  without breaking the other.
- Static files served by Apache directly, confirmed 200.
- Screenshot watermark: rendered the home page as a restricted user
  (watermark present, username embedded) and a normal user (no
  watermark) — confirmed both, and confirmed the Django-comment leak is
  gone from the rendered output.
- Full `py_compile` + `manage.py check` clean across every file touched
  today.

This closes out all 21 items from your original list.
