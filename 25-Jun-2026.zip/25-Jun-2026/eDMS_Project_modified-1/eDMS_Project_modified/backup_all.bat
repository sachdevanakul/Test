@echo off
echo ========================================
echo   eDMS - Complete Backup (All in One)
echo ========================================
echo.

echo Running database backup...
call %~dp0backup_database.bat

echo.
echo Running file backup...
call %~dp0backup_files.bat

echo.
echo ========================================
echo ALL BACKUPS COMPLETED!
echo ========================================
pause