@echo off
echo ========================================
echo   eDMS - File Attachments Backup
echo ========================================
echo.

set BACKUP_ROOT=C:\eDMS_Project\Backups
set DATE=%date:~10,4%%date:~7,2%%date:~4,2%
set TIMESTAMP=%DATE%
set LOG_FILE=%BACKUP_ROOT%\Logs\files_backup_%TIMESTAMP%.log

echo Starting file backup at %DATE% %TIME% > %LOG_FILE%
echo. >> %LOG_FILE%

echo [1/2] Backing up media files... >> %LOG_FILE%
echo [1/2] Backing up media files...

if exist "C:\eDMS_Project\Code\media" (
    "C:\Program Files\7-Zip\7z.exe" a -tzip %BACKUP_ROOT%\Daily\media_%TIMESTAMP%.zip "C:\eDMS_Project\Code\media" >> %LOG_FILE% 2>&1
    echo ✓ Media files backup successful >> %LOG_FILE%
    echo ✓ Media files backup successful
) else (
    echo ⚠ Media folder not found >> %LOG_FILE%
    echo ⚠ Media folder not found
)

echo [2/2] Cleaning up old backups... >> %LOG_FILE%
echo [2/2] Cleaning up old backups...

REM Keep only last 7 days of daily backups
forfiles -p "%BACKUP_ROOT%\Daily" -m *.zip -d -7 -c "cmd /c del @path" >> %LOG_FILE% 2>&1

echo. >> %LOG_FILE%
echo ======================================== >> %LOG_FILE%
echo BACKUP COMPLETED AT %TIME% >> %LOG_FILE%
echo ======================================== >> %LOG_FILE%

echo.
echo File backup completed!
pause