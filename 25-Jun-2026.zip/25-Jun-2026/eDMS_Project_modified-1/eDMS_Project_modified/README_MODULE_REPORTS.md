# eDW / eToT / eIIG Reports + Nav-Permission Verification

11 files. Paths as shown — `edms/settings.py`, `daks/context_processors.py`,
and `templates/daks/base.html` are included again specifically so there's
no ambiguity about the nav-permission fix (see Part 2).

## Part 1 — Dedicated eDW / eToT / eIIG reports

You were right that this was a real gap. The Report Builder (column
picker) already technically covered these 3 modules, but there was no
*ready-made, one-click* report for any of them — unlike Dak, which has
Daily/Monthly/etc. reports ready to go. Built that:

- **New "Module Quick Reports" section** on the Reports Dashboard — one
  card per module (eDW/eToT/eIIG), each with an optional date range and
  three one-click buttons: PDF, Excel, CSV.
- **Direct report button on each module's own dashboard** — eDW
  Dashboard now has an "eDW Report" button right next to its existing
  Export Excel button, same for eToT and eIIG. This is likely what was
  missing when you said there was "no view of custom report" — it's now
  reachable directly from inside each module, not just from the central
  Reports menu.
- **Excel and CSV were actually completely missing** for these modules —
  only PDF and Word existed before (via the Report Builder), with no
  Excel/CSV option for eDW/eToT/eIIG data at all. Added both.
- Each report uses a curated, sensible set of default columns (the same
  ones used for the read-only database views from Phase 3, for
  consistency) — no column-picking needed for the quick version. The
  full Report Builder is still there if you want to customize.

**A mistake I made and caught before sending**: while adding the date-filter
helper function, I accidentally deleted the line that starts the Excel
report function, leaving its body as orphaned, unreachable code — the
exact same class of bug I found and fixed in Phase 6 (the missing
`generate_pdf_report` line). Caught it by actually running the Excel
export and getting a `NameError`, not by re-reading the code. Fixed and
re-tested.

## Part 2 — The nav-permission issue ("no options available")

I re-checked this very carefully because you reported it's not working,
but it tested correctly on my end in Phase 4 and again just now. Here's
what that most likely means:

**The fix is genuinely correct in the code** — I just re-ran the exact
test again: created a user with eDW access granted and eToT access
denied, logged in as them, and inspected the actual rendered sidebar.
Result: eDW shows, eToT does not, Admin does not. That's exactly right.

**So if your live server still shows no options for a permissioned user,
the most likely explanation is that the Phase 4 fix was never actually
applied to your real codebase** — either that zip wasn't copied over, or
a later zip's `settings.py` was copied over it without including that
line (each phase's zip should have had it, but to remove all doubt, the
three files that matter for this are included again here).

**Check this on your server right now, in this exact order:**

1. Open your server's `edms/settings.py`. Find the `TEMPLATES` block's
   `context_processors` list. It must contain this exact line:
   ```
   'daks.context_processors.user_profile',
   ```
   If it's missing, that's the bug — copy in the `settings.py` from this
   zip (or just add that one line yourself).
2. Confirm `daks/context_processors.py` exists on your server with a
   `user_profile` function in it (included here in case it's missing).
3. Restart the server/Apache process — this is a settings change, it
   needs a restart to take effect, just reloading the page isn't enough.
4. Go to User Management, open a non-staff user, tick exactly one module
   (say, eDW only), save, then log in as that user (or have them refresh
   after you save). Their sidebar should show eDW and nothing else
   module-related.

If you do all four steps and it's still wrong, tell me exactly what you
see (a blank sidebar entirely? everything shown? a specific module
missing?) and I'll dig further — but the code itself has now been
verified correct twice.

## Tested for real
27 checks: all three modules' reports in all three formats, with real
data, confirmed actual data appears in the output (not blank exports);
date-range filtering confirmed to actually exclude/include the right
records; permission gating confirmed module-specific (a user with only
eDW access can get an eDW report but is blocked from eToT); and the nav
sidebar re-verified end-to-end exactly as in Phase 4.
