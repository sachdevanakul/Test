@echo off
echo ========================================
echo   eDMS - Restore from Backup
echo ========================================
echo.

set BACKUP_ROOT=C:\eDMS_Project\Backups

echo Available daily backups:
echo -------------------------
dir %BACKUP_ROOT%\Daily\*.zip /b
echo.
echo Available weekly backups:
echo -------------------------
dir %BACKUP_ROOT%\Weekly\*.zip /b
echo.

set /p BACKUP_FILE="Enter backup filename to restore (from Daily or Weekly): "

if not exist "%BACKUP_ROOT%\Daily\%BACKUP_FILE%" (
    if not exist "%BACKUP_ROOT%\Weekly\%BACKUP_FILE%" (
        echo Error: Backup file not found!
        pause
        exit /b 1
    )
)

echo.
echo WARNING: This will overwrite your current database and files!
set /p CONFIRM="Are you sure? (yes/no): "

if /i not "%CONFIRM%"=="yes" (
    echo Restore cancelled.
    pause
    exit /b 0
)

echo.
echo [1/4] Extracting backup...
cd %BACKUP_ROOT%\Daily
if exist "%BACKUP_ROOT%\Daily\%BACKUP_FILE%" (
    "C:\Program Files\7-Zip\7z.exe" x %BACKUP_FILE% -o%TEMP%\restore_temp -y
) else (
    cd %BACKUP_ROOT%\Weekly
    "C:\Program Files\7-Zip\7z.exe" x %BACKUP_FILE% -o%TEMP%\restore_temp -y
)

echo [2/4] Restoring database...
set PG_PATH=C:\Program Files\PostgreSQL\15\bin
set PATH=%PATH%;%PG_PATH%
set DB_NAME=edms_db
set DB_USER=postgres
set DB_PASSWORD=EDMS@2024
set PGPASSWORD=%DB_PASSWORD%

for %%f in (%TEMP%\restore_temp\*.sql) do (
    psql -U %DB_USER% -d %DB_NAME% -f "%%f"
    echo ✓ Database restored from: %%~nf
)

echo [3/4] Restoring files...
if exist "%TEMP%\restore_temp\media" (
    xcopy /E /I /H /Y "%TEMP%\restore_temp\media" "C:\eDMS_Project\Code\media\" 
    echo ✓ Files restored
)

echo [4/4] Cleaning up...
rmdir /s /q %TEMP%\restore_temp

echo.
echo ========================================
echo RESTORE COMPLETED SUCCESSFULLY!
echo ========================================
pause