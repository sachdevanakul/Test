@echo off
echo ========================================
echo   eDMS - Weekly Full Backup
echo ========================================
echo.

set BACKUP_ROOT=C:\eDMS_Project\Backups
set DATE=%date:~10,4%%date:~7,2%%date:~4,2%
set WEEKLY_FILE=%BACKUP_ROOT%\Weekly\full_backup_%DATE%.zip
set LOG_FILE=%BACKUP_ROOT%\Logs\weekly_backup_%DATE%.log

echo Starting weekly full backup at %DATE% %TIME% > %LOG_FILE%
echo. >> %LOG_FILE%

echo [1/4] Running daily database backup... >> %LOG_FILE%
call %~dp0backup_database.bat

echo [2/4] Running daily file backup... >> %LOG_FILE%
call %~dp0backup_files.bat

echo [3/4] Creating complete project backup... >> %LOG_FILE%
echo [3/4] Creating complete project backup...

cd C:\eDMS_Project

REM Exclude venv, pycache, and backup folders
"C:\Program Files\7-Zip\7z.exe" a -tzip %WEEKLY_FILE% Code -xr!venv -xr!__pycache__ -xr!*.pyc -xr!Backups >> %LOG_FILE% 2>&1

if %errorlevel% equ 0 (
    echo ✓ Project backup successful >> %LOG_FILE%
    echo ✓ Project backup successful
) else (
    echo ✗ Project backup failed >> %LOG_FILE%
    echo ✗ Project backup failed
)

echo [4/4] Cleaning up old weekly backups... >> %LOG_FILE%
REM Keep only last 4 weeks of weekly backups
forfiles -p "%BACKUP_ROOT%\Weekly" -m *.zip -d -28 -c "cmd /c del @path" >> %LOG_FILE% 2>&1

echo. >> %LOG_FILE%
echo ======================================== >> %LOG_FILE%
echo WEEKLY BACKUP COMPLETED AT %TIME% >> %LOG_FILE%
echo ======================================== >> %LOG_FILE%

echo.
echo Weekly full backup completed!
echo Location: %WEEKLY_FILE%
pause