"""
Run this script ONCE from your project folder (with venv active) to generate
the three Excel import templates in the current directory.

  python generate_templates.py

Requires: pip install openpyxl==3.1.5
"""
import openpyxl
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter

HDR_FILL = PatternFill('solid', fgColor='1F3864')
REQ_FILL = PatternFill('solid', fgColor='FEF9C3')   # yellow  = required
DAT_FILL = PatternFill('solid', fgColor='EFF6FF')   # blue    = date
NUM_FILL = PatternFill('solid', fgColor='FFF7ED')   # orange  = number
TXT_FILL = PatternFill('solid', fgColor='F8FAFC')   # white   = text
HDR_FONT = Font(color='FFFFFF', bold=True, size=9, name='Calibri')
thin     = Side(style='thin', color='CBD5E1')
BORDER   = Border(left=thin, right=thin, top=thin, bottom=thin)

def styled_sheet(ws, columns, module_name):
    ws.title = f'{module_name} Import'
    for ci, (field, label, dtype) in enumerate(columns, 1):
        # Header
        h = ws.cell(row=1, column=ci, value=label)
        h.fill      = HDR_FILL
        h.font      = HDR_FONT
        h.border    = BORDER
        h.alignment = Alignment(wrap_text=True, horizontal='center', vertical='center')
        # Data rows
        fill = REQ_FILL if '*' in label else \
               DAT_FILL if dtype == 'DATE' else \
               NUM_FILL if dtype == 'NUMBER' else TXT_FILL
        for r in range(2, 502):
            c = ws.cell(row=r, column=ci)
            c.fill   = fill
            c.border = BORDER
        ws.column_dimensions[get_column_letter(ci)].width = max(16, len(label) * 0.9)
    ws.row_dimensions[1].height = 38
    ws.freeze_panes = 'A2'

def add_instructions(wb, lines):
    ns = wb.create_sheet('Instructions')
    for i, line in enumerate(lines, 1):
        ns.cell(row=i, column=1, value=line).font = Font(size=10, name='Calibri')
    ns.column_dimensions['A'].width = 100

# ── eDW ────────────────────────────────────────────────────────────────────────
EDW_COLS = [
    ('acn_no','ACN No. *','TEXT'),
    ('rdr_register_number','RDR Register Number','TEXT'),
    ('acn_date','ACN Date (DD/MM/YYYY)','DATE'),
    ('company_name','Company Name','TEXT'),
    ('group','Group Name','TEXT'),
    ('acn_request_received_date','ACN Request Received Date','DATE'),
    ('intimation_acn_to_group','Intimation to Group (MAIL / HARD_COPY)','TEXT'),
    ('bq_shared_to_firm_date','BQ Shared to Firm Date','DATE'),
    ('amount_paid_by_firm','Amount Paid by Firm','NUMBER'),
    ('bank_reference_no','Bank Reference No.','TEXT'),
    ('firm_payment_date','Firm Payment Date','DATE'),
    ('amount_reflected_in_acn','Amount Reflected in ACN','NUMBER'),
    ('testing_changes_receipt_no','Testing Changes Receipt No.','TEXT'),
    ('testing_changes_receipt_date','Testing Changes Receipt Date','DATE'),
    ('emro_payment_date','eMRO Payment Date','DATE'),
    ('mro_outgoing_date','MRO Outgoing Date','DATE'),
    ('mro_number','MRO No.','TEXT'),
    ('mro_date','MRO Date','DATE'),
    ('trial_title','Trial Title','TEXT'),
    ('no_of_test_samples_planned','No. of Test Samples Planned','NUMBER'),
    ('no_of_test_conducted','No. of Test Conducted','NUMBER'),
    ('trial_tentative_date','Trial Tentative Date','DATE'),
    ('job_number_alloted_by_i2g','Job Number Allotted by I2G','TEXT'),
    ('te_number_outgoing_date','TE Number Outgoing Date','DATE'),
    ('te_number_incoming_date','TE Number Incoming Date','DATE'),
    ('report_received_from_group','Report Received from Group','DATE'),
    ('trial_report_no','Trial Report No.','TEXT'),
    ('trial_report_issued_on','Trial Report Issued On','DATE'),
    ('report_to_whom_dispatched','Report Dispatched To','TEXT'),
    ('dispatch_date','Dispatch Date','DATE'),
    ('speed_post_no','Speed Post No.','TEXT'),
    ('speed_post_date','Speed Post Date','DATE'),
    ('amount_utilized','Amount Utilized','NUMBER'),
    ('cancellation_amount','Cancellation Amount','NUMBER'),
    ('refund_amount','Refund Amount','NUMBER'),
    ('gst_paid_on_rcm_basis_transaction_no','GST RCM Transaction No.','TEXT'),
    ('gst_paid_on_rcm_basis_date','GST RCM Date','DATE'),
    ('gst_challan_no','GST Challan No.','TEXT'),
    ('gst_challan_amount','GST Challan Amount','NUMBER'),
    ('gst_challan_date','GST Challan Date','DATE'),
    ('jcc_number','JCC Number','TEXT'),
    ('jcc_received_date','JCC Received Date','DATE'),
    ('code_head','Code Head (xx / 017 / 05)','TEXT'),
    ('dpsu_psu_private_capf','DPSU / PSU / PRIVATE / SERVICES / CAPF','TEXT'),
    ('status','Status (COMPLETED / ONGOING)','TEXT'),
    ('workflow_stage','Workflow Stage','TEXT'),
    ('for_closure','For Closure (Yes / No)','TEXT'),
    ('remarks','Remarks','TEXT'),
]

wb = openpyxl.Workbook()
styled_sheet(wb.active, EDW_COLS, 'eDW')
add_instructions(wb, [
    'eDW BULK IMPORT — INSTRUCTIONS',
    '',
    'REQUIRED COLUMNS (yellow):',
    '  acn_no  — Activity Code Number. MUST be unique. If it already exists in the system, that record will be UPDATED.',
    '',
    'DATE FORMAT:  DD/MM/YYYY   e.g.  15/06/2024',
    '',
    'DROPDOWN VALUES:',
    '  status              → COMPLETED  or  ONGOING',
    '  for_closure         → Yes  or  No',
    '  intimation_to_group → MAIL  or  HARD_COPY',
    '  dpsu_psu_...        → DPSU / PSU / PRIVATE / SERVICES / CAPF',
    '  workflow_stage      → INQUIRY / NTR_CREATED / BQ_ISSUED / PAYMENT_RCVD / TRIAL_DONE / CLOSED',
    '',
    'FOREIGN KEY COLUMNS:',
    '  company_name → must match Organisation Master  (new names are auto-created as placeholders)',
    '  group        → must match Group Master          (new names are auto-created as placeholders)',
    '',
    'LIMITS:  Max 3000 rows per upload.  Accepted formats: .xlsx  .csv',
    '',
    'COLOUR LEGEND:',
    '  Yellow = Required    Blue = Date field    Orange = Number field    White = Text field',
])
wb.save('eDW_import_template.xlsx')
print('✓  eDW_import_template.xlsx')

# ── eTOT ───────────────────────────────────────────────────────────────────────
ETOT_COLS = [
    ('tot_file_no','ToT File No. *','TEXT'),
    ('product_technology','Product / Technology *','TEXT'),
    ('technology_category','Technology Category (A / B)','TEXT'),
    ('stage','Stage','TEXT'),
    ('technical_group','Technical Group','TEXT'),
    ('point_of_contact','Point of Contact','TEXT'),
    ('licensee_name','Licensee Name','TEXT'),
    ('licensee_company','Licensee Company','TEXT'),
    ('licensee_address','Licensee Address','TEXT'),
    ('meeting_held_on','Meeting Held On','DATE'),
    ('minute_signed_by_chairman_on','Minute Signed by Chairman','DATE'),
    ('minute_approved_by_director_on','Minute Approved by Director','DATE'),
    ('tnf_initiated_by_group_on','TNF Initiated by Group','DATE'),
    ('tnf_certificate_issued_by_director_on','TNF Certificate Issued by Director','DATE'),
    ('tnf_nom_no','TNF NOM No.','TEXT'),
    ('tnf_no_allotted_by_diitm_on','TNF No. Allotted by DIITM','DATE'),
    ('no_of_licenses_approved','No. of Licenses Approved','NUMBER'),
    ('additional_no_of_licenses','Additional No. of Licenses','NUMBER'),
    ('licenses_awarded_to_industry','Licenses Awarded to Industry','NUMBER'),
    ('eoi_hosting_on_portal','EOI Hosting on Portal','DATE'),
    ('cec_constitution_on','CEC Constitution','DATE'),
    ('cec_meeting_held_on','CEC Meeting Held On','DATE'),
    ('cec_report_signed_by_chairman_on','CEC Report Signed by Chairman','DATE'),
    ('cec_min_forwarded_by_director_on','CEC Min Forwarded by Director','DATE'),
    ('cec_recommended_by_dg_mss_on','CEC Recommended by DG(MSS)','DATE'),
    ('cec_approved_by_dg_pc_s7_on','CEC Approved by DG(PC and S7)','DATE'),
    ('tac_constitution_by_dir_dg_mss_on','TAC Constitution by Dir/DG(MSS)','DATE'),
    ('tac1_no_of_eoi_received','TAC-1 No. of EOI Received','NUMBER'),
    ('defence_industrial_license_no','Defence Industrial License No.','TEXT'),
    ('defence_industrial_license_date','Defence Industrial License Date','DATE'),
    ('peso_license_no','PESO License No.','TEXT'),
    ('peso_license_date','PESO License Date','DATE'),
    ('tac1_meeting_held_on','TAC-1 Meeting Held On','DATE'),
    ('tac1_report_signed_by_chairman_on','TAC-1 Report Signed by Chairman','DATE'),
    ('tac1_recommended_firms','TAC-1 Recommended Firms','TEXT'),
    ('vetted_latot_shared_with_industry_on','Vetted LAToT Shared with Industry','DATE'),
    ('signed_stamped_latot_received_on','Signed LAToT Received On','DATE'),
    ('emro_no','eMRO No.','TEXT'),
    ('tot_fee_paid_by_licensee','ToT Fee Paid by Licensee (Rs)','NUMBER'),
    ('tot_fee_paid_on','ToT Fee Paid On','DATE'),
    ('gst_details','GST Details','TEXT'),
    ('latot_no','LAToT No. (unique per row)','TEXT'),
    ('latot_signed_on','LAToT Signed On','DATE'),
    ('latot_signed_year','LAToT Signed Year','TEXT'),
    ('ttd_no','TTD No. (unique per row)','TEXT'),
    ('ttd_issued_on','TTD Issued On','DATE'),
    ('hand_holding_support_weeks','Hand Holding Support (Weeks)','NUMBER'),
    ('tot_absorption_request_received_on','ToT Absorption Request Received','DATE'),
    ('ta_certificate_no','TA Certificate No.','TEXT'),
    ('ta_certificate_issued_on','TA Certificate Issued On','DATE'),
    ('ta_certificate_validity','TA Certificate Validity','TEXT'),
    ('royalty_fee_received','Royalty Fee Received (Rs)','NUMBER'),
    ('remarks','Remarks','TEXT'),
]

wb2 = openpyxl.Workbook()
styled_sheet(wb2.active, ETOT_COLS, 'eTOT')
add_instructions(wb2, [
    'eTOT BULK IMPORT — INSTRUCTIONS',
    '',
    'REQUIRED COLUMNS (yellow):',
    '  tot_file_no        — e.g.  ToT-0103   (same file no. can repeat for multiple licensees)',
    '  product_technology — name of the technology/product',
    '',
    'DATE FORMAT:  DD/MM/YYYY   e.g.  15/06/2024',
    '',
    'UNIQUE COLUMNS — if provided, used as the upsert key:',
    '  latot_no — LAToT Number. If this already exists in DB, that record is UPDATED.',
    '  ttd_no   — TTD Number.   Leave blank if not yet assigned.',
    '',
    'DROPDOWN VALUES:',
    '  stage               → INITIATED / TNF / EOI / CEC / TAC / LAToT / TTD / TA_CERTIFICATE / COMPLETED / TERMINATED',
    '  technology_category → A  or  B',
    '',
    'FOREIGN KEY COLUMNS:',
    '  technical_group  → must match Group Master',
    '  licensee_company → must match Organisation Master',
    '  point_of_contact → must match Person Master  (left blank if person not found)',
    '',
    'LIMITS:  Max 3000 rows per upload.',
])
wb2.save('eTOT_import_template.xlsx')
print('✓  eTOT_import_template.xlsx')

# ── eIIG ───────────────────────────────────────────────────────────────────────
EIIG_COLS = [
    ('visit_id','Visit ID (leave blank to auto-generate)','TEXT'),
    ('date_of_visit','Date of Visit * (DD/MM/YYYY)','DATE'),
    ('firm_name','Firm / Industry Name *','TEXT'),
    ('firm_address','Complete Address','TEXT'),
    ('firm_state','State Code (PB / DL / MH / HR etc.)','TEXT'),
    ('company_category','Category (INDUSTRY / GOVERNMENT / RESEARCH / INDIVIDUAL / OTHER)','TEXT'),
    ('company_sub_category','Sub Category (PRIVATE / DPSU / PSU / MSME / STARTUP etc.)','TEXT'),
    ('purpose_of_visit','Purpose of Visit','TEXT'),
    ('feedback','Feedback','TEXT'),
    ('remarks','Remarks','TEXT'),
    ('visitor_1_name','Visitor 1 — Name','TEXT'),
    ('visitor_1_designation','Visitor 1 — Designation','TEXT'),
    ('visitor_1_mobile','Visitor 1 — Mobile','TEXT'),
    ('visitor_1_email','Visitor 1 — Email','TEXT'),
    ('visitor_2_name','Visitor 2 — Name','TEXT'),
    ('visitor_2_designation','Visitor 2 — Designation','TEXT'),
    ('visitor_2_mobile','Visitor 2 — Mobile','TEXT'),
    ('visitor_2_email','Visitor 2 — Email','TEXT'),
    ('visitor_3_name','Visitor 3 — Name','TEXT'),
    ('visitor_3_designation','Visitor 3 — Designation','TEXT'),
    ('visitor_3_mobile','Visitor 3 — Mobile','TEXT'),
    ('visitor_3_email','Visitor 3 — Email','TEXT'),
    ('visitor_4_name','Visitor 4 — Name','TEXT'),
    ('visitor_4_designation','Visitor 4 — Designation','TEXT'),
    ('visitor_4_mobile','Visitor 4 — Mobile','TEXT'),
    ('visitor_4_email','Visitor 4 — Email','TEXT'),
    ('visitor_5_name','Visitor 5 — Name','TEXT'),
    ('visitor_5_designation','Visitor 5 — Designation','TEXT'),
    ('visitor_5_mobile','Visitor 5 — Mobile','TEXT'),
    ('visitor_5_email','Visitor 5 — Email','TEXT'),
]

wb3 = openpyxl.Workbook()
styled_sheet(wb3.active, EIIG_COLS, 'eIIG')
add_instructions(wb3, [
    'eIIG BULK IMPORT — INSTRUCTIONS',
    '',
    'REQUIRED COLUMNS (yellow):',
    '  date_of_visit — Date the delegation visited.  Format: DD/MM/YYYY',
    '  firm_name     — Name of the visiting firm / organisation.',
    '',
    'VISIT ID:',
    '  Leave the visit_id column blank — the system auto-generates it as DCMM/I2G/YYYY-YY/XXXX.',
    '  If you fill in a visit_id that already exists in the DB, that visit record is UPDATED.',
    '',
    'VISITORS:',
    '  Each row supports up to 5 visitors (visitor_1 through visitor_5).',
    '  Leave visitor columns blank if there are fewer than 5 visitors.',
    '  If a visitor with the same name already exists for that visit, they are not duplicated.',
    '',
    'STATE CODES (2-letter):  PB=Punjab  DL=Delhi  MH=Maharashtra  HR=Haryana',
    '  UP=Uttar Pradesh  RJ=Rajasthan  KA=Karnataka  TN=Tamil Nadu  GJ=Gujarat',
    '',
    'CATEGORY:       INDUSTRY / GOVERNMENT / RESEARCH / INDIVIDUAL / OTHER',
    'SUB CATEGORY:   PRIVATE / DPSU / PSU / MSME / STARTUP / CENTRAL / STATE / DEFENCE / CAPF',
    '                UNIVERSITY / RESEARCH_INST / IIT_NIT / LAB / ENTREPRENEUR / STUDENT / RESEARCHER',
    '',
    'LIMITS:  Max 3000 rows per upload.',
])
wb3.save('eIIG_import_template.xlsx')
print('✓  eIIG_import_template.xlsx')
print('\nAll 3 templates generated successfully.')
