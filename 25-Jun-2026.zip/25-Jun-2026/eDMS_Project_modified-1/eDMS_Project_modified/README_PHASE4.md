# Phase 4 — Nav access control (#17, #19)

3 files: `edms/settings.py`, `templates/daks/base.html`, `templates/daks/home.html`.

## The actual bug
Your sidebar already had the right logic — every module link in
`base.html` already checks `{% if user.is_staff or user_profile.can_access_X %}`.
That part was written correctly.

The problem: `daks/context_processors.py` (the file that's supposed to
hand `user_profile` to every template) was **never registered** in
`settings.py`'s `TEMPLATES` config. So `user_profile` was always blank in
every template, for every non-staff user, always — meaning none of those
`can_access_X` checks could ever pass except for staff/superusers. Granting
a regular user access to a module in User Management had zero visible
effect on their nav, no matter what you ticked.

One line fixes it:
```python
'context_processors': [
    ...,
    'daks.context_processors.user_profile',   # ← added
],
```
That single registration retroactively makes every existing permission
check in `base.html` (Daks, Reports, eDW, eToT, eIIG, Tasks) actually work.

## Admin tab (#17)
The Django admin link (`href="/admin/"`) had no condition at all — shown
to literally every user. Wrapped it in `{% if user.is_staff %}`, matching
how the other staff-only items (Assign Task, Bulk Import, User Mgmt) were
already done.

## Quick Access box (#19)
Removed it from `home.html` along with its now-unused CSS, and adjusted
the bottom-row layout from 3 columns to 2 (Recent Daks + Quick Notes) so
it doesn't look like something's missing.

## One thing I noticed but did NOT touch
The home page's charts (Module Overview, eToT Stages, IIG Categories,
etc.) show data for every module to every user, regardless of their
`can_access_X` permissions — that's separate from the sidebar nav and
wasn't part of what you listed, so I left it alone. Worth a quick decision
on your end: is it fine for, say, an eDW-only user to see aggregate
eToT/eIIG numbers on the home dashboard, or should those be hidden too?
Easy to add later either way.

## Tested for real
Built a throwaway SQLite copy, created three real users — a plain user
with only eDW granted, a staff user, and a superuser — logged in as each
with Django's test client, and checked the actual rendered sidebar HTML:
- Plain user (eDW only): sidebar shows **only** eDW. No eToT, no eIIG, no
  Tasks, no Admin link, no Dak Entry.
- Staff and superuser: sidebar shows everything, including Admin.
- Quick Access markup and its CSS are gone from the rendered page for
  everyone.

All four checks passed.
