# Phase 2 — Random IDs (Dak, eDW, eTOT, eIIG, Tasks)

28 files. Drop into your project at matching relative paths (overwrite existing).

## What this does
Every Dak, DakThread, attachment, eDW, eTOT, eIIG visit, and Task now has a
`public_id` (UUID) field. All URLs for these (`/dak/5/`, `/edw/12/edit/`,`/attachment/3/download/`, etc.) now use that UUID instead of the sequential number — so nobody can sit at `/dak/1/` and tap the up arrow to walk through
every record.

## ⚠️ Before you deploy — read this
This touches live data. Do these in order:

1. **Back up the real Postgres DB first** (`pg_dump`). Non-negotiable —
   this is exactly the kind of change item #6 on your list exists for, and
   you don't have that automated yet, so do it manually right now:
   ```
   pg_dump -U postgres -d edms_db -F c -f edms_backup_before_phase2.dump
   ```
2. Copy the files in.
3. Check what migrations will run:
   ```
   python manage.py showmigrations daks
   python manage.py migrate daks --plan
   ```
4. **One possible snag:** `0002_userprofile_can_take_screenshot` adds a
   column that — if you ever ran a manual `ALTER TABLE` for it yourself
   outside Django (like your `fix_all_tables.py` scripts do for other
   columns) — might already exist on the live DB. If `migrate` errors with
   "column already exists" on that one specifically, run:
   ```
   python manage.py migrate daks 0002 --fake
   python manage.py migrate daks 0003
   ```
   to skip re-creating it and continue to the real change.
5. Run it:
   ```
   python manage.py migrate
   ```

## Why this is safe to run on data that already exists
Django's normal auto-generated migration for a unique field with
`default=uuid.uuid4` only evaluates that default **once** and reuses the
same value for every existing row — which would crash immediately on a
table with more than one row (duplicate key on the unique constraint).

So `0003_add_public_ids.py` is hand-written, not auto-generated, in three
safe stages: add the column nullable → walk every existing row and give it
its own fresh UUID → only then lock the column to NOT NULL + UNIQUE.

**I proved this isn't just theoretical** — before sending this, I built a
throwaway copy of your schema, inserted rows simulating real pre-existing
data, ran this exact migration against it, and confirmed every row got its
own distinct UUID with no collision. Don't substitute the auto-generated
version if you ever re-run `makemigrations` — keep this hand-written file.

## What's NOT changed (on purpose, lower risk for one day)
- **The `User` model / `/users/...` URLs** — still integer IDs. Admin-only,
  already gated, smaller attack surface. Can extend the same pattern later
  if you want.
- **Link sub-resources** (`eDWDakLink`, `eTOTDakLink` — the `link_pk` in
  `/edw/<id>/unlink-dak/<link_pk>/`) — still integer. These are internal,
  staff-only, and not independently browsable.
- **Internal form values** (e.g. the thread dropdown when replying to an
  outgoing dak, or the dak picker inside eDW linking) — these still submit
  the real internal pk in POST/GET data. They're not URL paths you can
  type or bookmark, just values a `<select>` sends back, so changing them
  would mean rewriting form widgets for no real security benefit.

## Bonus fix (found while testing, unrelated to today's list)
`edw_detail.html` was using a custom template filter (`split`) without
loading it — meaning **the eDW detail page currently 500-errors for every
user on your live site right now**, independent of anything in this
phase. Added the missing `{% load custom_filters %}`. Worth confirming on
your end since I only caught it because I happened to test that page.

## Tested before sending
- `py_compile` on every changed file — clean.
- Full `python manage.py check` — no issues.
- Built a disposable SQLite copy of your real schema, ran the migration
  against seeded data, then used Django's test client (logged in) to hit
  every converted URL — `dak_detail`, `thread_detail`,
  `download_attachment`, `task_detail`/`edit`/`delete`, `edw_detail`/
  `edit`/`delete`, `etot_detail`/`edit`/`delete`, `eiig_detail`/`edit`/
  `delete`, all dashboards, plus POST actions (`task_update_status`,
  `thread_close`) — all returned correctly, and the **old** integer URLs
  now correctly 404 instead of silently still working.
- This was all on a disposable SQLite stand-in, not your actual Postgres —
  the migration logic is database-agnostic, but please still test on a
  copy of the real DB if you can before touching production.
