# Apache Deployment Guide (#11)

I didn't just write this from documentation — I actually installed Apache
2.4.58 + mod_wsgi in a sandbox, deployed this exact codebase against a
real PostgreSQL database, and tested real HTTP requests through it
(login, dashboard, static files) before writing any of this down. Two
real bugs turned up doing that, both already fixed in this delivery —
details below.

## 1. System packages (Linux/Apache server)

```bash
sudo apt update
sudo apt install -y apache2 libapache2-mod-wsgi-py3 python3-venv postgresql-client
```

`libapache2-mod-wsgi-py3` must match your server's Python version — it's
built against whatever `python3` resolves to on that machine. Check with
`python3 --version` first; if it's not 3.12 and the package doesn't match,
build mod_wsgi from pip inside your venv instead (`pip install mod_wsgi`,
then `mod_wsgi-express install-module` and use the line it prints in your
Apache config instead of `libapache2-mod-wsgi-py3`).

You do **not** need `libpq-dev` — `psycopg2-binary` in requirements.txt
ships its own compiled Postgres client library.

## 2. Python dependencies

**Fixed in this delivery**: `requirements.txt` had a bare `pywin32>=306`
line — that package has no Linux build at all, so `pip install -r
requirements.txt` would fail outright on your Apache server. It's also
not imported anywhere in the actual app code (checked). Changed it to:
```
pywin32>=306; sys_platform == 'win32'
```
pip now correctly skips it on Linux while it still installs fine on
Windows for whoever's still developing there — one requirements.txt file
works for both.

```bash
cd /var/www/edms/Code   # wherever you put the project
python3 -m venv ../venv
../venv/bin/pip install -r requirements.txt
```

## 3. Configuration (.env)

Use the `.env`/`.env.example` from the Phase 3 delivery, but on the real
server set:
```
DJANGO_DEBUG=False
DJANGO_ALLOWED_HOSTS=edms.tbrl.local,<server-ip>
DJANGO_SECRET_KEY=<generate one — see below>
DB_USER=edms_app
DB_PASSWORD=<the edms_app password from phase3_db_users.sql>
```
Generate a real secret key:
```bash
python3 -c "import secrets; print(secrets.token_urlsafe(50))"
```

**Found and fixed while testing this**: `SECRET_KEY`, `DEBUG`, and
`ALLOWED_HOSTS` in `settings.py` were still reading from plain
`os.environ`, while `DATABASES` (changed back in Phase 3) reads through
`python-decouple`. Since decouple's `.env` file doesn't populate real OS
environment variables, your `.env` file was silently having **no effect**
on those three settings — only DB credentials actually came from it. Now
all four are consistent through decouple, so one `.env` file genuinely
controls all of it. Also changed `DEBUG`'s default from `True` to
`False` — a forgotten env var should fail toward "production mode," not
accidentally leave debug pages exposed.

⚠️ **This changes local dev behavior too** — without `DJANGO_DEBUG=True`
and `DJANGO_ALLOWED_HOSTS=localhost,127.0.0.1` set somewhere, your local
`manage.py runserver` would now respond to everything with a
`DisallowedHost` error, because `ALLOWED_HOSTS` would end up empty. The
updated `.env` in this delivery (replaces the Phase 3 one) already has
both lines added so this doesn't break your local setup.

## 4. Collect static files

```bash
../venv/bin/python manage.py collectstatic --noinput
```

## 5. Directory permissions — the bug I actually hit

**This is the second real bug found by testing, not reading**: Apache's
`mod_wsgi` runs as `www-data`, not as you. After getting everything else
working, login crashed with `PermissionError: [Errno 13] Permission
denied` on the `cache/` directory — because `cache/` and `media/` were
owned by whoever created them (you, running as yourself), and `www-data`
had no write access. Same thing will happen on your server unless these
are fixed:

```bash
sudo chown -R www-data:www-data /var/www/edms/Code/cache /var/www/edms/Code/media
```
(`staticfiles/` doesn't need this — Apache only reads from it.)

## 6. Apache config

Use `apache_edms_final.conf` in this zip — copy it to
`/etc/apache2/sites-available/edms.conf`, edit every `/var/www/edms/...`
path to match where you actually put the project, then:

```bash
sudo a2dissite 000-default
sudo a2ensite edms
sudo apache2ctl configtest
sudo systemctl restart apache2
sudo systemctl enable apache2   # survive reboots
```

## 7. Verify

```bash
curl -I http://your-server-ip/login/
```
Should return `200`. If you get `400 Bad Request`, your `Host` header
doesn't match `DJANGO_ALLOWED_HOSTS` — this is exactly what I hit first
in testing; add the right hostname/IP to `.env`.

## What I actually verified end to end
- Apache serving the real WSGI app through mod_wsgi, against a real
  PostgreSQL database (not SQLite) — including running migrations
  against it.
- Static files served by Apache directly (not Django) — `Alias /static/`
  confirmed returning real CSS files with 200.
- A full login → dashboard flow through real HTTP requests, with the
  Phase 1 `NoCacheForAuthenticatedMiddleware` header confirmed present.
- The full Django deployment checklist (`manage.py check --deploy`) —
  the remaining warnings (HSTS, SSL redirect, secure cookies) are all
  HTTPS-related and expected until you add a certificate; not bugs.
- `DEBUG=False` (real production mode) end to end, then reverted to
  confirm `DEBUG=True` still works for your local dev machine.

## Next step, not done here
HTTPS/TLS isn't set up (needs your actual domain or a self-signed cert
for internal use, plus a real certificate decision — Let's Encrypt won't
work for an internal/LAN-only hostname). Once you have a cert, the
commented block at the bottom of `apache_edms_final.conf` plus setting
`SESSION_COOKIE_SECURE=True` in `.env` is what's left — `manage.py check
--deploy` will tell you exactly what else to flip on at that point.
