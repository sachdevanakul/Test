# Phase 8 — Colors (#20)

3 files: `templates/daks/base.html`, `templates/registration/login.html`,
`templates/registration/logged_out.html`.

## Changes
- **Main content background**: `#f1f5f9` → `#eef2f7` (light blue-gray)
- **Left sidebar**: `#fff` → `#e9f6f2` (light teal-tint) — a clearly
  different hue from the main background now, not just a slightly
  different shade of the same one, while still pairing with your existing
  teal brand accent (`#0f766e`) used in the top bar and buttons
- **Login page**: the purple/indigo gradient (`#667eea → #764ba2`, what
  reads as "pink" was likely this) → light green (`#a7f3d0 → #6ee7b7`),
  button updated to match (`#34d399 → #10b981`)
- **Logout confirmation page**: updated the same way for consistency —
  though worth knowing, this template is actually never reached right
  now. `LOGOUT_REDIRECT_URL` sends users straight to `/login/` after
  logging out, so `logged_out.html` is dead code. Didn't touch that
  behavior since the practical outcome you want (no purple/pink after
  logout) is already covered by the login page itself; just mentioning it
  so the unreachable template doesn't look like a wasted edit.

## A mistake I made and want to be upfront about
While editing the CSS in `login.html`, two of my edits accidentally
dropped surrounding properties (`display`, `border`, `cursor`, etc.) that
weren't part of what I meant to change — a copy-paste boundary mistake.
I caught both by checking brace balance and diffing the full file
afterward, not by luck, and fixed them before this ever reached you. The
file you're getting has been verified property-by-property against the
original; flagging it rather than glossing over it.

## Tested for real
Rendered the actual login page, home page, a regular list page, and the
logout flow through Django's test client:
- Login page: confirmed the new gradient colors are present and the old
  ones are completely gone.
- Home page: confirmed both new background colors actually appear in the
  rendered HTML.
- Dak list and other pages: still render fine (200), nothing broken by
  the base.html change.
- Full `py_compile` + `manage.py check` — clean.
