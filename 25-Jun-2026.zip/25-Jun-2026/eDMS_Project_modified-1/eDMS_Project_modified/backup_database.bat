@echo off
echo ========================================
echo   eDMS - Database Backup
echo ========================================
echo.

REM Set variables
set BACKUP_ROOT=C:\eDMS_Project\Backups
set DATE=%date:~10,4%%date:~7,2%%date:~4,2%
set TIME=%time:~0,2%%time:~3,2%
set TIMESTAMP=%DATE%_%TIME%
set LOG_FILE=%BACKUP_ROOT%\Logs\db_backup_%TIMESTAMP%.log

echo Starting database backup at %DATE% %TIME% > %LOG_FILE%
echo. >> %LOG_FILE%

REM Set PostgreSQL path (adjust if different)
set PG_PATH=C:\Program Files\PostgreSQL\15\bin
set PATH=%PATH%;%PG_PATH%

REM Database credentials
set DB_NAME=edms_db
set DB_USER=postgres
set DB_PASSWORD=EDMS@2024
set PGPASSWORD=%DB_PASSWORD%

echo [1/2] Backing up database... >> %LOG_FILE%
echo [1/2] Backing up database...

pg_dump -U %DB_USER% -d %DB_NAME% > %BACKUP_ROOT%\Daily\edms_db_%TIMESTAMP%.sql 2>> %LOG_FILE%

if %errorlevel% equ 0 (
    echo ✓ Database backup successful >> %LOG_FILE%
    echo ✓ Database backup successful
) else (
    echo ✗ Database backup failed >> %LOG_FILE%
    echo ✗ Database backup failed
    pause
    exit /b 1
)

echo [2/2] Compressing backup... >> %LOG_FILE%
echo [2/2] Compressing backup...

cd %BACKUP_ROOT%\Daily
"C:\Program Files\7-Zip\7z.exe" a -tzip edms_db_%TIMESTAMP%.zip edms_db_%TIMESTAMP%.sql >> %LOG_FILE% 2>&1

if %errorlevel% equ 0 (
    del edms_db_%TIMESTAMP%.sql
    echo ✓ Compression successful >> %LOG_FILE%
    echo ✓ Compression successful
) else (
    echo ✗ Compression failed >> %LOG_FILE%
    echo ✗ Compression failed
)

echo. >> %LOG_FILE%
echo ======================================== >> %LOG_FILE%
echo BACKUP COMPLETED AT %TIME% >> %LOG_FILE%
echo ======================================== >> %LOG_FILE%

echo.
echo Database backup completed!
echo Location: %BACKUP_ROOT%\Daily\edms_db_%TIMESTAMP%.zip
pause