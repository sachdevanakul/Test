# Phase 1 — Security Foundation (changed files)

Drop these into your project at the same relative paths (overwrite existing files):
- `daks/views.py`
- `edms/settings.py`
- `daks/middleware.py` (new file)

## What changed and why

1. **Critical fix — `download_attachment` view (daks/views.py)**
   This view had **no `@login_required`** at all. Anyone who knew or guessed
   an attachment ID could paste the download URL into a browser, no login,
   no session — exactly the leak you flagged. Added `@login_required`.

2. **`api_thread_subject` view (daks/views.py)**
   Also had no auth check (minor info leak — returns a thread's subject
   text to anyone). Added `@login_required`. Found during the endpoint
   audit, same as item #2 on your list.

3. **Pre-existing syntax bug (daks/views.py, `thread_close`)**
   Unrelated to the security list, but found while reviewing: line 680 had
   a literal `\n` typed into the source instead of an actual line break
   (`@login_required\ndef thread_close...`), which makes the entire file
   fail to import. Fixed. This may explain other "this isn't working"
   symptoms you've seen, since the app can't even boot with this in place.
   I scanned the rest of the codebase for the same pattern — nothing else
   was affected.

4. **Logout / back-button fix (`daks/middleware.py`, new + registered in
   `edms/settings.py`)**
   Your logout view itself works fine — Django clears the session
   correctly. The actual bug: no page had no-cache headers, so after
   logging out, pressing **Back** shows a stale cached page from the
   browser's own cache, making it *look* like logout failed. Added
   `NoCacheForAuthenticatedMiddleware`, registered right after
   `AuthenticationMiddleware` in `MIDDLEWARE`. Now every page served to a
   logged-in user is marked `no-store`, so Back always re-checks with the
   server and correctly bounces to `/login/`.

5. **Dak endpoint method (#3 on your list)**
   Checked `dak_create_incoming` / `dak_create_outgoing` and their
   templates: both are already POST-only with `{% csrf_token %}` in the
   form. No change made here — it was already correct, changing it would
   have made things worse, not better.

6. **Delete endpoints / session checks (#2)**
   Audited every delete view (`dak_delete`, `thread_delete`, `edw_delete`,
   `etot_delete`, `eiig_delete`, `user_delete`, `task_delete`). All already
   have `@login_required` + a role check (`is_staff`/`is_superuser`) and
   only act on POST. No changes needed there — `download_attachment` above
   was the actual hole.

## Verified before sending
- `python -m py_compile` on every `.py` file in the project — clean.
- Full `python manage.py check` against a throwaway venv with your
  `requirements.txt` installed (minus `pywin32`, which is Windows-only and
  unrelated) — **"System check identified no issues."**

## Still open from Phase 1
- **Session management (#15):** your `SESSION_COOKIE_*` settings in
  `settings.py` were already solid (`HTTPONLY`, `SAMESITE=Lax`, 8h age,
  expire-at-browser-close). One thing to flip later: `SESSION_COOKIE_SECURE`
  is `False` — set it to `True` once you're serving over HTTPS (can't turn
  it on yet without breaking login over plain HTTP, which is what you're
  on until the Apache/SSL step).
