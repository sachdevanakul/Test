# Phase 3 — Read-only views, DB users, backup strategy

7 files. Paths: `daks/migrations/0004_create_readonly_views.py`,
`edms/settings.py` (overwrite), `phase3_db_users.sql`, `backup_db.py`,
`.env`, `.env.example`, `.gitignore` (all four go in `Code/`, next to
`manage.py`).

## 1. Read-only views (#8)
Migration `0004` creates 7 Postgres views: `v_dak_summary`,
`v_dak_attachment_safe`, `v_thread_summary`, `v_task_summary`,
`v_edw_summary`, `v_etot_summary`, `v_eiig_summary`.

These don't change how the Django app works — it keeps reading/writing the
real tables. The point is to give anything that only ever needs to **read**
(an analyst at psql, a future BI tool, the restricted `edms_app` role below)
a safe, curated surface instead of raw tables: no server file paths
(`file_path` on attachments), no checksums, and no granular financial
breakdowns (bank references, refund/cancellation amounts, GST details) —
just the fields a read-only consumer actually needs.

**Tested for real**, not just in theory: I installed Postgres in my own
sandbox, ran every migration including this one against it, and confirmed
all 7 views exist and return correctly joined data.

## 2. Two DB users, least privilege (#1)
`phase3_db_users.sql` — run this with `psql -U postgres -d edms_db -f phase3_db_users.sql`.

- **`edms_admin`** — full read/write **and** schema rights (CREATE/ALTER/DROP).
  Used by a human for `python manage.py migrate` and your `fix_*_tables.py`
  scripts. Not what the live web app connects as.
- **`edms_app`** — read/write on data (SELECT/INSERT/UPDATE/DELETE), but
  **no** schema rights at all. This is what the deployed app actually
  connects as. Even if the running app were ever compromised, the attacker
  can't drop or alter tables — only touch rows the app itself could already
  touch.

⚠️ **Edit the two `CHANGE_ME_..._PASSWORD` placeholders in the SQL file
before running it.** Don't reuse `Nakul@123` — that password has been
sitting in plaintext in `settings.py` and you don't want it on either of
these new roles.

**I didn't just write this and hope** — I installed a real Postgres in my
sandbox and actually logged in as each role to confirm the boundary holds:
- `edms_app`: SELECT ✅, INSERT ✅ (on real tables), INSERT into a view ❌,
  `CREATE TABLE` ❌ ("permission denied for schema public"),
  `DROP TABLE` ❌.
- `edms_admin`: `CREATE TABLE` ✅, `DROP TABLE` ✅.

## 3. Found and fixed while in here: the hardcoded DB password
`settings.py` had `'PASSWORD': os.environ.get('DB_PASSWORD', 'Nakul@123')`
— a real password sitting as plaintext fallback in source. Since I was
already touching this exact block for the new DB user, I wired in
`python-decouple` (it's already in your `requirements.txt`, just unused)
properly:
- `DB_PASSWORD` now has **no fallback** — if it's not set, the app refuses
  to start instead of silently connecting with a leaked password. Tested
  both ways: confirmed it throws `decouple.UndefinedValueError` with
  nothing set, and works normally once `.env` is present.
- Default `DB_USER` is now `edms_app` (not `postgres`).
- `.env` in this zip keeps your **local dev machine** working exactly as
  before (still points at your current credentials) — don't commit it.
  `.env.example` is the safe, committable template for anyone else.
- Added a `.gitignore` (you didn't have one) so `.env` can't get committed
  by accident.

## 4. Backup strategy — database only, as you asked (#6)
`backup_db.py` — `pg_dump`s the DB in compressed custom format, timestamps
the file, and deletes anything older than 14 days. Deliberately doesn't
touch attachment files, per your instruction.

Schedule it:
- **Linux (cron)**, daily at 2 AM:
  `0 2 * * * /usr/bin/python3 /path/to/backup_db.py >> /path/to/backup.log 2>&1`
- **Windows Task Scheduler**: Basic Task → Daily → Action: your venv's
  `python.exe` with `backup_db.py` as the argument.

**Tested for real**: ran it against the live test database, then actually
restored the resulting `.dump` into a fresh database with `pg_restore` and
confirmed the data (including the views) came back intact — a backup
you've never test-restored is a backup you don't actually have.

One thing worth knowing, found during that test: **restore as the Postgres
superuser**, not as `edms_admin`, when recovering into a brand-new/empty
database. `edms_admin` only has CREATE rights on the `edms_db` schema
specifically (granted by `phase3_db_users.sql`) — a fresh database won't
have that grant yet, so table creation during restore fails with
"permission denied for schema public" until either you restore as
superuser (normal practice for disaster recovery) or run the schema grant
from `phase3_db_users.sql` against the new database first.

## Tested before sending
- `py_compile` — clean.
- Installed a real PostgreSQL 16 in my sandbox (not SQLite this time) and
  ran every migration through `0004` against it for real.
- Logged in as both new roles and verified the actual privilege boundaries
  by trying to do things that should and shouldn't be allowed.
- Ran the backup script for real, then test-restored the dump into a fresh
  database and confirmed the data and views came back correctly.
- Confirmed `settings.py` fails loudly without `DB_PASSWORD` set, and works
  normally with `.env` present.
