# Run as Administrator

# Daily Backup at 6:00 PM
$dailyAction = New-ScheduledTaskAction -Execute "C:\eDMS_Project\backup_database.bat"
$dailyTrigger = New-ScheduledTaskTrigger -Daily -At 6:00PM
$dailySettings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
Register-ScheduledTask -TaskName "eDMS Daily Database Backup" -Action $dailyAction -Trigger $dailyTrigger -Settings $dailySettings -User "SYSTEM" -RunLevel Highest

# Daily File Backup at 6:30 PM
$fileAction = New-ScheduledTaskAction -Execute "C:\eDMS_Project\backup_files.bat"
$fileTrigger = New-ScheduledTaskTrigger -Daily -At 6:30PM
Register-ScheduledTask -TaskName "eDMS Daily File Backup" -Action $fileAction -Trigger $fileTrigger -Settings $dailySettings -User "SYSTEM" -RunLevel Highest

# Weekly Full Backup on Friday at 8:00 PM
$weeklyAction = New-ScheduledTaskAction -Execute "C:\eDMS_Project\backup_weekly.bat"
$weeklyTrigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek "Friday" -At 8:00PM
Register-ScheduledTask -TaskName "eDMS Weekly Full Backup" -Action $weeklyAction -Trigger $weeklyTrigger -Settings $dailySettings -User "SYSTEM" -RunLevel Highest

Write-Host "Backup schedules created successfully!" -ForegroundColor Green