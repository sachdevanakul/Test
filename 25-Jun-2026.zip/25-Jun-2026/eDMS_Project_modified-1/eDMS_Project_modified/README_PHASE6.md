# Phase 6 — Reporting (#9, #10, #21)

3 files: `daks/reports.py`, `templates/daks/report_builder.html` (new),
`templates/daks/report_dashboard.html`.

## The surprise: most of this was already built
Before changing anything, I read the existing code — and #9 (header on
every page) and #10 (date-basis fix + custom range report) were **already
implemented**, with docstrings literally describing the fix. Most of #21
(column-picker report builder) was there too: `report_columns.py`
auto-introspects eDW/eTOT/eIIG's fields into a checklist, and
`generate_module_pdf_report`/`generate_module_docx_report` in `reports.py`
already build watermarked exports from whatever columns get picked.

So today's real job was verifying it actually works, not rebuilding it —
and that surfaced two real bugs blocking all of it.

## Bug 1 (severe): every PDF report was completely broken
`generate_pdf_report` — the function every standard report (daily,
monthly, range, category, pending) calls for PDF export — had no `def`
line. Somewhere along the way, the function signature got deleted, and
what was left was a docstring and function body sitting as dead code
inside the *previous* function, never executed, after a `return`. Calling
any of those reports with `?format=pdf` crashed with
`NameError: name 'generate_pdf_report' is not defined`.

This is exactly the kind of bug that `py_compile`/`manage.py check` can't
catch — dead code after a `return` is syntactically valid Python, it just
silently never runs. Only actually calling it surfaces the problem, which
is why I test every fix against a real request instead of just reading
the code. Fixed by restoring the missing `def generate_pdf_report(data,
title, start_date, end_date, watermark_text='IIG-DCMM'):` line.

## Bug 2: the report builder's template didn't exist
The `report_builder` view, the column registry, the PDF/DOCX generators —
all real and working. But `daks/report_builder.html` was never created,
so visiting the page 500'd with `TemplateDoesNotExist`. Built it: module
tabs (eDW/eToT/eIIG), a checklist that repopulates from the real field
list when you switch modules, optional date range, PDF/Word format
choice, and a watermark text box (defaults to "IIG-DCMM" per your ask).
Also added a card on the Reports Dashboard linking to it — it existed but
had no way to find it either.

## Tested for real
- Date basis: created an incoming dak entered on the 10th but received on
  the 1st, and an outgoing dak entered on the 10th but dispatched on the
  20th. Confirmed a report for the 1st catches only the incoming one, a
  report for the 20th catches only the outgoing one, and a report for the
  entry date (the 10th) catches **neither** — proving it's genuinely using
  receipt/dispatch date, not entry date.
- Header fix: generated an 80-row PDF (4 pages), opened it with `pypdf`,
  and confirmed the title and page number actually appear on every single
  page, not just the first.
- Report builder: rendered the page, generated a real PDF and a real
  DOCX with picked columns, confirmed a foreign-key column resolved to
  the actual organization name (not "OrganizationMaster object"),
  confirmed the custom watermark text shows up in the extracted PDF text,
  confirmed picking zero columns gives a clean 400 instead of crashing,
  and confirmed a non-staff user gets redirected away from the page.
- Reran PDF generation for daily/category/pending reports too, since they
  all share the function that was broken — all three now return 200.

12 checks across the builder alone, all passed, plus the date-basis and
header tests.
